package com.airlink.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** Permanent: everybody who connected once. */
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val photo: ByteArray?,
    val lastSeen: Long
)

/** Temporary (7 days). kind: 0 = text, 1 = voice message, 2 = file. status: 0 sent, 1 delivered, 2 seen. progress: 0..100, -1 = failed. */
@Entity(tableName = "messages", indices = [Index("convId")])
data class MessageEntity(
    @PrimaryKey val id: String,
    val convId: String,
    val senderId: String,
    val senderName: String,
    val kind: Int,
    val text: String,
    val path: String,
    val fileName: String,
    val fileSize: Long,
    val outgoing: Boolean,
    val status: Int,
    val progress: Int,
    val timestamp: Long
)

/** Temporary (7 days). */
@Entity(tableName = "calls")
data class CallEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val convId: String,
    val peerName: String,
    val video: Boolean,
    val outgoing: Boolean,
    val timestamp: Long,
    val durationSec: Int
)

@Dao
interface AirDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUser(u: UserEntity)

    @Query("SELECT * FROM users ORDER BY lastSeen DESC")
    fun users(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun user(id: String): UserEntity?

    @Query("DELETE FROM users")
    suspend fun clearUsers()

    @Query("UPDATE users SET lastSeen = :t WHERE id = :id")
    suspend fun touchUser(id: String, t: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMessage(m: MessageEntity)

    @Query("SELECT * FROM messages WHERE convId = :c ORDER BY timestamp ASC")
    fun messages(c: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE convId = :c ORDER BY timestamp ASC")
    suspend fun messagesOnce(c: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE kind > 0 ORDER BY timestamp DESC")
    fun transfers(): Flow<List<MessageEntity>>

    @Query("UPDATE messages SET status = :s WHERE id = :id AND status < :s")
    suspend fun setStatus(id: String, s: Int)

    @Query("UPDATE messages SET progress = :p WHERE id = :id")
    suspend fun setProgress(id: String, p: Int)

    @Query("SELECT * FROM messages WHERE convId = :c AND outgoing = 0 AND status < 2")
    suspend fun unseen(c: String): List<MessageEntity>

    @Insert
    suspend fun insertCall(c: CallEntity)

    @Query("SELECT * FROM calls ORDER BY timestamp DESC")
    fun calls(): Flow<List<CallEntity>>

    @Query("SELECT * FROM messages WHERE timestamp < :t")
    suspend fun oldMessages(t: Long): List<MessageEntity>

    @Query("DELETE FROM messages WHERE timestamp < :t")
    suspend fun deleteOldMessages(t: Long)

    @Query("DELETE FROM calls WHERE timestamp < :t")
    suspend fun deleteOldCalls(t: Long)

    @Query("SELECT * FROM messages")
    suspend fun allMessages(): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE convId = :c")
    suspend fun convMessages(c: String): List<MessageEntity>

    @Query("DELETE FROM messages WHERE convId = :c")
    suspend fun clearConv(c: String)

    @Query("DELETE FROM messages")
    suspend fun clearMessages()

    @Query("DELETE FROM calls")
    suspend fun clearCalls()
}

@Database(entities = [UserEntity::class, MessageEntity::class, CallEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AirDao

    companion object {
        fun build(c: Context): AppDb =
            Room.databaseBuilder(c.applicationContext, AppDb::class.java, "airlink.db").build()
    }
}
