package com.airlink.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.airlink.app.data.MessageEntity
import com.airlink.app.net.Manager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * The floating chat bubble. It is drawn above every other app (needs "Display over other apps"),
 * can be dragged anywhere, and is only visible while a chat/call is connected and Airlink itself is not on screen.
 * Tap it to open a small panel: latest messages, a reply box, call controls and a button to open the full chat.
 */
class FloatingBubble(private val ctx: Context, private val mgr: Manager, private val scope: CoroutineScope) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dens = ctx.resources.displayMetrics.density
    private fun px(v: Int) = (v * dens).toInt()

    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var expanded = false

    private var titleTv: TextView? = null
    private var callTv: TextView? = null
    private var callRow: LinearLayout? = null
    private var acceptBtn: TextView? = null
    private var endBtn: TextView? = null
    private var msgsTv: TextView? = null
    private var scroll: ScrollView? = null
    private var input: EditText? = null

    private var convNow = ""
    private var unread = 0

    @OptIn(ExperimentalCoroutinesApi::class)
    fun start() {
        scope.launch {
            combine(mgr.session, mgr.online, mgr.appVisible) { s, o, v ->
                s.mode != 0 && o.isNotEmpty() && !v && Settings.canDrawOverlays(ctx)
            }.distinctUntilChanged().collect { if (it) show() else hide() }
        }
        scope.launch {
            combine(mgr.session, mgr.online) { s, o -> if (s.mode == 2) s.groupId else (o.keys.firstOrNull() ?: "") }
                .distinctUntilChanged()
                .flatMapLatest { c ->
                    convNow = c
                    if (c.isEmpty()) flowOf(emptyList<MessageEntity>()) else mgr.dao.messages(c)
                }
                .collect { render(it) }
        }
        scope.launch {
            mgr.call.collect {
                if (it.state == 1 && bubble != null && !expanded) expand()
                updateCall()
            }
        }
        scope.launch {
            while (isActive) {
                delay(1000)
                if (expanded) updateCall()
            }
        }
    }

    fun stop() {
        hide()
    }

    // ------------------------------------------------------------ helpers

    private fun title(): String {
        val s = mgr.session.value
        return if (s.mode == 2) s.groupName.ifBlank { "Group" } else (mgr.online.value.values.firstOrNull()?.name ?: "Airlink")
    }

    private fun btn(text: String, c1: Long, c2: Long, onClick: () -> Unit): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.setPadding(px(12), px(7), px(12), px(7))
        val r = floatArrayOf(30f, 30f, 10f, 10f, 30f, 30f, 10f, 10f).map { it * dens }.toFloatArray()
        tv.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c1.toInt(), c2.toInt())).apply {
            cornerRadii = r
            setStroke(px(1), 0x99FFFFFF.toInt())
        }
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun lpParams(w: Int, h: Int, focusable: Boolean): WindowManager.LayoutParams {
        val flags = if (focusable) WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    // ------------------------------------------------------------ show / hide

    private fun show() {
        if (bubble != null) return
        val tv = TextView(ctx)
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        tv.textSize = 22f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.elevation = px(6).toFloat()
        tv.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7C3AED.toInt(), 0xFFEC4899.toInt())).apply {
            shape = GradientDrawable.OVAL
            setStroke(px(2), 0x99FFFFFF.toInt())
        }
        val lp = lpParams(px(58), px(58), false)
        lp.x = 0
        lp.y = px(220)
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > px(6) || abs(dy) > px(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (x: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        toggle()
                    } else {
                        val w = ctx.resources.displayMetrics.widthPixels
                        lp.x = if (lp.x + px(29) < w / 2) 0 else w - px(58)
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (x: Exception) {
                        }
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(tv, lp)
        } catch (e: Exception) {
            return
        }
        bubble = tv
        bubbleLp = lp
        refreshBubble()
    }

    private fun hide() {
        if (expanded) collapse()
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        bubble = null
        bubbleLp = null
    }

    private fun toggle() {
        if (expanded) collapse() else expand()
    }

    // ------------------------------------------------------------ panel

    private fun buildPanel(): LinearLayout {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(12), px(12), px(12), px(12))
        root.background = GradientDrawable().apply {
            setColor(0xF51E1B4B.toInt())
            cornerRadius = px(20).toFloat()
            setStroke(px(1), 0x66FFFFFF)
        }

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(ctx)
        t.setTextColor(Color.WHITE)
        t.textSize = 17f
        t.typeface = Typeface.DEFAULT_BOLD
        t.maxLines = 1
        head.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val open = btn("Open", 0xFF22D3EE, 0xFF3B82F6) { openApp() }
        val close = btn("✕", 0xFF6B7280, 0xFF4B5563) { collapse() }
        head.addView(open)
        head.addView(close, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = px(6) })
        root.addView(head)

        val cr = LinearLayout(ctx)
        cr.orientation = LinearLayout.HORIZONTAL
        cr.gravity = Gravity.CENTER_VERTICAL
        cr.visibility = View.GONE
        val ct = TextView(ctx)
        ct.setTextColor(0xFF67E8F9.toInt())
        ct.textSize = 14f
        ct.typeface = Typeface.DEFAULT_BOLD
        cr.addView(ct, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val acc = btn("Accept", 0xFF22C55E, 0xFF14B8A6) {
            val c = mgr.call.value
            mgr.acceptCall()
            if (c.video) openApp()
        }
        val end = btn("End call", 0xFFEF4444, 0xFFF97316) {
            if (mgr.call.value.state == 1) mgr.rejectCall() else mgr.endCall()
        }
        cr.addView(acc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = px(6) })
        cr.addView(end)
        root.addView(cr, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8) })

        val sv = ScrollView(ctx)
        val mt = TextView(ctx)
        mt.setTextColor(Color.WHITE)
        mt.textSize = 14f
        mt.setLineSpacing(px(3).toFloat(), 1f)
        sv.addView(mt)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(180)).apply { topMargin = px(8) })

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val et = EditText(ctx)
        et.hint = "Message"
        et.setHintTextColor(0x99FFFFFF.toInt())
        et.setTextColor(Color.WHITE)
        et.textSize = 14f
        et.maxLines = 3
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val send = btn("Send", 0xFF7C3AED, 0xFFEC4899) {
            val txt = et.text.toString().trim()
            if (txt.isNotEmpty()) {
                mgr.sendText(txt)
                et.setText("")
            }
        }
        row.addView(send, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = px(6) })
        root.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(8) })

        titleTv = t
        callRow = cr
        callTv = ct
        acceptBtn = acc
        endBtn = end
        msgsTv = mt
        scroll = sv
        input = et
        return root
    }

    private fun expand() {
        if (expanded || bubble == null) return
        val p = buildPanel()
        val w = ctx.resources.displayMetrics.widthPixels - px(24)
        val lp = lpParams(w, WindowManager.LayoutParams.WRAP_CONTENT, true)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = px(60)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        try {
            wm.addView(p, lp)
        } catch (e: Exception) {
            return
        }
        panel = p
        panelLp = lp
        expanded = true
        mgr.setActive(convNow)
        titleTv?.text = title()
        updateCall()
        scope.launch { render(mgr.dao.messagesOnce(convNow)) }
    }

    private fun collapse() {
        panel?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        panel = null
        expanded = false
        titleTv = null
        callRow = null
        callTv = null
        acceptBtn = null
        endBtn = null
        msgsTv = null
        scroll = null
        input = null
        mgr.setActive("")
    }

    private fun openApp() {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("open_chat", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
        collapse()
    }

    // ------------------------------------------------------------ live updates

    private fun refreshBubble() {
        val b = bubble ?: return
        val c = mgr.call.value
        b.text = when {
            c.state != 0 -> "📞"
            unread > 0 -> unread.toString()
            else -> title().take(1).uppercase()
        }
    }

    private fun updateCall() {
        refreshBubble()
        val row = callRow ?: return
        val c = mgr.call.value
        when (c.state) {
            1 -> {
                row.visibility = View.VISIBLE
                callTv?.text = "Incoming " + (if (c.video) "video" else "voice") + " call"
                acceptBtn?.visibility = View.VISIBLE
                endBtn?.text = "Reject"
            }
            2 -> {
                row.visibility = View.VISIBLE
                val secs = if (c.startedAt > 0) ((System.currentTimeMillis() - c.startedAt) / 1000).toInt() else 0
                callTv?.text = if (c.startedAt > 0) "In call  " + Utils.duration(secs) else "Calling..."
                acceptBtn?.visibility = View.GONE
                endBtn?.text = "End call"
            }
            else -> row.visibility = View.GONE
        }
    }

    private fun render(list: List<MessageEntity>) {
        unread = list.count { !it.outgoing && it.status < 2 }
        refreshBubble()
        val tv = msgsTv ?: return
        val sb = StringBuilder()
        for (m in list.takeLast(30)) {
            val who = if (m.outgoing) "Me" else m.senderName.ifBlank { "Them" }
            val body = when (m.kind) {
                0 -> m.text
                1 -> "🎤 Voice message"
                else -> "📎 " + m.fileName
            }
            sb.append(who).append(": ").append(body).append('\n')
        }
        tv.text = if (sb.isEmpty()) "No messages yet" else sb.toString().trimEnd()
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }
}
