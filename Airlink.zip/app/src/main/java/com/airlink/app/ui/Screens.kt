package com.airlink.app.ui

import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.airlink.app.R
import com.airlink.app.Utils
import com.airlink.app.data.CallEntity
import com.airlink.app.data.MessageEntity
import com.airlink.app.data.UserEntity
import com.airlink.app.net.Manager
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class Scr { HOME, DIRECT, GROUP, USERS, HISTORY }

// ------------------------------------------------------------------ helpers

object VoicePlayer {
    private var mp: MediaPlayer? = null

    fun play(path: String) {
        try {
            mp?.release()
            val m = MediaPlayer()
            m.setDataSource(path)
            m.setOnCompletionListener {
                it.release()
                if (mp === it) mp = null
            }
            m.prepare()
            m.start()
            mp = m
        } catch (e: Exception) {
        }
    }
}

class VoiceRec(private val ctx: android.content.Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start(): Boolean {
        return try {
            val dir = File(ctx.filesDir, "voice")
            dir.mkdirs()
            val f = File(dir, "v_" + System.currentTimeMillis() + ".m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            true
        } catch (e: Exception) {
            false
        }
    }

    fun stop(): File? {
        val r = rec ?: return null
        rec = null
        return try {
            r.stop()
            r.release()
            file
        } catch (e: Exception) {
            try {
                r.release()
            } catch (x: Exception) {
            }
            null
        }
    }
}

fun openFile(ctx: android.content.Context, path: String) {
    try {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun Title(text: String, back: (() -> Unit)?, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) {
            AirButton("←", HomeTheme.accent, style = 2, onClick = back)
            Spacer(Modifier.width(10.dp))
        }
        Text(text, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        if (trailing != null) trailing()
    }
}

// ------------------------------------------------------------------ home

@Composable
fun HomeScreen(mgr: Manager, go: (Scr) -> Unit) {
    val ctx = LocalContext.current
    val me by mgr.me.collectAsState()
    var editing by remember { mutableStateOf(false) }
    PageBox(HomeTheme) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(me.photo, me.name, 48.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Hello,", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(me.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 1)
                    Spacer(Modifier.width(8.dp))
                    AirButton("\u270E", HomeTheme.accent, small = true) { editing = true }
                }
            }
            // one small button: tap once = dark mode, tap again = follow the phone's own theme
            AirButton(if (me.dark) "\u263E" else "\u25D0", HomeTheme.accent) { mgr.setDark(!me.dark) }
        }
        Spacer(Modifier.weight(1f))
        Image(
            painterResource(R.drawable.ic_launcher_foreground), null,
            Modifier.size(170.dp).align(Alignment.CenterHorizontally)
        )
        Text(
            "Airlink", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Text(
            "Chat, call and share files with no internet",
            color = Color.White.copy(alpha = 0.85f), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Spacer(Modifier.weight(1f))
        GlassButton(
            "One to one", DirectTheme.accent,
            listOf(Color(0xFF67E8F9), Color(0xFFA78BFA), Color(0xFFF0ABFC)),
            Modifier.fillMaxWidth()
        ) { go(Scr.DIRECT) }
        Spacer(Modifier.height(12.dp))
        GlassButton(
            "Group", GroupTheme.accent,
            listOf(Color(0xFFFDE68A), Color(0xFFFDA4AF), Color(0xFFF0ABFC)),
            Modifier.fillMaxWidth()
        ) { go(Scr.GROUP) }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            AirButton("Saved users", Green, Modifier.weight(1f), 2) { go(Scr.USERS) }
            Spacer(Modifier.width(10.dp))
            AirButton("History", Cyan, Modifier.weight(1f), 3) { go(Scr.HISTORY) }
        }
        Spacer(Modifier.height(8.dp))
    }
    if (editing) EditProfileDialog(mgr) { editing = false }
}

@Composable
fun EditProfileDialog(mgr: Manager, close: () -> Unit) {
    val ctx = LocalContext.current
    val me by mgr.me.collectAsState()
    var name by remember { mutableStateOf(me.name) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val b = Utils.profileBytes(ctx, u)
            if (b != null) mgr.setPhoto(b)
        }
    }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Edit profile") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(me.photo, me.name, 72.dp)
                    Spacer(Modifier.width(12.dp))
                    AirButton("Change photo", HomeTheme.accent, style = 1) { pickPhoto.launch(arrayOf("image/*")) }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(24); mgr.setName(it) },
                    label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { AirButton("Done", Green, style = 1, onClick = close) }
    )
}

// ------------------------------------------------------------------ direct (one to one) + group pages

@Composable
fun ModePage(mgr: Manager, mode: Int, theme: PageTheme, title: String, back: () -> Unit) {
    if (mode == 2) GroupPage(mgr, theme, title, back) else DirectPage(mgr, theme, title, back)
}

@Composable
fun GroupPage(mgr: Manager, theme: PageTheme, title: String, back: () -> Unit) {
    val session by mgr.session.collectAsState()
    val online by mgr.online.collectAsState()
    val tick by mgr.openChatTick.collectAsState()
    var showQr by remember { mutableStateOf(false) }
    LaunchedEffect(online.size) { if (online.isNotEmpty()) showQr = false }
    LaunchedEffect(tick) { if (tick > 0) showQr = false }
    val active = session.mode == 2
    PageBox(theme) {
        if (active && online.isNotEmpty() && !showQr) {
            ChatPanel(mgr, 2, theme, back, onInvite = { showQr = true })
        } else {
            ConnectPanel(mgr, 2, theme, title, back, active && online.isNotEmpty(), onOpenChat = { showQr = false })
        }
    }
}

/** One to one: saved users (name + last seen) -> tap = chat history. QR icon (top right) = connect flow. */
@Composable
fun DirectPage(mgr: Manager, theme: PageTheme, title: String, back: () -> Unit) {
    val session by mgr.session.collectAsState()
    val online by mgr.online.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    val tick by mgr.openChatTick.collectAsState()
    val liveId: String? = if (session.mode == 1) online.keys.firstOrNull() else null
    var selected by remember { mutableStateOf(liveId) }
    var showQr by remember { mutableStateOf(false) }
    var transport by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(liveId) {
        if (liveId != null) {
            selected = liveId
            showQr = false
            transport = null
        }
    }
    LaunchedEffect(tick) {
        if (tick > 0 && liveId != null) {
            selected = liveId
            showQr = false
            transport = null
        }
    }
    BackHandler(enabled = showQr || selected != null) {
        if (showQr) {
            if (transport != null) transport = null else showQr = false
        } else {
            selected = null
        }
    }

    PageBox(theme) {
        val sel = selected
        val tr = transport
        when {
            showQr && tr == null -> TransportChooser(theme, { showQr = false }) { transport = it }
            showQr -> ConnectPanel(
                mgr, 1, theme, "Connect", { transport = null },
                liveId != null, { selected = liveId; showQr = false }, tr == 1
            )
            sel != null -> ChatPanel(mgr, 1, theme, { selected = null }, { }, sel, liveId == sel)
            else -> Column(Modifier.fillMaxSize()) {
                Title(title, back) {
                    AirBox(theme.accent, onClick = { showQr = true; transport = null }) { QrIcon() }
                }
                if (users.isEmpty()) {
                    Panel {
                        Text("No saved users yet.", fontWeight = FontWeight.Bold)
                        Text("Tap the QR icon at the top right to connect with a phone. Everyone you connect with is saved here.", fontSize = 13.sp)
                    }
                }
                val ctx = LocalContext.current
                LazyColumn(Modifier.weight(1f)) {
                    items(users, key = { it.id }) { u ->
                        Panel(Modifier.padding(bottom = 8.dp).clickable { selected = u.id }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Avatar(u.photo, u.name, 46.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(u.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                                    Text(
                                        if (online.containsKey(u.id) && session.mode == 1) "Online now" else "Last seen " + Utils.stamp(ctx, u.lastSeen),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransportChooser(theme: PageTheme, back: () -> Unit, pick: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Title("Connect", back)
        Panel {
            Text("How do you want to connect?", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                AirButton("Bluetooth", Cyan, Modifier.weight(1f), 3) { pick(1) }
                Spacer(Modifier.width(10.dp))
                AirButton("Wi-Fi", theme.accent, Modifier.weight(1f), 1) { pick(0) }
            }
        }
    }
}

@Composable
fun ConnectPanel(
    mgr: Manager, mode: Int, theme: PageTheme, title: String, back: () -> Unit,
    canOpenChat: Boolean, onOpenChat: () -> Unit, fixedBt: Boolean? = null
) {
    val ctx = LocalContext.current
    val session by mgr.session.collectAsState()
    val nearby by mgr.nearby.collectAsState()
    val online by mgr.online.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    var btSel by remember { mutableStateOf(false) }
    val bt = fixedBt ?: btSel
    var gname by remember { mutableStateOf("") }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        val c = r.contents
        if (c != null) mgr.joinFromQr(c)
    }
    val showing = session.mode == mode
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Title(title, back)
        if (fixedBt == null) {
            Row(Modifier.fillMaxWidth()) {
                AirButton("Wi-Fi", if (!bt) theme.accent else Grey, Modifier.weight(1f), 1) { btSel = false }
                Spacer(Modifier.width(10.dp))
                AirButton("Bluetooth", if (bt) theme.accent else Grey, Modifier.weight(1f), 3) { btSel = true }
            }
            Spacer(Modifier.height(10.dp))
        }
        Panel {
            if (bt) {
                Text("Bluetooth is slower. Chat, voice calls and files work, but video calls are Wi-Fi only. Pair the two phones in Bluetooth settings once before connecting.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                AirButton("Open Bluetooth settings", Cyan, Modifier.fillMaxWidth(), 2) {
                    ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                }
            } else {
                Text("Wi-Fi: turn on the hotspot on one phone and connect the other phone to it (or put both on the same Wi-Fi). No internet needed.", fontSize = 13.sp)
            }
            if (mode == 2) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = gname, onValueChange = { gname = it.take(30) },
                    label = { Text("Group name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            AirButton(if (mode == 2) "Create group + QR" else "Show my QR", theme.accent, Modifier.weight(1f), 0) {
                mgr.startHost(mode, bt, gname)
            }
            Spacer(Modifier.width(10.dp))
            AirButton("Scan QR", Cyan, Modifier.weight(1f), 1) {
                scan.launch(
                    ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                        .setPrompt("Scan the Airlink QR code").setBeepEnabled(false).setOrientationLocked(false)
                )
            }
        }
        if (showing) {
            Spacer(Modifier.height(10.dp))
            Panel {
                if (session.host && session.qr.isNotEmpty()) {
                    val bmp = remember(session.qr) { Utils.qrBitmap(session.qr).asImageBitmap() }
                    Image(
                        bmp, "QR code",
                        Modifier.size(250.dp).align(Alignment.CenterHorizontally).background(Color.White).padding(8.dp)
                    )
                    Text(
                        if (mode == 2) "Everybody scans this to join the group" else "Let the other phone scan this",
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 13.sp
                    )
                }
                Text(session.status, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                if (online.isNotEmpty()) {
                    Text("Connected: " + online.values.joinToString { it.name }, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    if (canOpenChat) {
                        AirButton("Open chat", Green, Modifier.weight(1f), 1, onClick = onOpenChat)
                        Spacer(Modifier.width(10.dp))
                    }
                    AirButton("Stop", Red, Modifier.weight(1f), 2) { mgr.stopSession() }
                }
            }
        }
        val near = nearby.values.filter { it.mode == mode }
        if (!bt && near.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Panel {
                Text("Phones nearby", fontWeight = FontWeight.Bold)
                for (n in near) {
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(n.name, Modifier.weight(1f))
                        if (users.any { it.id == n.id }) {
                            AirButton("Connect", theme.accent, style = 1) { mgr.connectNearby(n) }
                        } else {
                            Text("scan their QR", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

/** Chat. `convId` = which saved user (one to one). `live` = connected right now (otherwise read-only history). */
@Composable
fun ChatPanel(
    mgr: Manager, mode: Int, theme: PageTheme, back: () -> Unit, onInvite: () -> Unit,
    convId: String? = null, live: Boolean = true
) {
    val ctx = LocalContext.current
    val session by mgr.session.collectAsState()
    val online by mgr.online.collectAsState()
    val call by mgr.call.collectAsState()
    val nearby by mgr.nearby.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    val conv = if (mode == 2) session.groupId else (convId ?: online.keys.firstOrNull() ?: "")
    val msgs by remember(conv) { mgr.dao.messages(conv) }.collectAsState(initial = emptyList<MessageEntity>())
    val listState = rememberLazyListState()
    val now = rememberNow()
    var text by remember { mutableStateOf("") }
    var muted by remember { mutableStateOf(false) }
    LaunchedEffect(conv) { mgr.setActive(conv) }
    DisposableEffect(Unit) { onDispose { mgr.setActive("") } }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) mgr.sendUri(u)
    }
    val title = if (mode == 2) session.groupName.ifBlank { "Group" }
    else (users.firstOrNull { it.id == conv }?.name ?: online[conv]?.name ?: "Chat")

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            AirButton("←", theme.accent, style = 2, onClick = back)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text(
                    if (live) (online.size + 1).toString() + " online · " + (if (session.bt) "Bluetooth" else "Wi-Fi")
                    else "Offline · saved history",
                    color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp
                )
            }
            if (live) {
                AirButton("📞", Green, style = 0) { mgr.startCall(false) }
                Spacer(Modifier.width(6.dp))
                AirButton("📹", if (session.bt) Grey else Cyan, style = 3) { mgr.startCall(true) }
            }
        }
        if (live) {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                if (mode == 2 && session.host) {
                    AirButton("＋ Invite", theme.accent, Modifier.weight(1f), 1) { onInvite() }
                    Spacer(Modifier.width(8.dp))
                }
                AirButton("Disconnect", Red, Modifier.weight(1f), 2) { mgr.stopSession() }
            }
        }
        if (live && session.bt) {
            Text(
                "Bluetooth is slower: big files and voice may take longer. Video calls are Wi-Fi only.",
                color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)
            )
        }
        if (live && call.state == 2 && !call.video) {
            Panel(Modifier.padding(bottom = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (call.startedAt > 0) "In call  " + Utils.duration(((now - call.startedAt) / 1000).toInt()) else "Calling...",
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                    )
                    AirButton(if (muted) "Unmute" else "Mute", Grey, style = 2) {
                        muted = !muted
                        mgr.audio.muted = muted
                    }
                    Spacer(Modifier.width(8.dp))
                    AirButton("End", Red, style = 1) { mgr.endCall() }
                }
            }
        }
        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(msgs, key = { it.id }) { m -> Bubble(m, theme, mode == 2) }
            if (msgs.isNotEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                    AirButton("Clear conversation", Grey, small = true) {
                        mgr.clearConversation(conv)
                        Toast.makeText(ctx, "Conversation cleared", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        if (live) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                AirButton("📎", Cyan, style = 3) { pick.launch(arrayOf("*/*")) }
                Spacer(Modifier.width(6.dp))
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("Message") }, maxLines = 3
                )
                Spacer(Modifier.width(6.dp))
                if (text.isBlank()) {
                    MicButton(mgr, theme)
                } else {
                    AirButton("➤", theme.accent, style = 0) {
                        mgr.sendText(text.trim())
                        text = ""
                    }
                }
            }
        } else {
            Panel(Modifier.padding(top = 6.dp)) {
                Text("Not connected. To chat again, connect with the QR icon on the previous page.", fontSize = 13.sp)
                val n = nearby[conv]
                if (n != null) {
                    Spacer(Modifier.height(8.dp))
                    AirButton("Connect (nearby)", theme.accent, Modifier.fillMaxWidth(), 1) { mgr.connectNearby(n) }
                }
            }
        }
    }
}

@Composable
fun MicButton(mgr: Manager, theme: PageTheme) {
    val ctx = LocalContext.current
    val rec = remember { VoiceRec(ctx) }
    var recording by remember { mutableStateOf(false) }
    Box(
        Modifier.size(52.dp).clip(AirShape)
            .background(Brush.verticalGradient(if (recording) Red else theme.accent), AirShape)
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), AirShape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    recording = rec.start()
                    tryAwaitRelease()
                    if (recording) {
                        recording = false
                        val f = rec.stop()
                        if (f != null) {
                            if (f.length() > 800) mgr.sendVoice(f) else f.delete()
                        }
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text(if (recording) "●" else "🎤", color = Color.White, fontSize = 20.sp)
    }
}

/** Small picture, or the first frame of a video with a play mark. */
@Composable
fun MediaThumb(path: String, type: Int, onClick: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { Utils.thumbnail(path, type) }?.asImageBitmap()
    }
    Box(
        Modifier.size(200.dp, 150.dp).clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.25f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (type == 2) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) { Text("▶", color = Color.White, fontSize = 20.sp) }
        }
    }
}

@Composable
fun Bubble(m: MessageEntity, theme: PageTheme, group: Boolean) {
    val ctx = LocalContext.current
    val out = m.outgoing
    val fg = if (out) Color.White else MaterialTheme.colorScheme.onSurface
    val shape = RoundedCornerShape(
        topStart = 18.dp, topEnd = 18.dp,
        bottomStart = if (out) 18.dp else 4.dp, bottomEnd = if (out) 4.dp else 18.dp
    )
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalAlignment = if (out) Alignment.End else Alignment.Start) {
        val bg = if (out) Modifier.background(Brush.linearGradient(theme.accent)) else Modifier.background(MaterialTheme.colorScheme.surface)
        Column(Modifier.widthIn(max = 290.dp).clip(shape).then(bg).padding(10.dp)) {
            if (group && !out) {
                Text(m.senderName, color = theme.accent[0], fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            when (m.kind) {
                0 -> Text(m.text, color = fg)
                1 -> Row(verticalAlignment = Alignment.CenterVertically) {
                    AirButton("▶", if (out) Grey else theme.accent, style = 0) {
                        if (m.path.isNotEmpty() && m.progress == 100) VoicePlayer.play(m.path)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Voice message", color = fg)
                }
                else -> Column {
                    val type = Utils.fileType(m.fileName)
                    val ready = m.path.isNotEmpty() && m.progress == 100
                    if (type != 0 && ready) {
                        MediaThumb(m.path, type) { openFile(ctx, m.path) }
                        Spacer(Modifier.height(4.dp))
                    }
                    Text((if (type == 1) "🖼 " else if (type == 2) "🎬 " else "📎 ") + m.fileName, color = fg, fontWeight = FontWeight.Bold)
                    Text(Utils.sizeText(m.fileSize), color = fg.copy(alpha = 0.7f), fontSize = 12.sp)
                    if (ready) {
                        Row(Modifier.padding(top = 6.dp)) {
                            AirButton("Open", Cyan, small = true) { openFile(ctx, m.path) }
                            Spacer(Modifier.width(8.dp))
                            AirButton("Save", Green, small = true) {
                                Thread {
                                    val ok = Utils.saveToDownloads(ctx, m.path, m.fileName)
                                    Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(ctx, if (ok) "Saved to Downloads" else "Could not save", Toast.LENGTH_SHORT).show()
                                    }
                                }.start()
                            }
                        }
                    }
                }
            }
            if (m.kind > 0 && m.progress in 0..99) {
                LinearProgressIndicator(progress = { m.progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                Text("${m.progress}%", color = fg.copy(alpha = 0.7f), fontSize = 11.sp)
            }
            if (m.progress < 0) Text("Failed", color = Color(0xFFFF6B6B), fontSize = 12.sp)
            Row(Modifier.align(Alignment.End).padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(Utils.stamp(ctx, m.timestamp), color = fg.copy(alpha = 0.7f), fontSize = 10.sp)
                if (out) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (m.status == 0) "✓" else "✓✓",
                        color = if (m.status >= 2) Color(0xFF67E8F9) else fg.copy(alpha = 0.8f),
                        fontSize = 12.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ video call (dark + neon)

@Composable
fun VideoCallScreen(mgr: Manager) {
    val call by mgr.call.collectAsState()
    val frames by mgr.frames.collectAsState()
    val now = rememberNow()
    var front by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    val neonA = listOf(Color(0xFF00F5D4), Color(0xFF00BBF9))
    val neonB = listOf(Color(0xFFFF2E93), Color(0xFFFF6B35))
    val neonC = listOf(Color(0xFFB517FF), Color(0xFF6A5CFF))
    Box(Modifier.fillMaxSize().background(Color(0xFF07070F))) {
        val list = frames.values.toList()
        if (list.isEmpty()) {
            Text("Waiting for video...", color = Color(0xFF00F5D4), modifier = Modifier.align(Alignment.Center))
        } else {
            Column(Modifier.fillMaxSize()) {
                for (rowItems in list.chunked(2)) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        for (b in rowItems) {
                            Image(
                                b.asImageBitmap(), null,
                                Modifier.weight(1f).fillMaxHeight().padding(2.dp), contentScale = ContentScale.Fit
                            )
                        }
                    }
                }
            }
        }
        Text(
            if (call.startedAt > 0) Utils.duration(((now - call.startedAt) / 1000).toInt()) else "Calling...",
            color = Color(0xFF00F5D4), fontWeight = FontWeight.Bold, fontSize = 18.sp,
            modifier = Modifier.align(Alignment.TopStart).padding(16.dp)
        )
        CameraPreview(
            front, { jpeg, rot -> mgr.sendVideo(jpeg, rot) },
            Modifier.align(Alignment.TopEnd).padding(12.dp).size(110.dp, 150.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(2.dp, Brush.linearGradient(neonA), RoundedCornerShape(16.dp))
        )
        Row(Modifier.align(Alignment.BottomCenter).padding(24.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AirButton(if (muted) "🔇" else "🎤", neonC, style = 2) {
                muted = !muted
                mgr.audio.muted = muted
            }
            AirButton("🔄", neonA, style = 2) { front = !front }
            AirButton("End", neonB, style = 2) { mgr.endCall() }
        }
    }
}

// ------------------------------------------------------------------ saved users, history

@Composable
fun UsersScreen(mgr: Manager, back: () -> Unit) {
    val ctx = LocalContext.current
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    val nearby by mgr.nearby.collectAsState()
    PageBox(ToolsTheme) {
        Title("Saved users", back)
        Panel {
            Text("Everyone you connected with once is saved here. If a saved user is hosting nearby, tap Connect (no QR needed).", fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            AirButton("Reconnect over Bluetooth", Cyan, Modifier.fillMaxWidth(), 1) { mgr.connectBtKnown() }
            Spacer(Modifier.height(8.dp))
            AirButton("Clear saved users", Red, Modifier.fillMaxWidth(), 2) {
                mgr.clearUsers()
                Toast.makeText(ctx, "Saved users cleared", Toast.LENGTH_SHORT).show()
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(users, key = { it.id }) { u ->
                Panel(Modifier.padding(bottom = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u.photo, u.name, 44.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(u.name, fontWeight = FontWeight.Bold)
                            Text("Last connected " + Utils.stamp(ctx, u.lastSeen), fontSize = 11.sp)
                        }
                        val n = nearby[u.id]
                        if (n != null) AirButton("Connect", ToolsTheme.accent, style = 1) { mgr.connectNearby(n) }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(mgr: Manager, back: () -> Unit) {
    val ctx = LocalContext.current
    val calls by mgr.callsFlow.collectAsState(initial = emptyList<CallEntity>())
    val files by mgr.transfersFlow.collectAsState(initial = emptyList<MessageEntity>())
    PageBox(ToolsTheme) {
        Title("History", back)
        Text("Kept for 7 days, then deleted automatically.", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            item { Text("Calls", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            items(calls, key = { "c" + it.id }) { c ->
                Panel(Modifier.padding(vertical = 4.dp)) {
                    Text((if (c.video) "📹 " else "📞 ") + (if (c.outgoing) "Outgoing · " else "Incoming · ") + c.peerName, fontWeight = FontWeight.Bold)
                    Text(Utils.stamp(ctx, c.timestamp) + "  ·  " + Utils.duration(c.durationSec), fontSize = 12.sp)
                }
            }
            item { Text("Files and voice messages", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 12.dp)) }
            items(files, key = { "f" + it.id }) { f ->
                Panel(Modifier.padding(vertical = 4.dp)) {
                    Text((if (f.kind == 1) "🎤 " else "📎 ") + (if (f.outgoing) "Sent · " else "Received · ") + f.fileName, fontWeight = FontWeight.Bold)
                    Text(Utils.stamp(ctx, f.timestamp) + "  ·  " + Utils.sizeText(f.fileSize) + (if (f.progress < 0) "  ·  failed" else ""), fontSize = 12.sp)
                }
            }
        }
    }
}
