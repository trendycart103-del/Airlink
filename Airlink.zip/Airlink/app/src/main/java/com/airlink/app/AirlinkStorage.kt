package com.airlink.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileInputStream

/**
 * Everything the "Save Image / Save Full Video / Save File" buttons need.
 * Files go to the root of the phone's main storage:  /sdcard/Airlink/   (Environment.getExternalStorageDirectory()/Airlink)
 *
 * Android 11+ only lets an app create folders in the storage root with the "All files access" permission,
 * so the app asks for it once. Until it is granted the user may choose Download/Airlink instead.
 */
object AirlinkStorage {
    const val FOLDER = "Airlink"

    fun root(): File = File(Environment.getExternalStorageDirectory(), FOLDER)

    /** True on Android 11+ while "All files access" is still missing (the only case where the prompt is needed). */
    fun needsAllFilesPrompt(): Boolean =
        Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()

    /** Opens the system page where the user allows "All files access" for Airlink. */
    fun accessIntent(ctx: Context): Intent {
        val i = if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
        }
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private fun uniqueFile(dir: File, safe: String): File {
        var dst = File(dir, safe)
        val base = safe.substringBeforeLast('.', safe)
        val ext = if (safe.contains('.')) "." + safe.substringAfterLast('.') else ""
        var i = 1
        while (dst.exists()) {
            dst = File(dir, "$base ($i)$ext")
            i++
        }
        return dst
    }

    /** Copies the file into /sdcard/Airlink/. Returns the saved path, or null if it failed. Call from a background thread. */
    fun save(ctx: Context, srcPath: String, name: String): String? {
        return try {
            val src = File(srcPath)
            if (!src.exists()) return null
            if (Build.VERSION.SDK_INT <= 29 &&
                ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) return null
            if (needsAllFilesPrompt()) return null
            val dir = root()
            if (!dir.exists() && !dir.mkdirs()) return null
            val dst = uniqueFile(dir, Utils.safeName(name))
            src.copyTo(dst)
            MediaScannerConnection.scanFile(ctx, arrayOf(dst.absolutePath), null, null)
            dst.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Used only when "All files access" was not granted: saves into Download/Airlink (always allowed).
     * Returns a readable location, or null if it failed.
     */
    fun saveToDownloadsAirlink(ctx: Context, srcPath: String, name: String): String? {
        return try {
            val src = File(srcPath)
            if (!src.exists()) return null
            val safe = Utils.safeName(name)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(src.extension.lowercase()) ?: "application/octet-stream"
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safe)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
                val out = ctx.contentResolver.openOutputStream(uri) ?: return null
                out.use { o -> FileInputStream(src).use { it.copyTo(o) } }
                "Download/$FOLDER/$safe"
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)
                dir.mkdirs()
                val dst = uniqueFile(dir, safe)
                src.copyTo(dst)
                dst.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }
}
