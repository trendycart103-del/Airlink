package com.airlink.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.airlink.app.data.MessageEntity
import com.airlink.app.net.Manager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * The floating call bubble.
 *
 * Visible ONLY when (1) a call is running (talking with someone, call state 2) and (2) the user just left Airlink
 * with Home / Recents (MainActivity.onUserLeaveHint -> Manager.leftApp). A plain connection or chat does not show it.
 * It disappears as soon as Airlink is opened again or the call ends.
 *
 * A round see-through glass bubble. It shows the user's name, any live incoming message text, and one small
 * RED round hang-up button (ends the call and disconnects) - nothing else.
 * Tapping anywhere else on the bubble opens Airlink straight on the ongoing chat. It can be dragged.
 */
class FloatingBubble(private val ctx: Context, private val mgr: Manager, private val scope: CoroutineScope) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dens = ctx.resources.displayMetrics.density
    private fun px(v: Int) = (v * dens).toInt()

    private var root: LinearLayout? = null
    private var rootLp: WindowManager.LayoutParams? = null
    private var msgsTv: TextView? = null
    private var nameTv: TextView? = null

    /** Only messages that arrive while the bubble is up are listed. */
    private var since = 0L

    @OptIn(ExperimentalCoroutinesApi::class)
    fun start() {
        scope.launch {
            // only while a call is really running (talking with someone), never just because a chat is connected
            combine(mgr.session, mgr.online, mgr.leftApp, mgr.appVisible, mgr.call) { s, o, left, visible, c ->
                s.mode != 0 && o.isNotEmpty() && c.state == 2 && left && !visible && Settings.canDrawOverlays(ctx)
            }.distinctUntilChanged().collect { if (it) show() else hide() }
        }
        scope.launch {
            combine(mgr.session, mgr.online) { s, o -> if (s.mode == 2) s.groupId else (o.keys.firstOrNull() ?: "") }
                .distinctUntilChanged()
                .flatMapLatest { c -> if (c.isEmpty()) flowOf(emptyList<MessageEntity>()) else mgr.dao.messages(c) }
                .collect { render(it) }
        }
    }

    fun stop() {
        hide()
    }

    // ------------------------------------------------------------ show / hide

    private fun show() {
        if (root != null) return
        since = System.currentTimeMillis()

        // big, round, see-through "glass" bubble
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(px(18), px(12), px(18), px(12))
        box.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL          // a true round bubble
            setColor(0x8A1E1B4B.toInt())            // light, see-through tint: the screen behind shows through
            setStroke(px(1), 0x88FFFFFF.toInt())
        }

        // the user's name (kept sharp on top of the blurred background)
        val nm = TextView(ctx)
        nm.setTextColor(Color.WHITE)
        nm.textSize = 14f
        nm.typeface = Typeface.DEFAULT_BOLD
        nm.gravity = Gravity.CENTER
        nm.maxLines = 1
        nm.ellipsize = TextUtils.TruncateAt.END
        nm.setShadowLayer(px(3).toFloat(), 0f, px(1).toFloat(), 0xAA000000.toInt())
        box.addView(nm, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // live incoming messages (empty until a message arrives)
        val tv = TextView(ctx)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 11.5f
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setLineSpacing(px(2).toFloat(), 1f)
        tv.setShadowLayer(px(3).toFloat(), 0f, px(1).toFloat(), 0xAA000000.toInt())
        tv.visibility = View.GONE
        box.addView(
            tv,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = px(4) }
        )

        // the one and only control: a small red round button - ends the call and disconnects
        val dc = TextView(ctx)
        dc.text = "✕"
        dc.setTextColor(Color.WHITE)
        dc.textSize = 18f
        dc.typeface = Typeface.DEFAULT_BOLD
        dc.gravity = Gravity.CENTER
        dc.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFFE11D2E.toInt())
        }
        dc.setOnClickListener {
            mgr.stopSession()   // ends the call/chat; the service and this bubble then shut down on their own
        }
        box.addView(
            dc,
            LinearLayout.LayoutParams(px(42), px(42)).apply { topMargin = px(6) }
        )

        val lp = WindowManager.LayoutParams(
            px(146), px(146),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px(12)
            y = px(140)
        }

        // drag anywhere on the body; a plain tap (no drag) opens the chat. The Disconnect button handles its own taps.
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        box.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > px(6) || abs(dy) > px(6)) moved = true
                    if (moved) {
                        val dm = ctx.resources.displayMetrics
                        lp.x = (startX + dx.toInt()).coerceIn(0, (dm.widthPixels - v.width).coerceAtLeast(0))
                        lp.y = (startY + dy.toInt()).coerceIn(0, (dm.heightPixels - v.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (x: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) openChat()
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(box, lp)
        } catch (e: Exception) {
            return
        }
        root = box
        rootLp = lp
        msgsTv = tv
        nameTv = nm
        scope.launch { render(mgr.dao.messagesOnce(currentConv())) }
    }

    private fun hide() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        root = null
        rootLp = null
        msgsTv = null
        nameTv = null
    }

    private fun currentConv(): String {
        val s = mgr.session.value
        return if (s.mode == 2) s.groupId else (mgr.online.value.keys.firstOrNull() ?: "")
    }

    /** Opens Airlink on the ongoing chat history. MainActivity coming to the front hides the bubble again. */
    private fun openChat() {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("open_chat", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ live updates

    private fun render(list: List<MessageEntity>) {
        val tv = msgsTv ?: return
        val s = mgr.session.value
        nameTv?.text = if (s.mode == 2) s.groupName.ifBlank { "Group" } else (mgr.online.value.values.firstOrNull()?.name ?: "")
        val fresh = list.filter { !it.outgoing && it.timestamp >= since }.takeLast(4)
        if (fresh.isEmpty()) {
            tv.visibility = View.GONE
            return
        }
        val sb = StringBuilder()
        for (m in fresh) {
            val body = when (m.kind) {
                0 -> m.text
                1 -> "🎤 Voice message"
                else -> "📎 " + m.fileName
            }
            if (sb.isNotEmpty()) sb.append('\n')
            if (s.mode == 2) sb.append(m.senderName.ifBlank { "Them" }).append(": ")
            sb.append(body)
        }
        tv.text = sb.toString()
        tv.visibility = View.VISIBLE
    }
}
