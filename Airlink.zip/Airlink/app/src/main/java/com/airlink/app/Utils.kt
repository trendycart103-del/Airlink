package com.airlink.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.format.DateFormat
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.Date

object Utils {
    /** Local IPv4 address on the Wi-Fi / hotspot interface. */
    fun localIp(): String? {
        return try {
            val found = ArrayList<Pair<String, String>>()
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        found.add(Pair(ni.name, a.hostAddress ?: ""))
                    }
                }
            }
            // Only Wi-Fi / hotspot interfaces count. Mobile-data addresses (rmnet, ccmni...) can never be reached by the other phone.
            val wifi = found.firstOrNull {
                it.first.startsWith("wlan") || it.first.startsWith("ap") || it.first.startsWith("swlan") ||
                    it.first.startsWith("eth") || it.first.startsWith("p2p")
            }
            val ip = wifi?.second
            if (ip.isNullOrEmpty()) null else ip
        } catch (e: Exception) {
            null
        }
    }

    fun qrBitmap(text: String, size: Int = 640): Bitmap {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bmp.setPixel(x, y, if (m.get(x, y)) Color.BLACK else Color.WHITE)
            }
        }
        return bmp
    }

    /** Date + time in the phone's own default format. */
    fun stamp(ctx: Context, ts: Long): String {
        val d = Date(ts)
        return DateFormat.getDateFormat(ctx).format(d) + " " + DateFormat.getTimeFormat(ctx).format(d)
    }

    fun duration(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

    fun sizeText(b: Long): String = when {
        b < 0 -> ""
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
        b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
        else -> "%.2f GB".format(b / 1073741824.0)
    }

    fun safeName(n: String): String =
        n.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(80).ifBlank { "file" }

    /** Square 160px JPEG for the profile photo. */
    fun profileBytes(ctx: Context, uri: Uri): ByteArray? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 320 && o.outHeight / (s * 2) >= 320) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val side = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val sc = Bitmap.createScaledBitmap(sq, 160, 160, true)
            val out = ByteArrayOutputStream()
            sc.compress(Bitmap.CompressFormat.JPEG, 80, out)
            out.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    /** 0 = other file, 1 = image, 2 = video (judged by the file extension). */
    fun fileType(name: String): Int {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif" -> 1
            "mp4", "mkv", "3gp", "webm", "mov", "avi", "m4v" -> 2
            else -> 0
        }
    }

    /** Small preview: the picture itself, or the first frame of a video. Call from a background thread. */
    fun thumbnail(path: String, type: Int, maxSide: Int = 480): Bitmap? {
        return try {
            val f = File(path)
            if (!f.exists()) return null
            if (type == 2) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(path)
                    val fr = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
                    val sc = maxSide.toFloat() / maxOf(fr.width, fr.height)
                    if (sc < 1f) Bitmap.createScaledBitmap(fr, (fr.width * sc).toInt().coerceAtLeast(1), (fr.height * sc).toInt().coerceAtLeast(1), true) else fr
                } finally {
                    try {
                        r.release()
                    } catch (e: Exception) {
                    }
                }
            } else {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, o)
                var s = 1
                while (o.outWidth / (s * 2) >= maxSide && o.outHeight / (s * 2) >= maxSide) s *= 2
                val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
                val rot = try {
                    when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270
                        else -> 0
                    }
                } catch (e: Exception) {
                    0
                }
                if (rot != 0) Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true) else bmp
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Compact clock time in the phone's own format, e.g. "10:15 AM". */
    fun timeOnly(ctx: Context, ts: Long): String = DateFormat.getTimeFormat(ctx).format(Date(ts))

    /** "Just now", "5 mins ago", "2 hrs ago", "3 days ago". */
    fun lastSeen(now: Long, ts: Long): String {
        val m = ((now - ts) / 60000).coerceAtLeast(0)
        return when {
            m < 1 -> "Just now"
            m == 1L -> "1 min ago"
            m < 60 -> "$m mins ago"
            m < 120 -> "1 hr ago"
            m < 24 * 60 -> "${m / 60} hrs ago"
            m < 48 * 60 -> "1 day ago"
            else -> "${m / (24 * 60)} days ago"
        }
    }

    fun startOfDay(ts: Long): Long {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = ts
        c.set(java.util.Calendar.HOUR_OF_DAY, 0)
        c.set(java.util.Calendar.MINUTE, 0)
        c.set(java.util.Calendar.SECOND, 0)
        c.set(java.util.Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** "Today, 10:15 AM" / "Yesterday, 4:02 PM" / "12/10/2026, 9:30 AM". */
    fun dayTime(ctx: Context, now: Long, ts: Long): String {
        val d0 = startOfDay(now)
        val day = when {
            ts >= d0 -> "Today"
            ts >= d0 - 86_400_000L -> "Yesterday"
            else -> DateFormat.getDateFormat(ctx).format(Date(ts))
        }
        return day + ", " + timeOnly(ctx, ts)
    }
}
