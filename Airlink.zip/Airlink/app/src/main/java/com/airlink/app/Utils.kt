package com.airlink.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.text.format.DateFormat
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.Date

object Utils {
    /** Local IPv4 address on the Wi-Fi / hotspot interface. */
    fun localIp(): String? {
        return try {
            val found = ArrayList<Pair<String, String>>()
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        found.add(Pair(ni.name, a.hostAddress ?: ""))
                    }
                }
            }
            val wifi = found.firstOrNull {
                it.first.startsWith("wlan") || it.first.startsWith("ap") || it.first.startsWith("swlan")
            }
            val ip = (wifi ?: found.firstOrNull())?.second
            if (ip.isNullOrEmpty()) null else ip
        } catch (e: Exception) {
            null
        }
    }

    fun qrBitmap(text: String, size: Int = 640): Bitmap {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bmp.setPixel(x, y, if (m.get(x, y)) Color.BLACK else Color.WHITE)
            }
        }
        return bmp
    }

    /** Date + time in the phone's own default format. */
    fun stamp(ctx: Context, ts: Long): String {
        val d = Date(ts)
        return DateFormat.getDateFormat(ctx).format(d) + " " + DateFormat.getTimeFormat(ctx).format(d)
    }

    fun duration(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

    fun sizeText(b: Long): String = when {
        b < 0 -> ""
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
        b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
        else -> "%.2f GB".format(b / 1073741824.0)
    }

    fun safeName(n: String): String =
        n.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(80).ifBlank { "file" }

    /** Square 160px JPEG for the profile photo. */
    fun profileBytes(ctx: Context, uri: Uri): ByteArray? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 320 && o.outHeight / (s * 2) >= 320) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val side = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val sc = Bitmap.createScaledBitmap(sq, 160, 160, true)
            val out = ByteArrayOutputStream()
            sc.compress(Bitmap.CompressFormat.JPEG, 80, out)
            out.toByteArray()
        } catch (e: Exception) {
            null
        }
    }
}
