package com.airlink.app.net

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/** Live voice: 16 kHz mono PCM, one AudioTrack per remote speaker (so group calls mix naturally). */
class AudioEngine(private val ctx: Context, private val send: (ByteArray) -> Unit) {
    companion object {
        const val RATE = 16000
    }

    @Volatile private var running = false
    @Volatile private var generation = 0
    @Volatile var muted = false
    private val players = ConcurrentHashMap<String, AudioTrack>()

    private fun am(): AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun start() {
        if (running) return
        running = true
        val my = ++generation
        val manager = am()
        manager.mode = AudioManager.MODE_IN_COMMUNICATION
        manager.isSpeakerphoneOn = true
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096)
            )
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            return
        }
        thread(name = "airlink-mic") {
            try {
                rec.startRecording()
                val buf = ByteArray(1280)
                while (running && my == generation) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0 && !muted) {
                        try {
                            send(buf.copyOf(n))
                        } catch (e: Exception) {
                        }
                    }
                }
            } catch (e: Exception) {
            } finally {
                try {
                    rec.stop()
                } catch (e: Exception) {
                }
                rec.release()
            }
        }
    }

    fun play(id: String, data: ByteArray) {
        if (!running) return
        val t = players.getOrPut(id) { createTrack() }
        try {
            t.write(data, 0, data.size, AudioTrack.WRITE_NON_BLOCKING)
        } catch (e: Exception) {
        }
    }

    private fun createTrack(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(min, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.play()
        return t
    }

    fun remove(id: String) {
        players.remove(id)?.let {
            try {
                it.stop()
                it.release()
            } catch (e: Exception) {
            }
        }
    }

    fun stop() {
        running = false
        generation++
        for (t in players.values) {
            try {
                t.stop()
                t.release()
            } catch (e: Exception) {
            }
        }
        players.clear()
        try {
            am().mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) {
        }
    }
}
