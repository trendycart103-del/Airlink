package com.airlink.app.net

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Packet types. */
object T {
    const val HELLO = 1
    const val CHAT = 2
    const val ACK = 3
    const val FSTART = 4
    const val FCHUNK = 5
    const val FEND = 6
    const val AUDIO = 7
    const val VIDEO = 8
    const val CALL = 9
    const val LEAVE = 10
    /** Nearby list: ask a hosting phone for its profile photo (no connection is made). */
    const val PEEK = 11
    /** Subnet sweep: "who are you?" - a hosting phone answers with its id, name, mode and port (works even when UDP broadcast is blocked). */
    const val WHO = 12
}

class Packet(val type: Int, val from: String, val payload: ByteArray)

/** One live connection (Wi-Fi socket or Bluetooth socket). */
class Peer(input: InputStream, output: OutputStream, private val closer: () -> Unit) {
    @Volatile var userId: String = ""
    @Volatile var name: String = ""
    @Volatile var hello: ByteArray = ByteArray(0)

    private val din = DataInputStream(BufferedInputStream(input, 65536))
    private val dout = DataOutputStream(BufferedOutputStream(output, 65536))

    fun write(p: Packet) {
        synchronized(dout) {
            val f = p.from.toByteArray()
            dout.writeByte(p.type)
            dout.writeByte(f.size)
            dout.write(f)
            dout.writeInt(p.payload.size)
            dout.write(p.payload)
            dout.flush()
        }
    }

    fun read(): Packet {
        val t = din.readUnsignedByte()
        val fl = din.readUnsignedByte()
        val fb = ByteArray(fl)
        din.readFully(fb)
        val len = din.readInt()
        if (len < 0 || len > 8_000_000) throw IOException("Bad packet")
        val pl = ByteArray(len)
        din.readFully(pl)
        return Packet(t, String(fb), pl)
    }

    fun close() {
        try {
            closer()
        } catch (e: Exception) {
        }
    }
}
