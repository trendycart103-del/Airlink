package com.airlink.app.ui

import android.graphics.BitmapFactory
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

data class PageTheme(val bg: List<Color>, val accent: List<Color>)

val HomeTheme = PageTheme(
    listOf(Color(0xFF2563EB), Color(0xFF7C3AED), Color(0xFFEC4899), Color(0xFFF59E0B)),
    listOf(Color(0xFF7C3AED), Color(0xFFEC4899))
)
val DirectTheme = PageTheme(
    listOf(Color(0xFF1E3A8A), Color(0xFF4338CA), Color(0xFF7C3AED)),
    listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6))
)
val GroupTheme = PageTheme(
    listOf(Color(0xFFF97316), Color(0xFFEC4899), Color(0xFFBE185D)),
    listOf(Color(0xFFF97316), Color(0xFFEC4899))
)
val ToolsTheme = PageTheme(
    listOf(Color(0xFF0EA5E9), Color(0xFF14B8A6), Color(0xFF6366F1)),
    listOf(Color(0xFF0EA5E9), Color(0xFF6366F1))
)
val Grey = listOf(Color(0xFF6B7280), Color(0xFF4B5563))
val Red = listOf(Color(0xFFEF4444), Color(0xFFF97316))
val Cyan = listOf(Color(0xFF22D3EE), Color(0xFF3B82F6))
val Green = listOf(Color(0xFF22C55E), Color(0xFF14B8A6))

@Composable
fun PageBox(theme: PageTheme, content: @Composable ColumnScope.() -> Unit) {
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(theme.bg))) {
        if (dark) Box(Modifier.fillMaxSize().background(Color(0xC4000000)))
        Column(Modifier.fillMaxSize().padding(12.dp), content = content)
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.93f),
        tonalElevation = 2.dp
    ) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

/** The one button shape used everywhere (copied from the History button): big and small corners, vertical gradient, thin white ring. */
val AirShape = RoundedCornerShape(topStart = 30.dp, bottomEnd = 30.dp, topEnd = 10.dp, bottomStart = 10.dp)
val AirShapeSmall = RoundedCornerShape(topStart = 18.dp, bottomEnd = 18.dp, topEnd = 6.dp, bottomStart = 6.dp)

/** Generic button body with the Airlink look; put anything inside. */
@Composable
fun AirBox(
    colors: List<Color>,
    modifier: Modifier = Modifier,
    small: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.9f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press"
    )
    val shape = if (small) AirShapeSmall else AirShape
    Box(
        modifier
            .scale(scale)
            .shadow(if (enabled) 6.dp else 0.dp, shape, ambientColor = colors[0], spotColor = colors[0])
            .defaultMinSize(minWidth = if (small) 32.dp else 46.dp, minHeight = if (small) 32.dp else 46.dp)
            .background(Brush.verticalGradient(colors), shape)
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), shape)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = if (small) 10.dp else 16.dp, vertical = if (small) 5.dp else 10.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

/** Every normal button in the app. `style` is kept only so old calls still compile; all styles look the same now. */
@Composable
fun AirButton(
    text: String,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") style: Int = 0,
    small: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    AirBox(colors, modifier, small, enabled, onClick) {
        Text(
            text, color = Color.White.copy(alpha = if (enabled) 1f else 0.5f),
            fontWeight = FontWeight.Bold, fontSize = if (small) 12.sp else 15.sp
        )
    }
}

/** Small QR-code icon drawn with a canvas. */
@Composable
fun QrIcon(modifier: Modifier = Modifier.size(24.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val u = size.width / 7f
        fun finder(x: Float, y: Float) {
            drawRect(color, Offset(x * u, y * u), Size(3 * u, 3 * u), style = Stroke(width = u * 0.75f))
            drawRect(color, Offset((x + 1) * u, (y + 1) * u), Size(u, u))
        }
        finder(0f, 0f)
        finder(4f, 0f)
        finder(0f, 4f)
        for (p in listOf(4f to 4f, 6f to 4f, 5f to 5f, 4f to 6f, 6f to 6f)) {
            drawRect(color, Offset(p.first * u, p.second * u), Size(u, u))
        }
    }
}

/**
 * Connectivity logo: signal waves radiating from a dot, with two chain links underneath.
 * No button shape or background; only the drawing itself. Colours come from `colors` (glow gradient).
 */
@Composable
fun LinkSignalIcon(
    modifier: Modifier = Modifier.size(44.dp),
    colors: List<Color> = listOf(Color(0xFF22D3EE), Color(0xFFFFFFFF))
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.075f
        val brush = Brush.linearGradient(
            listOf(colors.first(), colors.last()),
            start = Offset(0f, 0f), end = Offset(w, h)
        )

        // ---- signal: dot + three arcs (upper half of the canvas)
        val cx = w / 2f
        val cy = h * 0.46f
        drawCircle(brush, radius = sw * 1.05f, center = Offset(cx, cy))
        val radii = listOf(w * 0.17f, w * 0.30f, w * 0.43f)
        for ((i, r) in radii.withIndex()) {
            drawArc(
                brush = brush,
                startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - r, cy - r), size = Size(r * 2, r * 2),
                alpha = 1f - i * 0.18f,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
        }

        // ---- chain: two interlocked rounded links (lower part)
        val linkW = w * 0.34f
        val linkH = h * 0.20f
        val top = h * 0.70f
        val leftX = cx - linkW * 0.82f
        val rightX = cx - linkW * 0.18f
        val corner = CornerRadius(linkH / 2f, linkH / 2f)
        drawRoundRect(
            brush, Offset(leftX, top), Size(linkW, linkH), corner,
            style = Stroke(width = sw, join = StrokeJoin.Round)
        )
        drawRoundRect(
            brush, Offset(rightX, top), Size(linkW, linkH), corner,
            style = Stroke(width = sw, join = StrokeJoin.Round)
        )

        // ---- short stem joining the signal dot to the chain
        drawLine(
            brush, Offset(cx, cy + sw * 1.4f), Offset(cx, top - sw * 0.2f),
            strokeWidth = sw, cap = StrokeCap.Round
        )
    }
}

/** Bare white icon/arrow: no background, no shape, just a tappable symbol. */
@Composable
fun PlainIcon(symbol: String, sizeSp: Int = 22, onClick: () -> Unit) {
    Text(
        symbol, color = Color.White, fontSize = sizeSp.sp,
        modifier = Modifier
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    )
}

/**
 * Home-screen button: completely round, fairly solid glass with a soft coloured inner shadow
 * and a bevelled 3D-style gradient border. Presses in when tapped. Label: normal weight, soft, not ALL CAPS.
 */
@Composable
fun CircleGlassButton(
    text: String,
    ring: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.92f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "circle"
    )
    val bevel = Brush.linearGradient(
        listOf(Color.White.copy(alpha = 0.95f), ring[0], ring[1], Color.Black.copy(alpha = 0.45f))
    )
    val fill = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = 0.30f), ring[0].copy(alpha = 0.30f), ring[1].copy(alpha = 0.55f))
    )
    Box(
        modifier
            .scale(scale)
            .shadow(if (pressed) 3.dp else 10.dp, CircleShape, ambientColor = ring[0], spotColor = ring[1])
            .clip(CircleShape)
            .background(fill, CircleShape)
            .border(4.dp, bevel, CircleShape)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 19.sp,
            fontWeight = FontWeight.Light,
            fontFamily = FontFamily.SansSerif,
            letterSpacing = 0.5.sp,
            textAlign = TextAlign.Center,
            style = TextStyle(shadow = Shadow(Color.White.copy(alpha = 0.55f), Offset.Zero, 10f))
        )
    }
}

/** One small white phone (body + coloured screen + home dot), optionally tilted. */
private fun DrawScope.drawPhone(c: Offset, pw: Float, ph: Float, deg: Float, screen: Color) {
    rotate(deg, c) {
        val tl = Offset(c.x - pw / 2f, c.y - ph / 2f)
        drawRoundRect(Color.White, tl, Size(pw, ph), CornerRadius(pw * 0.22f, pw * 0.22f))
        val m = pw * 0.12f
        drawRoundRect(
            screen, Offset(tl.x + m, tl.y + m * 1.8f), Size(pw - 2 * m, ph - m * 3.6f),
            CornerRadius(pw * 0.1f, pw * 0.1f)
        )
        drawCircle(screen, radius = pw * 0.05f, center = Offset(c.x, tl.y + ph - m * 0.9f))
    }
}

/**
 * Drawing for the home tiles. kind 0 = two phones connected to each other (One to One),
 * kind 1 = five phones all connected to a centre phone (Group: many phones can join).
 */
@Composable
fun TileIcon(kind: Int, screen: Color, modifier: Modifier = Modifier.size(78.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.045f
        val link = Color.White.copy(alpha = 0.9f)
        if (kind == 0) {
            val a = Offset(w * 0.24f, w * 0.60f)
            val b = Offset(w * 0.76f, w * 0.60f)
            val pw = w * 0.30f
            val ph = w * 0.50f
            // link between the two phones
            drawLine(link, Offset(a.x + pw * 0.55f, a.y), Offset(b.x - pw * 0.55f, b.y), sw * 1.4f, StrokeCap.Round)
            // signal arcs above the link
            val cx = w * 0.5f
            val cy = w * 0.60f
            drawCircle(Color.White, radius = sw * 1.1f, center = Offset(cx, cy))
            for (i in 1..2) {
                val r = w * 0.10f * i
                drawArc(
                    color = Color.White.copy(alpha = 1f - i * 0.22f),
                    startAngle = 225f, sweepAngle = 90f, useCenter = false,
                    topLeft = Offset(cx - r, cy - r), size = Size(r * 2, r * 2),
                    style = Stroke(width = sw, cap = StrokeCap.Round)
                )
            }
            drawPhone(a, pw, ph, -10f, screen)
            drawPhone(b, pw, ph, 10f, screen)
        } else {
            val hub = Offset(w * 0.5f, w * 0.52f)
            val outer = listOf(
                Offset(w * 0.17f, w * 0.22f), Offset(w * 0.83f, w * 0.22f),
                Offset(w * 0.17f, w * 0.80f), Offset(w * 0.83f, w * 0.80f)
            )
            val pw = w * 0.21f
            val ph = w * 0.34f
            for (o in outer) drawLine(link, hub, o, sw * 1.2f, StrokeCap.Round)
            for (o in outer) drawPhone(o, pw, ph, 0f, screen)
            drawCircle(Color.White.copy(alpha = 0.35f), radius = w * 0.17f, center = hub)
            drawPhone(hub, pw * 1.15f, ph * 1.15f, 0f, screen)
        }
    }
}

/** Small Airlink mark: round gradient badge with the signal + chain symbol. Put it next to anything that comes from Airlink. */
@Composable
fun AirBadge(size: Dp = 26.dp) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6), Color(0xFFEC4899))), CircleShape)
            .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        LinkSignalIcon(Modifier.size(size * 0.7f), listOf(Color.White, Color.White))
    }
}

/** Pencil that points the usual way (tip at the bottom-left), drawn so it never depends on the phone's font. */
@Composable
fun EditIcon(modifier: Modifier = Modifier.size(20.dp)) {
    Canvas(modifier) {
        val w = size.width
        rotate(45f, Offset(w / 2f, w / 2f)) {
            drawRoundRect(Color(0xFFFF6B9D), Offset(w * 0.38f, w * 0.04f), Size(w * 0.24f, w * 0.13f), CornerRadius(w * 0.04f, w * 0.04f))
            drawRect(Color.White, Offset(w * 0.38f, w * 0.17f), Size(w * 0.24f, w * 0.52f))
            val tip = Path().apply {
                moveTo(w * 0.38f, w * 0.69f)
                lineTo(w * 0.62f, w * 0.69f)
                lineTo(w * 0.50f, w * 0.95f)
                close()
            }
            drawPath(tip, Color(0xFFFFD166))
        }
    }
}

/** Small scanner (viewfinder) icon: four corner brackets and a line through the middle. */
@Composable
fun ScanIcon(modifier: Modifier = Modifier.size(30.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.09f
        val a = w * 0.30f
        val e = w - sw / 2f
        val b = sw / 2f
        fun l(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(color, Offset(x1, y1), Offset(x2, y2), sw, StrokeCap.Round)
        l(b, b, b + a, b); l(b, b, b, b + a)
        l(e, b, e - a, b); l(e, b, e, b + a)
        l(b, e, b + a, e); l(b, e, b, e - a)
        l(e, e, e - a, e); l(e, e, e, e - a)
        l(w * 0.22f, w * 0.5f, w * 0.78f, w * 0.5f)
    }
}

/** Download icon: an arrow pointing down into a tray. */
@Composable
fun DownloadIcon(modifier: Modifier = Modifier.size(22.dp), color: Color = Color.White, stroke: Float = 0.17f) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * stroke
        fun l(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(color, Offset(x1, y1), Offset(x2, y2), sw, StrokeCap.Round)
        // arrow shaft + head
        l(w * 0.5f, w * 0.12f, w * 0.5f, w * 0.64f)
        l(w * 0.28f, w * 0.44f, w * 0.5f, w * 0.66f)
        l(w * 0.72f, w * 0.44f, w * 0.5f, w * 0.66f)
        // tray
        l(w * 0.18f, w * 0.88f, w * 0.82f, w * 0.88f)
        l(w * 0.18f, w * 0.72f, w * 0.18f, w * 0.88f)
        l(w * 0.82f, w * 0.72f, w * 0.82f, w * 0.88f)
    }
}

/**
 * Colourful logo of a file format: a glossy rounded square in the colour of the file family, a drawn symbol on top
 * (music notes for audio, a zipper for archives, page lines for everything else) and the format letters (MP3, PDF, ZIP ...) at the bottom.
 */
@Composable
fun FileLogo(fileName: String, size: androidx.compose.ui.unit.Dp = 44.dp) {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    // kind: 0 generic, 1 audio, 2 archive, 3 pdf, 4 document, 5 sheet, 6 slides, 7 apk, 8 code
    val kind = when (ext) {
        "mp3", "m4a", "aac", "wav", "ogg", "oga", "opus", "flac", "amr", "wma", "mid", "midi", "mka", "weba", "aif", "aiff" -> 1
        "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso" -> 2
        "pdf" -> 3
        "doc", "docx", "txt", "rtf", "odt", "md" -> 4
        "xls", "xlsx", "csv", "ods" -> 5
        "ppt", "pptx", "odp" -> 6
        "apk", "xapk", "aab" -> 7
        "json", "xml", "html", "htm", "js", "kt", "java", "py", "c", "cpp", "css", "sh" -> 8
        else -> 0
    }
    val cols = when (kind) {
        1 -> listOf(Color(0xFFFF3D9A), Color(0xFF7C3AED))
        2 -> listOf(Color(0xFFFFB300), Color(0xFFFF6D00))
        3 -> listOf(Color(0xFFFF5252), Color(0xFFC62828))
        4 -> listOf(Color(0xFF42A5F5), Color(0xFF1565C0))
        5 -> listOf(Color(0xFF4ADE80), Color(0xFF15803D))
        6 -> listOf(Color(0xFFFF8A65), Color(0xFFD84315))
        7 -> listOf(Color(0xFF69F0AE), Color(0xFF00A86B))
        8 -> listOf(Color(0xFF2DD4BF), Color(0xFF0F766E))
        else -> listOf(Color(0xFF8B7CFF), Color(0xFF00BBF9))
    }
    val label = if (ext.isEmpty()) "FILE" else ext.uppercase().take(4)
    Box(Modifier.size(size), contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            drawRoundRect(
                brush = Brush.linearGradient(cols, Offset(0f, 0f), Offset(w, w)),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.24f, w * 0.24f)
            )
            // soft shine on the top half
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.35f), Color.Transparent), 0f, w * 0.5f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.24f, w * 0.24f),
                size = androidx.compose.ui.geometry.Size(w, w * 0.5f)
            )
            val white = Color.White
            val sw = w * 0.07f
            fun l(x1: Float, y1: Float, x2: Float, y2: Float, t: Float = sw) =
                drawLine(white, Offset(x1 * w, y1 * w), Offset(x2 * w, y2 * w), t, StrokeCap.Round)
            when (kind) {
                1 -> { // two joined music notes
                    drawCircle(white, w * 0.09f, Offset(w * 0.30f, w * 0.50f))
                    drawCircle(white, w * 0.09f, Offset(w * 0.60f, w * 0.43f))
                    l(0.385f, 0.50f, 0.385f, 0.17f)
                    l(0.685f, 0.43f, 0.685f, 0.11f)
                    l(0.385f, 0.17f, 0.685f, 0.11f, w * 0.09f)
                }
                2 -> { // zipper
                    l(0.5f, 0.08f, 0.5f, 0.50f, w * 0.05f)
                    for (i in 0..3) {
                        val y = 0.12f + i * 0.1f
                        l(if (i % 2 == 0) 0.44f else 0.50f, y, if (i % 2 == 0) 0.50f else 0.56f, y, w * 0.045f)
                    }
                    drawRoundRect(white, Offset(w * 0.43f, w * 0.46f), androidx.compose.ui.geometry.Size(w * 0.14f, w * 0.1f),
                        androidx.compose.ui.geometry.CornerRadius(w * 0.03f, w * 0.03f))
                }
                else -> { // page lines
                    l(0.26f, 0.2f, 0.74f, 0.2f, w * 0.055f)
                    l(0.26f, 0.33f, 0.74f, 0.33f, w * 0.055f)
                    l(0.26f, 0.46f, 0.58f, 0.46f, w * 0.055f)
                }
            }
        }
        Text(
            label, color = Color.White, fontWeight = FontWeight.ExtraBold,
            fontSize = (size.value * 0.2f).sp, maxLines = 1,
            modifier = Modifier.padding(bottom = size * 0.06f)
        )
    }
}

/**
 * Home-screen tile: fully coloured glossy cut-corner button. A drawn icon on top, the name small at the bottom.
 */
@Composable
fun GlassTile(
    title: String,
    ring: List<Color>,
    kind: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.94f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "tile"
    )
    val shape = CutCornerShape(topStart = 38.dp, topEnd = 10.dp, bottomEnd = 38.dp, bottomStart = 10.dp)
    val bevel = Brush.linearGradient(
        listOf(Color.White.copy(alpha = 0.95f), ring[0], ring[1], Color.Black.copy(alpha = 0.35f))
    )
    val fill = Brush.linearGradient(listOf(ring[0], ring[1]))
    Box(
        modifier
            .scale(scale)
            .shadow(if (pressed) 4.dp else 14.dp, shape, ambientColor = ring[0], spotColor = ring[1])
            .clip(shape)
            .background(fill, shape)
            .border(3.dp, bevel, shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
    ) {
        // glossy sheen on the upper part
        Box(
            Modifier.fillMaxWidth().fillMaxHeight(0.42f)
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f), Color.Transparent)))
        )
        Column(
            Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                TileIcon(kind, ring[1], Modifier.fillMaxHeight().aspectRatio(1f))
            }
            Text(
                title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, letterSpacing = 0.4.sp,
                style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.35f), Offset(0f, 2f), 6f))
            )
        }
    }
}

@Composable
fun Avatar(photo: ByteArray?, name: String, size: Dp) {
    val bmp = remember(photo) {
        if (photo == null) null else BitmapFactory.decodeByteArray(photo, 0, photo.size)?.asImageBitmap()
    }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size).clip(CircleShape))
    } else {
        Box(
            Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(HomeTheme.accent)),
            contentAlignment = Alignment.Center
        ) {
            Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value / 2.2f).sp)
        }
    }
}

@Composable
fun rememberNow(): Long {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    return now
}

/** Like rememberNow but only refreshes every 30 s (for "5 mins ago" style labels). */
@Composable
fun rememberMinuteNow(): Long {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }
    return now
}

// ------------------------------------------------------------------ camera frames for video calls

private fun yuvToNv21(image: ImageProxy): ByteArray {
    val w = image.width
    val h = image.height
    val yP = image.planes[0]
    val uP = image.planes[1]
    val vP = image.planes[2]
    val out = ByteArray(w * h * 3 / 2)
    val yb = yP.buffer
    var pos = 0
    for (row in 0 until h) {
        yb.position(row * yP.rowStride)
        yb.get(out, pos, w)
        pos += w
    }
    val ub = uP.buffer
    val vb = vP.buffer
    for (row in 0 until h / 2) {
        for (col in 0 until w / 2) {
            val ui = row * uP.rowStride + col * uP.pixelStride
            val vi = row * vP.rowStride + col * vP.pixelStride
            out[pos++] = vb.get(vi)
            out[pos++] = ub.get(ui)
        }
    }
    return out
}

private class FrameAnalyzer(val onFrame: (ByteArray, Int) -> Unit) : ImageAnalysis.Analyzer {
    private var last = 0L

    override fun analyze(image: ImageProxy) {
        try {
            val now = System.currentTimeMillis()
            if (now - last >= 110) {
                last = now
                val nv21 = yuvToNv21(image)
                val yuv = android.graphics.YuvImage(nv21, android.graphics.ImageFormat.NV21, image.width, image.height, null)
                val out = ByteArrayOutputStream()
                yuv.compressToJpeg(android.graphics.Rect(0, 0, image.width, image.height), 55, out)
                onFrame(out.toByteArray(), image.imageInfo.rotationDegrees)
            }
        } catch (e: Exception) {
        } finally {
            image.close()
        }
    }
}

@Composable
fun CameraPreview(front: Boolean, onFrame: (ByteArray, Int) -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val pv = remember { PreviewView(ctx) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(front) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(android.util.Size(320, 240))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, FrameAnalyzer(onFrame))
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(owner, sel, preview, analysis)
            } catch (e: Exception) {
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            try {
                future.get().unbindAll()
            } catch (e: Exception) {
            }
        }
    }
    AndroidView(factory = { pv }, modifier = modifier)
}
