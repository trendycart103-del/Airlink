package com.airlink.app.ui

import android.graphics.BitmapFactory
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.airlink.app.R
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

data class PageTheme(val bg: List<Color>, val accent: List<Color>)

val HomeTheme = PageTheme(
    listOf(Color(0xFF2563EB), Color(0xFF7C3AED), Color(0xFFEC4899), Color(0xFFF59E0B)),
    listOf(Color(0xFF7C3AED), Color(0xFFEC4899))
)
val DirectTheme = PageTheme(
    listOf(Color(0xFF1E3A8A), Color(0xFF4338CA), Color(0xFF7C3AED)),
    listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6))
)
val GroupTheme = PageTheme(
    listOf(Color(0xFFF97316), Color(0xFFEC4899), Color(0xFFBE185D)),
    listOf(Color(0xFFF97316), Color(0xFFEC4899))
)
val ToolsTheme = PageTheme(
    listOf(Color(0xFF0EA5E9), Color(0xFF14B8A6), Color(0xFF6366F1)),
    listOf(Color(0xFF0EA5E9), Color(0xFF6366F1))
)
val Grey = listOf(Color(0xFF6B7280), Color(0xFF4B5563))
val Red = listOf(Color(0xFFEF4444), Color(0xFFF97316))
val Cyan = listOf(Color(0xFF22D3EE), Color(0xFF3B82F6))
val Green = listOf(Color(0xFF22C55E), Color(0xFF14B8A6))

@Composable
fun PageBox(theme: PageTheme, content: @Composable ColumnScope.() -> Unit) {
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(theme.bg))) {
        if (dark) Box(Modifier.fillMaxSize().background(Color(0x99000000)))
        Column(Modifier.fillMaxSize().padding(12.dp), content = content)
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.93f),
        tonalElevation = 2.dp
    ) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

/** Round button with press-bounce; each style has its own shape and fill. */
@Composable
fun AirButton(
    text: String,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    style: Int = 0,
    pulse: Boolean = false,
    enabled: Boolean = true,
    round: Boolean = false,
    onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.9f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press"
    )
    val inf = rememberInfiniteTransition(label = "pulse")
    val pul by inf.animateFloat(
        1f, if (pulse) 1.06f else 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pul"
    )
    // Every button follows the History button design (shape + gradient + white border).
    // Only the two big round home buttons use the circle shape.
    val shape = if (round) CircleShape
    else RoundedCornerShape(topStart = 30.dp, bottomEnd = 30.dp, topEnd = 10.dp, bottomStart = 10.dp)
    val fill = Modifier
        .background(Brush.verticalGradient(colors), shape)
        .border(1.5.dp, Color.White.copy(alpha = 0.6f), shape)
    Box(
        modifier
            .scale(scale * pul)
            .shadow(if (enabled) 6.dp else 0.dp, shape, ambientColor = colors[0], spotColor = colors[0])
            .defaultMinSize(minWidth = 46.dp, minHeight = 46.dp)
            .then(fill)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White.copy(alpha = if (enabled) 1f else 0.5f), fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** The one Airlink logo, used everywhere: same gradient circle + same speech-bubble mark. */
@Composable
fun AppLogo(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(HomeTheme.accent))
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(size))
    }
}

/** User picture. If the user has no photo, the same Airlink logo is shown. */
@Composable
fun Avatar(photo: ByteArray?, name: String, size: Dp) {
    val bmp = remember(photo) {
        if (photo == null) null else BitmapFactory.decodeByteArray(photo, 0, photo.size)?.asImageBitmap()
    }
    if (bmp != null) {
        Image(
            bmp, null,
            Modifier.size(size).clip(CircleShape).border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape),
            contentScale = ContentScale.Crop
        )
    } else {
        AppLogo(size)
    }
}

@Composable
fun rememberNow(): Long {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    return now
}

// ------------------------------------------------------------------ camera frames for video calls

private fun yuvToNv21(image: ImageProxy): ByteArray {
    val w = image.width
    val h = image.height
    val yP = image.planes[0]
    val uP = image.planes[1]
    val vP = image.planes[2]
    val out = ByteArray(w * h * 3 / 2)
    val yb = yP.buffer
    var pos = 0
    for (row in 0 until h) {
        yb.position(row * yP.rowStride)
        yb.get(out, pos, w)
        pos += w
    }
    val ub = uP.buffer
    val vb = vP.buffer
    for (row in 0 until h / 2) {
        for (col in 0 until w / 2) {
            val ui = row * uP.rowStride + col * uP.pixelStride
            val vi = row * vP.rowStride + col * vP.pixelStride
            out[pos++] = vb.get(vi)
            out[pos++] = ub.get(ui)
        }
    }
    return out
}

private class FrameAnalyzer(val onFrame: (ByteArray, Int) -> Unit) : ImageAnalysis.Analyzer {
    private var last = 0L

    override fun analyze(image: ImageProxy) {
        try {
            val now = System.currentTimeMillis()
            if (now - last >= 110) {
                last = now
                val nv21 = yuvToNv21(image)
                val yuv = android.graphics.YuvImage(nv21, android.graphics.ImageFormat.NV21, image.width, image.height, null)
                val out = ByteArrayOutputStream()
                yuv.compressToJpeg(android.graphics.Rect(0, 0, image.width, image.height), 55, out)
                onFrame(out.toByteArray(), image.imageInfo.rotationDegrees)
            }
        } catch (e: Exception) {
        } finally {
            image.close()
        }
    }
}

@Composable
fun CameraPreview(front: Boolean, onFrame: (ByteArray, Int) -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val pv = remember { PreviewView(ctx) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(front) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(android.util.Size(320, 240))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, FrameAnalyzer(onFrame))
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(owner, sel, preview, analysis)
            } catch (e: Exception) {
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            try {
                future.get().unbindAll()
            } catch (e: Exception) {
            }
        }
    }
    AndroidView(factory = { pv }, modifier = modifier)
}
