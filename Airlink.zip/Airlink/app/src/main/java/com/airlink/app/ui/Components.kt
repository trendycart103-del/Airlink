package com.airlink.app.ui

import android.graphics.BitmapFactory
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

data class PageTheme(val bg: List<Color>, val accent: List<Color>)

val HomeTheme = PageTheme(
    listOf(Color(0xFF2563EB), Color(0xFF7C3AED), Color(0xFFEC4899), Color(0xFFF59E0B)),
    listOf(Color(0xFF7C3AED), Color(0xFFEC4899))
)
val DirectTheme = PageTheme(
    listOf(Color(0xFF1E3A8A), Color(0xFF4338CA), Color(0xFF7C3AED)),
    listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6))
)
val GroupTheme = PageTheme(
    listOf(Color(0xFFF97316), Color(0xFFEC4899), Color(0xFFBE185D)),
    listOf(Color(0xFFF97316), Color(0xFFEC4899))
)
val ToolsTheme = PageTheme(
    listOf(Color(0xFF0EA5E9), Color(0xFF14B8A6), Color(0xFF6366F1)),
    listOf(Color(0xFF0EA5E9), Color(0xFF6366F1))
)
val Grey = listOf(Color(0xFF6B7280), Color(0xFF4B5563))
val Red = listOf(Color(0xFFEF4444), Color(0xFFF97316))
val Cyan = listOf(Color(0xFF22D3EE), Color(0xFF3B82F6))
val Green = listOf(Color(0xFF22C55E), Color(0xFF14B8A6))

@Composable
fun PageBox(theme: PageTheme, content: @Composable ColumnScope.() -> Unit) {
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(theme.bg))) {
        if (dark) Box(Modifier.fillMaxSize().background(Color(0x99000000)))
        Column(Modifier.fillMaxSize().padding(12.dp), content = content)
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.93f),
        tonalElevation = 2.dp
    ) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

/** The one button shape used everywhere (copied from the History button): big and small corners, vertical gradient, thin white ring. */
val AirShape = RoundedCornerShape(topStart = 30.dp, bottomEnd = 30.dp, topEnd = 10.dp, bottomStart = 10.dp)
val AirShapeSmall = RoundedCornerShape(topStart = 18.dp, bottomEnd = 18.dp, topEnd = 6.dp, bottomStart = 6.dp)

/** Generic button body with the Airlink look; put anything inside. */
@Composable
fun AirBox(
    colors: List<Color>,
    modifier: Modifier = Modifier,
    small: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.9f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press"
    )
    val shape = if (small) AirShapeSmall else AirShape
    Box(
        modifier
            .scale(scale)
            .shadow(if (enabled) 6.dp else 0.dp, shape, ambientColor = colors[0], spotColor = colors[0])
            .defaultMinSize(minWidth = if (small) 32.dp else 46.dp, minHeight = if (small) 32.dp else 46.dp)
            .background(Brush.verticalGradient(colors), shape)
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), shape)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = if (small) 10.dp else 16.dp, vertical = if (small) 5.dp else 10.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

/** Every normal button in the app. `style` is kept only so old calls still compile; all styles look the same now. */
@Composable
fun AirButton(
    text: String,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") style: Int = 0,
    small: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    AirBox(colors, modifier, small, enabled, onClick) {
        Text(
            text, color = Color.White.copy(alpha = if (enabled) 1f else 0.5f),
            fontWeight = FontWeight.Bold, fontSize = if (small) 12.sp else 15.sp
        )
    }
}

/** Small QR-code icon drawn with a canvas. */
@Composable
fun QrIcon(modifier: Modifier = Modifier.size(24.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val u = size.width / 7f
        fun finder(x: Float, y: Float) {
            drawRect(color, Offset(x * u, y * u), Size(3 * u, 3 * u), style = Stroke(width = u * 0.75f))
            drawRect(color, Offset((x + 1) * u, (y + 1) * u), Size(u, u))
        }
        finder(0f, 0f)
        finder(4f, 0f)
        finder(0f, 4f)
        for (p in listOf(4f to 4f, 6f to 4f, 5f to 5f, 4f to 6f, 6f to 6f)) {
            drawRect(color, Offset(p.first * u, p.second * u), Size(u, u))
        }
    }
}

/**
 * Connectivity logo: signal waves radiating from a dot, with two chain links underneath.
 * No button shape or background; only the drawing itself. Colours come from `colors` (glow gradient).
 */
@Composable
fun LinkSignalIcon(
    modifier: Modifier = Modifier.size(44.dp),
    colors: List<Color> = listOf(Color(0xFF22D3EE), Color(0xFFFFFFFF))
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.075f
        val brush = Brush.linearGradient(
            listOf(colors.first(), colors.last()),
            start = Offset(0f, 0f), end = Offset(w, h)
        )

        // ---- signal: dot + three arcs (upper half of the canvas)
        val cx = w / 2f
        val cy = h * 0.46f
        drawCircle(brush, radius = sw * 1.05f, center = Offset(cx, cy))
        val radii = listOf(w * 0.17f, w * 0.30f, w * 0.43f)
        for ((i, r) in radii.withIndex()) {
            drawArc(
                brush = brush,
                startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - r, cy - r), size = Size(r * 2, r * 2),
                alpha = 1f - i * 0.18f,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
        }

        // ---- chain: two interlocked rounded links (lower part)
        val linkW = w * 0.34f
        val linkH = h * 0.20f
        val top = h * 0.70f
        val leftX = cx - linkW * 0.82f
        val rightX = cx - linkW * 0.18f
        val corner = CornerRadius(linkH / 2f, linkH / 2f)
        drawRoundRect(
            brush, Offset(leftX, top), Size(linkW, linkH), corner,
            style = Stroke(width = sw, join = StrokeJoin.Round)
        )
        drawRoundRect(
            brush, Offset(rightX, top), Size(linkW, linkH), corner,
            style = Stroke(width = sw, join = StrokeJoin.Round)
        )

        // ---- short stem joining the signal dot to the chain
        drawLine(
            brush, Offset(cx, cy + sw * 1.4f), Offset(cx, top - sw * 0.2f),
            strokeWidth = sw, cap = StrokeCap.Round
        )
    }
}

/** Bare white icon/arrow: no background, no shape, just a tappable symbol. */
@Composable
fun PlainIcon(symbol: String, sizeSp: Int = 22, onClick: () -> Unit) {
    Text(
        symbol, color = Color.White, fontSize = sizeSp.sp,
        modifier = Modifier
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    )
}

/**
 * Home-screen button: completely round, fairly solid glass with a soft coloured inner shadow
 * and a bevelled 3D-style gradient border. Presses in when tapped. Label: normal weight, soft, not ALL CAPS.
 */
@Composable
fun CircleGlassButton(
    text: String,
    ring: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.92f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "circle"
    )
    val bevel = Brush.linearGradient(
        listOf(Color.White.copy(alpha = 0.95f), ring[0], ring[1], Color.Black.copy(alpha = 0.45f))
    )
    val fill = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = 0.30f), ring[0].copy(alpha = 0.30f), ring[1].copy(alpha = 0.55f))
    )
    Box(
        modifier
            .scale(scale)
            .shadow(if (pressed) 3.dp else 10.dp, CircleShape, ambientColor = ring[0], spotColor = ring[1])
            .clip(CircleShape)
            .background(fill, CircleShape)
            .border(4.dp, bevel, CircleShape)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 19.sp,
            fontWeight = FontWeight.Light,
            fontFamily = FontFamily.SansSerif,
            letterSpacing = 0.5.sp,
            textAlign = TextAlign.Center,
            style = TextStyle(shadow = Shadow(Color.White.copy(alpha = 0.55f), Offset.Zero, 10f))
        )
    }
}

/** Small white drawing for the home tiles: kind 0 = two linked phones, 1 = three linked phones (group). */
@Composable
fun TileIcon(kind: Int, modifier: Modifier = Modifier.size(54.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.07f
        val c = Color.White
        val nodes = if (kind == 0) {
            listOf(Offset(w * 0.18f, h * 0.5f), Offset(w * 0.82f, h * 0.5f))
        } else {
            listOf(Offset(w * 0.5f, h * 0.18f), Offset(w * 0.16f, h * 0.78f), Offset(w * 0.84f, h * 0.78f))
        }
        // links between the nodes
        for (i in nodes.indices) {
            for (j in i + 1 until nodes.size) {
                drawLine(c.copy(alpha = 0.85f), nodes[i], nodes[j], sw, StrokeCap.Round)
            }
        }
        // soft ring + solid dot for every node
        for (n in nodes) {
            drawCircle(c.copy(alpha = 0.35f), radius = w * 0.17f, center = n, style = Stroke(sw * 0.8f))
            drawCircle(c, radius = w * 0.09f, center = n)
        }
        // signal pulse in the middle
        val mid = Offset(nodes.map { it.x }.average().toFloat(), nodes.map { it.y }.average().toFloat())
        drawCircle(c, radius = w * 0.05f, center = mid)
        drawCircle(c.copy(alpha = 0.4f), radius = w * 0.11f, center = mid, style = Stroke(sw * 0.7f))
    }
}

/**
 * Home-screen tile: a cut-corner glass shape (big cuts top-left / bottom-right, small cuts on the other two),
 * glossy top sheen, bevelled gradient border, a drawn icon, a title and a small subtitle. Presses in when tapped.
 */
@Composable
fun GlassTile(
    title: String,
    subtitle: String,
    ring: List<Color>,
    kind: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.94f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "tile"
    )
    val shape = CutCornerShape(topStart = 38.dp, topEnd = 10.dp, bottomEnd = 38.dp, bottomStart = 10.dp)
    val bevel = Brush.linearGradient(
        listOf(Color.White.copy(alpha = 0.95f), ring[0], ring[1], Color.Black.copy(alpha = 0.4f))
    )
    val fill = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = 0.26f), ring[0].copy(alpha = 0.38f), ring[1].copy(alpha = 0.65f))
    )
    Box(
        modifier
            .scale(scale)
            .shadow(if (pressed) 4.dp else 14.dp, shape, ambientColor = ring[0], spotColor = ring[1])
            .clip(shape)
            .background(fill, shape)
            .border(3.dp, bevel, shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
    ) {
        // glossy sheen on the upper part
        Box(
            Modifier.fillMaxWidth().fillMaxHeight(0.42f)
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.32f), Color.Transparent)))
        )
        Column(
            Modifier.fillMaxSize().padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            TileIcon(kind, Modifier.size(54.dp))
            Spacer(Modifier.height(8.dp))
            Text(
                title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, letterSpacing = 0.4.sp,
                style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.35f), Offset(0f, 3f), 8f))
            )
            Text(
                subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun Avatar(photo: ByteArray?, name: String, size: Dp) {
    val bmp = remember(photo) {
        if (photo == null) null else BitmapFactory.decodeByteArray(photo, 0, photo.size)?.asImageBitmap()
    }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size).clip(CircleShape))
    } else {
        Box(
            Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(HomeTheme.accent)),
            contentAlignment = Alignment.Center
        ) {
            Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value / 2.2f).sp)
        }
    }
}

@Composable
fun rememberNow(): Long {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    return now
}

/** Like rememberNow but only refreshes every 30 s (for "5 mins ago" style labels). */
@Composable
fun rememberMinuteNow(): Long {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }
    return now
}

// ------------------------------------------------------------------ camera frames for video calls

private fun yuvToNv21(image: ImageProxy): ByteArray {
    val w = image.width
    val h = image.height
    val yP = image.planes[0]
    val uP = image.planes[1]
    val vP = image.planes[2]
    val out = ByteArray(w * h * 3 / 2)
    val yb = yP.buffer
    var pos = 0
    for (row in 0 until h) {
        yb.position(row * yP.rowStride)
        yb.get(out, pos, w)
        pos += w
    }
    val ub = uP.buffer
    val vb = vP.buffer
    for (row in 0 until h / 2) {
        for (col in 0 until w / 2) {
            val ui = row * uP.rowStride + col * uP.pixelStride
            val vi = row * vP.rowStride + col * vP.pixelStride
            out[pos++] = vb.get(vi)
            out[pos++] = ub.get(ui)
        }
    }
    return out
}

private class FrameAnalyzer(val onFrame: (ByteArray, Int) -> Unit) : ImageAnalysis.Analyzer {
    private var last = 0L

    override fun analyze(image: ImageProxy) {
        try {
            val now = System.currentTimeMillis()
            if (now - last >= 110) {
                last = now
                val nv21 = yuvToNv21(image)
                val yuv = android.graphics.YuvImage(nv21, android.graphics.ImageFormat.NV21, image.width, image.height, null)
                val out = ByteArrayOutputStream()
                yuv.compressToJpeg(android.graphics.Rect(0, 0, image.width, image.height), 55, out)
                onFrame(out.toByteArray(), image.imageInfo.rotationDegrees)
            }
        } catch (e: Exception) {
        } finally {
            image.close()
        }
    }
}

@Composable
fun CameraPreview(front: Boolean, onFrame: (ByteArray, Int) -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val pv = remember { PreviewView(ctx) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(front) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(android.util.Size(320, 240))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, FrameAnalyzer(onFrame))
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(owner, sel, preview, analysis)
            } catch (e: Exception) {
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            try {
                future.get().unbindAll()
            } catch (e: Exception) {
            }
        }
    }
    AndroidView(factory = { pv }, modifier = modifier)
}
