package com.airlink.app

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import com.journeyapps.barcodescanner.CaptureManager
import com.journeyapps.barcodescanner.DecoratedBarcodeView

/**
 * Small portrait QR scanner shown as a floating card over the app,
 * instead of the library's full-screen landscape CaptureActivity.
 */
class ScanActivity : Activity() {
    private lateinit var capture: CaptureManager
    private lateinit var barcodeView: DecoratedBarcodeView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)

        // Card size: ~90% of screen width, ~55% of screen height
        val dm = resources.displayMetrics
        window.setLayout((dm.widthPixels * 0.9f).toInt(), (dm.heightPixels * 0.55f).toInt())
        window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setDimAmount(0.6f)

        barcodeView = findViewById(R.id.zxing_barcode_scanner)
        findViewById<TextView>(R.id.scan_close).setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }

        capture = CaptureManager(this, barcodeView)
        capture.initializeFromIntent(intent, savedInstanceState)
        capture.decode()
    }

    override fun onResume() { super.onResume(); capture.onResume() }
    override fun onPause() { super.onPause(); capture.onPause() }
    override fun onDestroy() { super.onDestroy(); capture.onDestroy() }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        capture.onSaveInstanceState(outState)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        capture.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}
