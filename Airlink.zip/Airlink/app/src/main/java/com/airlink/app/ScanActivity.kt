package com.airlink.app

import android.app.Activity
import android.os.Bundle
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import com.journeyapps.barcodescanner.CaptureManager
import com.journeyapps.barcodescanner.DecoratedBarcodeView

/**
 * Small portrait QR scanner shown as a floating card over the app,
 * instead of the library's full-screen landscape CaptureActivity.
 */
class ScanActivity : Activity() {
    private lateinit var capture: CaptureManager
    private lateinit var barcodeView: DecoratedBarcodeView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)

        // Small portrait card in the middle of a see-through screen: ~72% of the width, a bit taller than wide
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.72f).toInt()
        val h = minOf((w * 1.25f).toInt(), (dm.heightPixels * 0.5f).toInt())
        val card = findViewById<FrameLayout>(R.id.scan_card)
        card.layoutParams = (card.layoutParams as FrameLayout.LayoutParams).apply {
            width = w
            height = h
            gravity = Gravity.CENTER
        }
        card.background = GradientDrawable().apply {
            setColor(0xFF000000.toInt())
            cornerRadius = 22f * dm.density
        }
        card.clipToOutline = true

        barcodeView = findViewById(R.id.zxing_barcode_scanner)
        findViewById<TextView>(R.id.scan_close).setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }

        capture = CaptureManager(this, barcodeView)
        capture.initializeFromIntent(intent, savedInstanceState)
        capture.decode()
    }

    override fun onResume() { super.onResume(); capture.onResume() }
    override fun onPause() { super.onPause(); capture.onPause() }
    override fun onDestroy() { super.onDestroy(); capture.onDestroy() }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        capture.onSaveInstanceState(outState)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        capture.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}
