package com.airlink.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import kotlinx.coroutines.flow.update
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.airlink.app.net.Manager
import com.airlink.app.ui.AirButton
import com.airlink.app.ui.Avatar
import com.airlink.app.ui.DirectTheme
import com.airlink.app.ui.GroupTheme
import com.airlink.app.ui.Grey
import com.airlink.app.ui.Green
import com.airlink.app.ui.HistoryScreen
import com.airlink.app.ui.HomeScreen
import com.airlink.app.ui.ModePage
import com.airlink.app.ui.Scr
import com.airlink.app.ui.UsersScreen
import com.airlink.app.ui.VideoCallScreen

class MainActivity : ComponentActivity() {
    private var permsDone = false
    private var overlayDismissed = false
    private val overlayAsk = mutableStateOf(false)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            permsDone = true
            refreshOverlay()
        }

    private fun refreshOverlay() {
        overlayAsk.value = permsDone && !overlayDismissed && !Settings.canDrawOverlays(this)
    }

    private fun handleIntent(i: Intent?) {
        val k = i?.getIntExtra("open_settings", -1) ?: -1
        if (k >= 0) {
            i?.removeExtra("open_settings")
            (application as AirlinkApp).manager.internalLaunch = true
            if (k == 1) Utils.openHotspotSettings(this) else Utils.openWifiSettings(this)
        }
        if (i?.getBooleanExtra("open_chat", false) == true) {
            (application as AirlinkApp).manager.openChatTick.update { it + 1 }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Home / Recents pressed: the only moment the floating bubble is allowed to appear (and only if a chat is connected). */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val m = (application as AirlinkApp).manager
        if (m.internalLaunch) {
            m.internalLaunch = false
        } else {
            m.leftApp.value = true
        }
    }

    override fun onStart() {
        super.onStart()
        (application as AirlinkApp).manager.setVisible(true)
    }

    override fun onStop() {
        (application as AirlinkApp).manager.setVisible(false)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        (application as AirlinkApp).manager.internalLaunch = false
        refreshOverlay()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = ArrayList<String>()
        perms.add(Manifest.permission.RECORD_AUDIO)
        perms.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 31) perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 29) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        permLauncher.launch(perms.toTypedArray())

        val mgr = (application as AirlinkApp).manager
        handleIntent(intent)
        setContent {
            AirApp(
                mgr, overlayAsk.value,
                onAllow = {
                    mgr.internalLaunch = true
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    overlayAsk.value = false
                },
                onLater = {
                    overlayDismissed = true
                    overlayAsk.value = false
                }
            )
        }
    }
}

@Composable
fun AirApp(mgr: Manager, askOverlay: Boolean, onAllow: () -> Unit, onLater: () -> Unit) {
    val me by mgr.me.collectAsState()
    val call by mgr.call.collectAsState()
    val tick by mgr.openChatTick.collectAsState()
    val notice by mgr.notice.collectAsState()
    val pair by mgr.pairRequest.collectAsState()
    val ctx = LocalContext.current
    var scr by remember { mutableStateOf(Scr.HOME) }

    LaunchedEffect(notice) {
        if (notice.isNotEmpty()) {
            Toast.makeText(ctx, notice, Toast.LENGTH_LONG).show()
            mgr.notice.value = ""
        }
    }

    LaunchedEffect(tick) {
        if (tick > 0) scr = if (mgr.session.value.mode == 2) Scr.GROUP else Scr.DIRECT
    }

    MaterialTheme(colorScheme = if (me.dark || isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Box(Modifier.fillMaxSize()) {
            BackHandler(enabled = scr != Scr.HOME) { scr = Scr.HOME }
            when (scr) {
                Scr.HOME -> HomeScreen(mgr) { scr = it }
                Scr.DIRECT -> ModePage(mgr, 1, DirectTheme, "One to One") { scr = Scr.HOME }
                Scr.GROUP -> ModePage(mgr, 2, GroupTheme, "Group") { scr = Scr.HOME }
                Scr.USERS -> UsersScreen(mgr) { scr = Scr.HOME }
                Scr.HISTORY -> HistoryScreen(mgr) { scr = Scr.HOME }
            }
            if (call.state == 2 && call.video) VideoCallScreen(mgr)
            if (askOverlay) {
                AlertDialog(
                    onDismissRequest = onLater,
                    title = { Text("Floating chat bubble") },
                    text = {
                        Text("Allow \"Display over other apps\" so the Airlink bubble can float above any screen while you are chatting or in a call.")
                    },
                    confirmButton = { AirButton("Allow", Green, style = 1, onClick = onAllow) },
                    dismissButton = { AirButton("Later", Grey, style = 2, onClick = onLater) }
                )
            }
            pair?.let { pr ->
                AlertDialog(
                    onDismissRequest = { mgr.answerPair(false) },
                    title = { Text("Connection request") },
                    text = {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Avatar(pr.photo, pr.name, 48.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(pr.name + " wants to connect with you")
                        }
                    },
                    confirmButton = { AirButton("Confirm", Green, style = 1) { mgr.answerPair(true) } },
                    dismissButton = { AirButton("Decline", Grey, style = 2) { mgr.answerPair(false) } }
                )
            }
            if (call.state == 1) {
                AlertDialog(
                    onDismissRequest = { },
                    title = { Text("Incoming " + (if (call.video) "video" else "voice") + " call") },
                    text = { Text(call.who.ifBlank { "Someone" } + " is calling you") },
                    confirmButton = { AirButton("Accept", Green, style = 1) { mgr.acceptCall() } },
                    dismissButton = { AirButton("Reject", Grey, style = 2) { mgr.rejectCall() } }
                )
            }
        }
    }
}
