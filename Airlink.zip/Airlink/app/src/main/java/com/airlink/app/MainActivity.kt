package com.airlink.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.airlink.app.net.Manager
import com.airlink.app.ui.AirButton
import com.airlink.app.ui.DirectTheme
import com.airlink.app.ui.GroupTheme
import com.airlink.app.ui.Grey
import com.airlink.app.ui.Green
import com.airlink.app.ui.HistoryScreen
import com.airlink.app.ui.HomeScreen
import com.airlink.app.ui.ModePage
import com.airlink.app.ui.Scr
import com.airlink.app.ui.UsersScreen
import com.airlink.app.ui.VideoCallScreen

class MainActivity : ComponentActivity() {
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = ArrayList<String>()
        perms.add(Manifest.permission.RECORD_AUDIO)
        perms.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 31) perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        permLauncher.launch(perms.toTypedArray())

        val mgr = (application as AirlinkApp).manager
        setContent { AirApp(mgr) }
    }
}

@Composable
fun AirApp(mgr: Manager) {
    val me by mgr.me.collectAsState()
    val call by mgr.call.collectAsState()
    val notice by mgr.notice.collectAsState()
    val ctx = LocalContext.current
    var scr by remember { mutableStateOf(Scr.HOME) }

    LaunchedEffect(notice) {
        if (notice.isNotEmpty()) {
            Toast.makeText(ctx, notice, Toast.LENGTH_LONG).show()
            mgr.notice.value = ""
        }
    }

    MaterialTheme(colorScheme = if (me.dark || isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Box(Modifier.fillMaxSize()) {
            BackHandler(enabled = scr != Scr.HOME) { scr = Scr.HOME }
            when (scr) {
                Scr.HOME -> HomeScreen(mgr) { scr = it }
                Scr.DIRECT -> ModePage(mgr, 1, DirectTheme, "Direct") { scr = Scr.HOME }
                Scr.GROUP -> ModePage(mgr, 2, GroupTheme, "Group") { scr = Scr.HOME }
                Scr.USERS -> UsersScreen(mgr) { scr = Scr.HOME }
                Scr.HISTORY -> HistoryScreen(mgr) { scr = Scr.HOME }
            }
            if (call.state == 2 && call.video) VideoCallScreen(mgr)
            if (call.state == 1) {
                AlertDialog(
                    onDismissRequest = { },
                    title = { Text("Incoming " + (if (call.video) "video" else "voice") + " call") },
                    text = { Text(call.who.ifBlank { "Someone" } + " is calling you") },
                    confirmButton = { AirButton("Accept", Green, style = 1, pulse = true) { mgr.acceptCall() } },
                    dismissButton = { AirButton("Reject", Grey, style = 2) { mgr.rejectCall() } }
                )
            }
        }
    }
}
