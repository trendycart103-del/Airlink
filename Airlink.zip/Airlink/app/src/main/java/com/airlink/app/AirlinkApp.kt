package com.airlink.app

import android.app.Application
import com.airlink.app.data.AppDb
import com.airlink.app.net.Manager

class AirlinkApp : Application() {
    lateinit var manager: Manager

    override fun onCreate() {
        super.onCreate()
        manager = Manager(this, AppDb.build(this))
        manager.startDiscovery()
        manager.startPurge()
    }
}
