package com.airlink.app

import android.app.Application
import com.airlink.app.data.AppDb
import com.airlink.app.net.Manager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class AirlinkApp : Application() {
    lateinit var manager: Manager

    override fun onCreate() {
        super.onCreate()
        manager = Manager(this, AppDb.build(this))
        manager.startDiscovery()
        manager.startPurge()

        // Keep the app alive in the background (and show the floating bubble) while a session exists.
        CoroutineScope(SupervisorJob() + Dispatchers.Main).launch {
            manager.session.map { it.mode != 0 }.distinctUntilChanged().collect { on ->
                try {
                    if (on) AirlinkService.start(this@AirlinkApp) else AirlinkService.stop(this@AirlinkApp)
                } catch (e: Exception) {
                }
            }
        }
    }
}
