package com.airlink.app.net

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.provider.OpenableColumns
import android.util.Base64
import com.airlink.app.Utils
import com.airlink.app.data.AppDb
import com.airlink.app.data.CallEntity
import com.airlink.app.data.MessageEntity
import com.airlink.app.data.UserEntity
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlin.random.Random

data class Me(val id: String, val name: String, val photo: ByteArray?, val dark: Boolean)

/** mode: 0 none, 1 direct, 2 group. */
data class Session(
    val mode: Int = 0,
    val bt: Boolean = false,
    val host: Boolean = false,
    val groupId: String = "",
    val groupName: String = "",
    val qr: String = "",
    val status: String = ""
)

/** state: 0 idle, 1 ringing (incoming), 2 in call. startedAt = 0 while still calling. */
data class CallInfo(
    val state: Int = 0,
    val video: Boolean = false,
    val who: String = "",
    val startedAt: Long = 0,
    val outgoing: Boolean = false
)

/** Someone without the QR key is asking to connect; this phone must tap Confirm. */
data class PairRequest(val name: String, val photo: ByteArray?)

data class Nearby(val id: String, val name: String, val ip: String, val port: Int, val mode: Int, val seen: Long)

private class Incoming(
    val out: OutputStream,
    val size: Long,
    val msgId: String,
    val conv: String,
    val sender: String,
    var got: Long = 0,
    var lastPct: Int = -1
)

class Manager(private val ctx: Context, val db: AppDb) {
    companion object {
        val BT_UUID: UUID = UUID.fromString("7d2c9a54-3b1e-4f60-9a8e-0a17c0de1111")
        const val MAX_GROUP = 6
        const val MAX_VIDEO = 4
        const val BEACON_PORT = 45455
    }

    val dao = db.dao()
    val usersFlow = dao.users()
    val callsFlow = dao.calls()
    val transfersFlow = dao.transfers()
    fun messagesSince(t: Long) = dao.messagesSince(t)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs = ctx.getSharedPreferences("airlink", Context.MODE_PRIVATE)

    val me = MutableStateFlow(loadMe())
    val session = MutableStateFlow(Session())
    val online = MutableStateFlow<Map<String, UserEntity>>(emptyMap())
    val notice = MutableStateFlow("")
    val nearby = MutableStateFlow<Map<String, Nearby>>(emptyMap())
    val call = MutableStateFlow(CallInfo())
    val frames = MutableStateFlow<Map<String, Bitmap>>(emptyMap())
    val activeConv = MutableStateFlow("")
    /** True while the Airlink screen is on top; the floating bubble only shows when it is false. */
    val appVisible = MutableStateFlow(true)
    /** True after the user left Airlink (Home / Recents, via onUserLeaveHint) and has not come back yet. The bubble needs this AND a live connection. */
    val leftApp = MutableStateFlow(false)
    /** Set right before Airlink itself opens another screen (file picker, QR scanner, settings) so that trip does not count as "leaving the app". */
    @Volatile var internalLaunch = false
    /** Bumped when the bubble asks the app to open the current chat. */
    val openChatTick = MutableStateFlow(0)
    /** Non-null while another phone waits for this phone's Confirm / Decline. */
    val pairRequest = MutableStateFlow<PairRequest?>(null)
    private var pairDecision: CompletableDeferred<Boolean>? = null
    private var hiddenConv = ""

    private val peers = CopyOnWriteArrayList<Peer>()
    private val incoming = ConcurrentHashMap<String, Incoming>()
    private val gen = AtomicInteger()
    private var token = ""
    private var server: Closeable? = null
    private var beaconJob: Job? = null

    val audio = AudioEngine(ctx) { data -> sendPacket(Packet(T.AUDIO, me.value.id, data)) }

    // ---------------------------------------------------------------- profile

    private fun loadMe(): Me {
        var id = prefs.getString("id", null)
        if (id == null) {
            id = UUID.randomUUID().toString()
            prefs.edit().putString("id", id).apply()
        }
        val name = prefs.getString("name", null)
            ?: phoneName().ifBlank { "User" + (1000 + Random.nextInt(9000)) }
        val f = File(ctx.filesDir, "me.jpg")
        return Me(id, name, if (f.exists()) f.readBytes() else null, prefs.getBoolean("dark", false))
    }

    /** The phone's own name (Settings > About phone > Device name), or its model, kept short. */
    private fun phoneName(): String {
        val raw = try {
            Settings.Global.getString(ctx.contentResolver, "device_name")
        } catch (e: Exception) {
            null
        }
        val n = if (!raw.isNullOrBlank()) raw else (Build.MODEL ?: "")
        return n.trim().take(16)
    }

    fun setName(n: String) {
        val t = n.trim().take(24)
        if (t.isEmpty()) return
        prefs.edit().putString("name", t).apply()
        me.update { it.copy(name = t) }
    }

    fun setPhoto(b: ByteArray) {
        File(ctx.filesDir, "me.jpg").writeBytes(b)
        me.update { it.copy(photo = b) }
    }

    fun setDark(d: Boolean) {
        prefs.edit().putBoolean("dark", d).apply()
        me.update { it.copy(dark = d) }
    }

    // ---------------------------------------------------------------- housekeeping (7 days, fixed)

    fun startPurge() {
        scope.launch {
            while (true) {
                try {
                    purgeOld()
                } catch (e: Exception) {
                }
                delay(3_600_000L)
            }
        }
    }

    private suspend fun purgeOld() {
        val cut = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        for (m in dao.oldMessages(cut)) if (m.path.isNotEmpty()) File(m.path).delete()
        dao.deleteOldMessages(cut)
        dao.deleteOldCalls(cut)
    }

    /** Clears only one conversation (one user or one group). */
    fun clearConversation(conv: String) {
        if (conv.isEmpty()) return
        scope.launch {
            for (m in dao.convMessages(conv)) if (m.path.isNotEmpty()) File(m.path).delete()
            dao.clearConv(conv)
        }
    }

    fun clearUsers() {
        scope.launch { dao.clearUsers() }
    }

    // ---------------------------------------------------------------- discovery (UDP beacons on Wi-Fi)

    fun startDiscovery() {
        scope.launch {
            while (true) {
                var s: DatagramSocket? = null
                try {
                    val sock = DatagramSocket(null)
                    s = sock
                    sock.reuseAddress = true
                    sock.bind(InetSocketAddress(BEACON_PORT))
                    sock.soTimeout = 3000
                    val buf = ByteArray(512)
                    while (true) {
                        try {
                            val pk = DatagramPacket(buf, buf.size)
                            sock.receive(pk)
                            val parts = String(pk.data, 0, pk.length).split("|")
                            if (parts.size >= 5 && parts[0] == "AIRLINK" && parts[3] != me.value.id) {
                                val n = Nearby(
                                    parts[3], parts[4], pk.address.hostAddress ?: "",
                                    parts[2].toInt(), parts[1].toInt(), System.currentTimeMillis()
                                )
                                nearby.update { it + (n.id to n) }
                            }
                        } catch (e: SocketTimeoutException) {
                        } catch (e: NumberFormatException) {
                        }
                        val cut = System.currentTimeMillis() - 8000
                        nearby.update { m -> m.filterValues { it.seen > cut } }
                    }
                } catch (e: Exception) {
                    delay(3000)
                } finally {
                    s?.close()
                }
            }
        }
    }

    private fun startBeacon(ip: String, port: Int, mode: Int) {
        beaconJob?.cancel()
        beaconJob = scope.launch {
            var s: DatagramSocket? = null
            try {
                val sock = DatagramSocket()
                s = sock
                sock.broadcast = true
                val subnet = ip.substringBeforeLast('.') + ".255"
                while (isActive) {
                    val msg = "AIRLINK|$mode|$port|${me.value.id}|${me.value.name.replace("|", " ")}".toByteArray()
                    for (target in listOf("255.255.255.255", subnet)) {
                        try {
                            sock.send(DatagramPacket(msg, msg.size, InetAddress.getByName(target), BEACON_PORT))
                        } catch (e: Exception) {
                        }
                    }
                    delay(2000)
                }
            } catch (e: Exception) {
            } finally {
                s?.close()
            }
        }
    }

    // ---------------------------------------------------------------- session control

    private fun btAdapter(): BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun qrText(mode: Int, t: String, ip: String, port: Int, gid: String, gn: String): String =
        "airlink://join?m=$mode&t=$t&ip=$ip&p=$port&k=$token&g=${Uri.encode(gid)}&gn=${Uri.encode(gn)}"

    fun answerPair(ok: Boolean) {
        pairDecision?.complete(ok)
        pairRequest.value = null
    }

    private suspend fun askPair(name: String, photo: ByteArray?): Boolean {
        pairDecision?.complete(false)
        val d = CompletableDeferred<Boolean>()
        pairDecision = d
        val req = PairRequest(name.ifBlank { "A phone" }, photo)
        pairRequest.value = req
        val ok = withTimeoutOrNull(30_000L) { d.await() } ?: false
        if (pairRequest.value === req) pairRequest.value = null
        return ok
    }

    /**
     * Makes this phone visible to the other Airlink phones around (Wi-Fi / hotspot) while the connect screen is open.
     * Does nothing (and shows no message) if there is no Wi-Fi / hotspot yet or a session already exists.
     */
    fun startVisible() {
        if (session.value.mode != 0) return
        if (Utils.localIp() == null) return
        startHost(1, false, "")
    }

    fun stopSession() {
        gen.incrementAndGet()
        pairDecision?.complete(false)
        pairRequest.value = null
        beaconJob?.cancel()
        beaconJob = null
        if (call.value.state != 0) endCall(false)
        val oldServer = server
        server = null
        val old = peers.toList()
        peers.clear()
        online.value = emptyMap()
        session.value = Session()
        scope.launch {
            try {
                oldServer?.close()
            } catch (e: Exception) {
            }
            for (p in old) p.close()
        }
    }

    /** Show my QR and wait for others. mode 1 = direct, 2 = group. */
    fun startHost(mode: Int, bt: Boolean, groupName: String) {
        stopSession()
        val my = gen.get()
        token = UUID.randomUUID().toString().take(8)
        val gid = if (mode == 2) UUID.randomUUID().toString() else ""
        val gn = if (mode == 2) groupName.trim().ifBlank { "Airlink group" } else ""
        scope.launch {
            try {
                if (bt) {
                    val ad = btAdapter() ?: throw IOException("Bluetooth is not available")
                    if (!ad.isEnabled) throw IOException("Please turn Bluetooth on")
                    val ss = ad.listenUsingInsecureRfcommWithServiceRecord("Airlink", BT_UUID)
                    server = ss
                    session.value = Session(mode, true, true, gid, gn, qrText(mode, "b", "", 0, gid, gn), "Waiting for the other phone...")
                    while (true) {
                        val sock = ss.accept()
                        launch {
                            hostHandshake(Peer(sock.inputStream, sock.outputStream) { sock.close() })
                        }
                    }
                } else {
                    val ip = Utils.localIp() ?: throw IOException("Turn on your hotspot (or join the same Wi-Fi) first")
                    val ss = ServerSocket(0)
                    server = ss
                    session.value = Session(mode, false, true, gid, gn, qrText(mode, "w", ip, ss.localPort, gid, gn), "Waiting for the other phone...")
                    startBeacon(ip, ss.localPort, mode)
                    while (true) {
                        val sock = ss.accept()
                        sock.tcpNoDelay = true
                        launch {
                            hostHandshake(Peer(sock.getInputStream(), sock.getOutputStream()) { sock.close() })
                        }
                    }
                }
            } catch (e: Exception) {
                if (my == gen.get()) {
                    notice.value = e.message ?: "Could not start"
                    session.value = Session()
                }
            }
        }
    }

    fun joinFromQr(text: String) {
        val u = try {
            Uri.parse(text)
        } catch (e: Exception) {
            null
        }
        if (u == null || u.scheme != "airlink") {
            notice.value = "This is not an Airlink QR code"
            return
        }
        connectTo(
            u.getQueryParameter("t") == "b",
            u.getQueryParameter("ip") ?: "",
            u.getQueryParameter("p")?.toIntOrNull() ?: 0,
            u.getQueryParameter("k") ?: "",
            u.getQueryParameter("m")?.toIntOrNull() ?: 1,
            u.getQueryParameter("g") ?: "",
            u.getQueryParameter("gn") ?: ""
        )
    }

    /** Reconnect to a saved user whose phone is announcing itself on Wi-Fi (no QR needed). */
    fun connectNearby(n: Nearby) = connectTo(false, n.ip, n.port, "", n.mode, "", "")

    /** Reconnect over Bluetooth to a paired, saved user that is hosting. */
    fun connectBtKnown() = connectTo(true, "", 0, "", 1, "", "")

    private fun connectTo(bt: Boolean, ip: String, port: Int, tok: String, mode: Int, gid: String, gn: String) {
        stopSession()
        val my = gen.get()
        token = tok
        session.value = Session(
            mode, bt, false, gid, gn, "",
            if (tok.isEmpty() && !bt) "Waiting for the other phone to confirm..." else "Connecting..."
        )
        scope.launch {
            try {
                val (peer, first) = if (bt) connectBt() else connectWifi(ip, port)
                if (first.type != T.HELLO) throw IOException("Unexpected reply")
                val j = JSONObject(String(first.payload))
                session.value = session.value.copy(
                    mode = j.optInt("mode", mode), groupId = j.optString("g"),
                    groupName = j.optString("gn"), status = "Connected"
                )
                peer.userId = first.from
                peer.name = j.optString("name")
                peer.hello = first.payload
                peers.add(peer)
                handleHello(first)
                readLoop(peer)
            } catch (e: Exception) {
                if (my == gen.get()) {
                    notice.value = if (tok.isEmpty() && e is java.io.EOFException) {
                        "The other phone did not accept the connection"
                    } else {
                        "Could not connect: " + (e.message ?: "the other phone refused or is not ready")
                    }
                    session.value = Session()
                }
            }
        }
    }

    private fun connectWifi(ip: String, port: Int): Pair<Peer, Packet> {
        if (Utils.localIp() == null) {
            throw IOException("This phone is not on Wi-Fi. Turn Wi-Fi ON and join the other phone's hotspot, then scan again")
        }
        val s = Socket()
        try {
            s.tcpNoDelay = true
            try {
                s.connect(InetSocketAddress(ip, port), 8000)
            } catch (e: java.net.SocketTimeoutException) {
                throw IOException("Both phones must be on the same Wi-Fi or hotspot (mobile data cannot connect them)")
            }
            val p = Peer(s.getInputStream(), s.getOutputStream()) { s.close() }
            p.write(helloPacket())
            return Pair(p, p.read())
        } catch (e: Exception) {
            try {
                s.close()
            } catch (x: Exception) {
            }
            throw e
        }
    }

    private fun connectBt(): Pair<Peer, Packet> {
        val ad = btAdapter() ?: throw IOException("Bluetooth is not available")
        if (!ad.isEnabled) throw IOException("Please turn Bluetooth on")
        ad.cancelDiscovery()
        val devices = ad.bondedDevices.toList()
        if (devices.isEmpty()) throw IOException("Pair the two phones in Bluetooth settings first")
        for (d in devices) {
            try {
                val s = d.createInsecureRfcommSocketToServiceRecord(BT_UUID)
                try {
                    s.connect()
                    val p = Peer(s.inputStream, s.outputStream) { s.close() }
                    p.write(helloPacket())
                    return Pair(p, p.read())
                } catch (e: Exception) {
                    try {
                        s.close()
                    } catch (x: Exception) {
                    }
                }
            } catch (e: Exception) {
            }
        }
        throw IOException("No paired phone is hosting Airlink right now")
    }

    private fun helloPacket(): Packet {
        val m = me.value
        val s = session.value
        val photo = m.photo
        val j = JSONObject()
            .put("name", m.name)
            .put("tok", if (s.host) "" else token)
            .put("mode", s.mode)
            .put("g", s.groupId)
            .put("gn", s.groupName)
            .put("photo", if (photo != null) Base64.encodeToString(photo, Base64.NO_WRAP) else "")
        return Packet(T.HELLO, m.id, j.toString().toByteArray())
    }

    private suspend fun hostHandshake(peer: Peer) {
        try {
            val first = peer.read()
            if (first.type != T.HELLO) {
                peer.close()
                return
            }
            val j = JSONObject(String(first.payload))
            // A valid QR key already is the owner's consent. Anyone else (nearby search, saved user) must be confirmed on this phone.
            val keyOk = token.isNotEmpty() && j.optString("tok") == token
            if (!keyOk) {
                val ph = j.optString("photo")
                val photo = if (ph.isEmpty()) null else try {
                    Base64.decode(ph, Base64.NO_WRAP)
                } catch (e: Exception) {
                    null
                }
                if (!askPair(j.optString("name"), photo)) {
                    peer.close()
                    return
                }
            }
            for (stale in peers.filter { it.userId == first.from }) {
                peers.remove(stale)
                stale.close()
            }
            val s = session.value
            val max = if (s.mode == 2) MAX_GROUP - 1 else 1
            if (peers.size >= max) {
                peer.close()
                return
            }
            peer.userId = first.from
            peer.name = j.optString("name")
            peer.hello = first.payload
            peer.write(helloPacket())
            for (o in peers) peer.write(Packet(T.HELLO, o.userId, o.hello))
            for (o in peers) safeWrite(o, Packet(T.HELLO, peer.userId, peer.hello))
            peers.add(peer)
            handleHello(first)
            session.value = session.value.copy(status = "Connected")
        } catch (e: Exception) {
            peer.close()
            return
        }
        readLoop(peer)
    }

    private suspend fun handleHello(p: Packet) {
        val j = JSONObject(String(p.payload))
        val ph = j.optString("photo")
        val photo = if (ph.isEmpty()) null else try {
            Base64.decode(ph, Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
        val u = UserEntity(p.from, j.optString("name", "User"), photo, System.currentTimeMillis())
        dao.upsertUser(u)
        online.update { it + (u.id to u) }
    }

    private suspend fun readLoop(peer: Peer) {
        try {
            while (true) {
                val p = peer.read()
                onPacket(peer, p)
            }
        } catch (e: Exception) {
        } finally {
            dropPeer(peer)
        }
    }

    private fun dropPeer(peer: Peer) {
        if (!peers.remove(peer)) {
            peer.close()
            return
        }
        peer.close()
        if (peer.userId.isNotEmpty()) {
            val uid = peer.userId
            scope.launch { dao.touchUser(uid, System.currentTimeMillis()) }
        }
        if (call.value.state != 0 && (session.value.mode == 1 || !session.value.host)) endCall(false)
        val s = session.value
        if (s.host) {
            online.update { it - peer.userId }
            audio.remove(peer.userId)
            frames.update { it - peer.userId }
            if (s.mode == 2) {
                val lp = Packet(T.LEAVE, peer.userId, ByteArray(0))
                for (o in peers) safeWrite(o, lp)
            }
        } else {
            online.value = emptyMap()
            notice.value = "Disconnected"
            session.value = Session()
        }
    }

    // ---------------------------------------------------------------- sending helpers

    fun sendPacket(p: Packet) {
        for (x in peers) safeWrite(x, p)
    }

    private fun safeWrite(x: Peer, p: Packet) {
        try {
            x.write(p)
        } catch (e: Exception) {
            x.close()
        }
    }

    fun currentConv(): String {
        val s = session.value
        return if (s.mode == 2) s.groupId else (peers.firstOrNull()?.userId ?: "")
    }

    private fun sendAck(to: String, id: String, st: Int) {
        val j = JSONObject().put("id", id).put("st", st).put("to", to)
        val pk = Packet(T.ACK, me.value.id, j.toString().toByteArray())
        val s = session.value
        val targets = if (s.host && s.mode == 2) peers.filter { it.userId == to } else peers.toList()
        for (x in targets) safeWrite(x, pk)
    }

    // ---------------------------------------------------------------- receiving

    private suspend fun onPacket(peer: Peer, p: Packet) {
        val s = session.value
        if (s.host && s.mode == 2) {
            if (p.type == T.ACK) {
                val to = try {
                    JSONObject(String(p.payload)).optString("to")
                } catch (e: Exception) {
                    ""
                }
                if (to != me.value.id) {
                    peers.firstOrNull { it.userId == to }?.let { safeWrite(it, p) }
                    return
                }
            } else if (p.type != T.HELLO) {
                for (o in peers) if (o !== peer) safeWrite(o, p)
            }
        }
        when (p.type) {
            T.HELLO -> handleHello(p)
            T.LEAVE -> {
                online.update { it - p.from }
                audio.remove(p.from)
                frames.update { it - p.from }
            }
            T.CHAT -> onChat(p)
            T.ACK -> {
                val j = JSONObject(String(p.payload))
                dao.setStatus(j.getString("id"), j.getInt("st"))
            }
            T.FSTART -> onFileStart(p)
            T.FCHUNK -> onFileChunk(p)
            T.FEND -> onFileEnd(p)
            T.AUDIO -> if (call.value.state == 2) audio.play(p.from, p.payload)
            T.VIDEO -> onVideo(p)
            T.CALL -> onCall(p)
        }
    }

    private suspend fun onChat(p: Packet) {
        val j = JSONObject(String(p.payload))
        val s = session.value
        val conv = if (s.mode == 2) s.groupId else p.from
        val seen = activeConv.value == conv
        val id = j.getString("id")
        dao.upsertMessage(
            MessageEntity(
                id, conv, p.from, j.optString("name"), 0, j.optString("text"), "", "", 0,
                false, if (seen) 2 else 1, 100, System.currentTimeMillis()
            )
        )
        sendAck(p.from, id, if (seen) 2 else 1)
    }

    private suspend fun onFileStart(p: Packet) {
        val j = JSONObject(String(p.payload))
        val fid = j.getString("fid")
        val name = Utils.safeName(j.optString("name", "file"))
        val size = j.optLong("size", -1)
        val dir = File(ctx.filesDir, "received")
        dir.mkdirs()
        val f = File(dir, fid.take(8) + "_" + name)
        val s = session.value
        val conv = if (s.mode == 2) s.groupId else p.from
        val msgId = j.getString("id")
        dao.upsertMessage(
            MessageEntity(
                msgId, conv, p.from, j.optString("sname"), j.optInt("kind", 2), "", f.absolutePath,
                name, size, false, 1, 0, System.currentTimeMillis()
            )
        )
        incoming[fid] = Incoming(FileOutputStream(f), size, msgId, conv, p.from)
    }

    private suspend fun onFileChunk(p: Packet) {
        if (p.payload.size < 36) return
        val fid = String(p.payload, 0, 36)
        val inc = incoming[fid] ?: return
        try {
            inc.out.write(p.payload, 36, p.payload.size - 36)
        } catch (e: Exception) {
            incoming.remove(fid)
            return
        }
        inc.got += (p.payload.size - 36).toLong()
        val pct = if (inc.size > 0) (inc.got * 100 / inc.size).toInt().coerceIn(0, 99) else 0
        if (pct >= inc.lastPct + 2) {
            inc.lastPct = pct
            dao.setProgress(inc.msgId, pct)
        }
    }

    private suspend fun onFileEnd(p: Packet) {
        val fid = String(p.payload)
        val inc = incoming.remove(fid) ?: return
        try {
            inc.out.close()
        } catch (e: Exception) {
        }
        dao.setProgress(inc.msgId, 100)
        val st = if (activeConv.value == inc.conv) 2 else 1
        if (st == 2) dao.setStatus(inc.msgId, 2)
        sendAck(inc.sender, inc.msgId, st)
    }

    private fun onVideo(p: Packet) {
        val c = call.value
        if (c.state != 2 || !c.video || p.payload.size < 2) return
        val rot = p.payload[0].toInt() * 90
        val bmp = BitmapFactory.decodeByteArray(p.payload, 1, p.payload.size - 1) ?: return
        val out = if (rot != 0) {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
        } else bmp
        frames.update { it + (p.from to out) }
    }

    // ---------------------------------------------------------------- chat / files / voice messages

    fun setVisible(v: Boolean) {
        appVisible.value = v
        if (v) leftApp.value = false
        if (!v) {
            hiddenConv = activeConv.value
            activeConv.value = ""
        } else {
            val c = hiddenConv
            hiddenConv = ""
            if (c.isNotEmpty()) setActive(c)
        }
    }

    fun setActive(conv: String) {
        activeConv.value = conv
        if (conv.isEmpty()) return
        scope.launch {
            for (m in dao.unseen(conv)) {
                dao.setStatus(m.id, 2)
                sendAck(m.senderId, m.id, 2)
            }
        }
    }

    fun sendText(text: String) {
        scope.launch {
            val conv = currentConv()
            if (conv.isEmpty() || peers.isEmpty()) {
                notice.value = "Not connected"
                return@launch
            }
            val m = me.value
            val id = UUID.randomUUID().toString()
            val ts = System.currentTimeMillis()
            dao.upsertMessage(MessageEntity(id, conv, m.id, m.name, 0, text, "", "", 0, true, 0, 100, ts))
            val j = JSONObject().put("id", id).put("text", text).put("ts", ts).put("name", m.name)
            sendPacket(Packet(T.CHAT, m.id, j.toString().toByteArray()))
        }
    }

    fun sendUri(uri: Uri) {
        scope.launch {
            var name = "file"
            var size = -1L
            try {
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: "file"
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
            } catch (e: Exception) {
            }
            val dir = File(ctx.filesDir, "sent")
            dir.mkdirs()
            val copy = File(dir, UUID.randomUUID().toString().take(8) + "_" + Utils.safeName(name))
            sendStream(name, size, 2, copy.absolutePath, copy) {
                ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open file")
            }
        }
    }

    fun sendVoice(f: File) {
        scope.launch { sendStream(f.name, f.length(), 1, f.absolutePath) { FileInputStream(f) } }
    }

    private suspend fun sendStream(
        name: String, size: Long, kind: Int, path: String, copyTo: File? = null, open: () -> InputStream
    ) {
        val conv = currentConv()
        if (conv.isEmpty() || peers.isEmpty()) {
            notice.value = "Not connected"
            return
        }
        val m = me.value
        val fid = UUID.randomUUID().toString()
        val id = UUID.randomUUID().toString()
        dao.upsertMessage(MessageEntity(id, conv, m.id, m.name, kind, "", path, name, size, true, 0, 0, System.currentTimeMillis()))
        try {
            val hdr = JSONObject().put("fid", fid).put("id", id).put("name", name)
                .put("size", size).put("kind", kind).put("sname", m.name)
            sendPacket(Packet(T.FSTART, m.id, hdr.toString().toByteArray()))
            val copyOut = copyTo?.let { FileOutputStream(it) }
            try {
                open().use { ins ->
                val buf = ByteArray(32 * 1024)
                val fb = fid.toByteArray()
                var sent = 0L
                var last = -1
                while (true) {
                    if (peers.isEmpty()) throw IOException("Disconnected")
                    val n = ins.read(buf)
                    if (n < 0) break
                    val pl = ByteArray(36 + n)
                    System.arraycopy(fb, 0, pl, 0, 36)
                    System.arraycopy(buf, 0, pl, 36, n)
                    copyOut?.write(buf, 0, n)
                    sendPacket(Packet(T.FCHUNK, m.id, pl))
                    sent += n
                    if (size > 0) {
                        val pct = (sent * 100 / size).toInt().coerceIn(0, 99)
                        if (pct >= last + 2) {
                            last = pct
                            dao.setProgress(id, pct)
                        }
                    }
                }
                }
            } finally {
                try {
                    copyOut?.close()
                } catch (e: Exception) {
                }
            }
            sendPacket(Packet(T.FEND, m.id, fid.toByteArray()))
            dao.setProgress(id, 100)
        } catch (e: Exception) {
            dao.setProgress(id, -1)
            notice.value = "File transfer failed"
        }
    }

    // ---------------------------------------------------------------- calls

    private fun sendCtl(a: String, video: Boolean = false) {
        val j = JSONObject().put("a", a).put("v", video).put("name", me.value.name)
        sendPacket(Packet(T.CALL, me.value.id, j.toString().toByteArray()))
    }

    fun startCall(video: Boolean) {
        if (call.value.state != 0 || peers.isEmpty()) return
        val s = session.value
        if (video && s.bt) {
            notice.value = "Video calls need Wi-Fi (Bluetooth cannot carry video)"
            return
        }
        if (video && s.mode == 2 && peers.size + 1 > MAX_VIDEO && !s.host) {
            notice.value = "Group video is limited to $MAX_VIDEO phones"
            return
        }
        if (video && s.mode == 2 && s.host && peers.size + 1 > MAX_VIDEO) {
            notice.value = "Group video is limited to $MAX_VIDEO phones"
            return
        }
        call.value = CallInfo(2, video, "", if (s.mode == 2) System.currentTimeMillis() else 0L, true)
        audio.start()
        scope.launch { sendCtl("invite", video) }
    }

    fun acceptCall() {
        val c = call.value
        if (c.state != 1) return
        if (c.video && session.value.bt) {
            rejectCall()
            return
        }
        call.value = c.copy(state = 2, startedAt = System.currentTimeMillis())
        audio.start()
        scope.launch { sendCtl("accept") }
    }

    fun rejectCall() {
        call.value = CallInfo()
        scope.launch { sendCtl("end") }
    }

    fun endCall(notify: Boolean = true) {
        val c = call.value
        if (c.state == 0) return
        call.value = CallInfo()
        audio.stop()
        frames.value = emptyMap()
        if (c.state == 2 && c.startedAt > 0) {
            val dur = ((System.currentTimeMillis() - c.startedAt) / 1000).toInt()
            val conv = currentConv()
            val s = session.value
            val who = if (s.mode == 2) s.groupName else (online.value.values.firstOrNull()?.name ?: "Call")
            scope.launch { dao.insertCall(CallEntity(0, conv, who, c.video, c.outgoing, c.startedAt, dur)) }
        }
        if (notify) scope.launch { sendCtl("end") }
    }

    private fun onCall(p: Packet) {
        val j = JSONObject(String(p.payload))
        val s = session.value
        when (j.optString("a")) {
            "invite" -> if (call.value.state == 0) {
                call.value = CallInfo(1, j.optBoolean("v"), j.optString("name"), 0, false)
            }
            "accept" -> {
                val c = call.value
                if (s.mode == 1 && c.state == 2 && c.startedAt == 0L) {
                    call.value = c.copy(startedAt = System.currentTimeMillis())
                }
            }
            "end" -> {
                if (s.mode == 1 || call.value.state == 1) {
                    endCall(false)
                } else {
                    audio.remove(p.from)
                    frames.update { it - p.from }
                }
            }
        }
    }

    fun sendVideo(jpeg: ByteArray, rotation: Int) {
        if (call.value.state != 2) return
        val pl = byteArrayOf((rotation / 90).toByte()) + jpeg
        sendPacket(Packet(T.VIDEO, me.value.id, pl))
    }
}
