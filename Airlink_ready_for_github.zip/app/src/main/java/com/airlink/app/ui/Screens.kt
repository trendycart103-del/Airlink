package com.airlink.app.ui

import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.draw.shadow
import androidx.core.content.FileProvider
import android.widget.MediaController
import android.widget.VideoView
import com.airlink.app.AirlinkStorage
import com.airlink.app.R
import com.airlink.app.Utils
import com.airlink.app.data.CallEntity
import com.airlink.app.data.MessageEntity
import com.airlink.app.data.UserEntity
import com.airlink.app.net.Manager
import com.airlink.app.net.Nearby
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

enum class Scr { HOME, DIRECT, GROUP, USERS, HISTORY }

// ------------------------------------------------------------------ helpers

object VoicePlayer {
    private var mp: MediaPlayer? = null

    fun play(path: String) {
        try {
            mp?.release()
            val m = MediaPlayer()
            m.setDataSource(path)
            m.setOnCompletionListener {
                it.release()
                if (mp === it) mp = null
            }
            m.prepare()
            m.start()
            mp = m
        } catch (e: Exception) {
        }
    }
}

class VoiceRec(private val ctx: android.content.Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start(): Boolean {
        return try {
            val dir = File(ctx.filesDir, "voice")
            dir.mkdirs()
            val f = File(dir, "v_" + System.currentTimeMillis() + ".m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            true
        } catch (e: Exception) {
            false
        }
    }

    fun stop(): File? {
        val r = rec ?: return null
        rec = null
        return try {
            r.stop()
            r.release()
            file
        } catch (e: Exception) {
            try {
                r.release()
            } catch (x: Exception) {
            }
            null
        }
    }
}

fun openFile(ctx: android.content.Context, path: String) {
    try {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun Title(text: String, back: (() -> Unit)?, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) {
            PlainIcon("←", 26, onClick = back)
            Spacer(Modifier.width(10.dp))
        }
        Text(text, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        if (trailing != null) trailing()
    }
}

// ------------------------------------------------------------------ home

@Composable
fun HomeScreen(mgr: Manager, go: (Scr) -> Unit) {
    val me by mgr.me.collectAsState()
    var editing by remember { mutableStateOf(false) }
    // tap the photo: the settings gear shows up (and hides again after a few seconds); nothing else is shown
    var showGear by remember { mutableStateOf(false) }
    LaunchedEffect(showGear) {
        if (showGear) {
            delay(4000)
            showGear = false
        }
    }
    PageBox(HomeTheme) {
        Spacer(Modifier.height(16.dp))
        // photo at the left, the short bold name right under it; the settings gear appears at the photo's top-right only after a tap on the photo
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
            Box {
                Box(
                    Modifier.padding(top = 8.dp, end = 8.dp).clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        indication = null
                    ) { showGear = !showGear }
                ) { Avatar(me.photo, me.name, 88.dp) }
                if (showGear) {
                    Box(
                        Modifier.align(Alignment.TopEnd).size(30.dp).background(Color.White, CircleShape)
                            .clickable(
                                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                indication = null
                            ) { editing = true },
                        contentAlignment = Alignment.Center
                    ) { SettingsIcon(Modifier.size(18.dp)) }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                me.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp,
                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 220.dp)
            )
        }
        Spacer(Modifier.weight(1f))
        Image(
            painterResource(R.drawable.ic_launcher_foreground), null,
            Modifier.size(170.dp).align(Alignment.CenterHorizontally)
        )
        Text(
            "Airlink", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Text(
            "Chat, call and share files with no internet",
            color = Color.White.copy(alpha = 0.85f), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Spacer(Modifier.weight(0.8f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            GlassTile("One to One", DirectTheme.accent, 0, Modifier.weight(1f).aspectRatio(1f)) { go(Scr.DIRECT) }
            GlassTile("Group", GroupTheme.accent, 1, Modifier.weight(1f).aspectRatio(1f)) { go(Scr.GROUP) }
        }
        Spacer(Modifier.weight(1.2f))
        Row(Modifier.fillMaxWidth()) {
            AirButton("Saved users", Green, Modifier.weight(1f), 2) { go(Scr.USERS) }
            Spacer(Modifier.width(10.dp))
            AirButton("History", Cyan, Modifier.weight(1f), 3) { go(Scr.HISTORY) }
        }
        Spacer(Modifier.height(8.dp))
    }
    if (editing) EditProfileDialog(mgr) { editing = false }
}

@Composable
fun EditProfileDialog(mgr: Manager, close: () -> Unit) {
    val ctx = LocalContext.current
    val me by mgr.me.collectAsState()
    var name by remember { mutableStateOf(me.name) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val b = Utils.profileBytes(ctx, u)
            if (b != null) mgr.setPhoto(b)
        }
    }
    val ringName by mgr.ringtoneName.collectAsState()
    val pickRing = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) mgr.setRingtone(u)
    }
    DisposableEffect(Unit) { onDispose { mgr.stopRing() } }
    AlertDialog(
        onDismissRequest = { mgr.stopRing(); close() },
        title = { Text("Edit profile") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(me.photo, me.name, 72.dp)
                    Spacer(Modifier.width(12.dp))
                    AirButton("Change photo", HomeTheme.accent, style = 1) { pickPhoto.launch(arrayOf("image/*")) }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(24); mgr.setName(it) },
                    label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                Text("Ringtone", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(if (ringName == "Default") "Phone's own ringtone" else ringName, fontSize = 13.sp, maxLines = 1)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AirButton("Play", Cyan, style = 2, small = true) { mgr.startRing(false) }
                    AirButton("Choose", HomeTheme.accent, style = 1, small = true) {
                        mgr.internalLaunch = true
                        pickRing.launch(arrayOf("audio/*"))
                    }
                    if (ringName != "Default") AirButton("Default", Grey, style = 2, small = true) { mgr.resetRingtone() }
                }
            }
        },
        confirmButton = { AirButton("Done", Green, style = 1) { mgr.stopRing(); close() } }
    )
}

// ------------------------------------------------------------------ direct (one to one) + group pages

@Composable
fun ModePage(mgr: Manager, mode: Int, theme: PageTheme, title: String, back: () -> Unit) {
    if (mode == 2) GroupPage(mgr, theme, title, back) else DirectPage(mgr, theme, title, back)
}

@Composable
fun GroupPage(mgr: Manager, theme: PageTheme, title: String, back: () -> Unit) {
    val ctx = LocalContext.current
    val session by mgr.session.collectAsState()
    val online by mgr.online.collectAsState()
    val me by mgr.me.collectAsState()
    val tick by mgr.openChatTick.collectAsState()
    var showQr by remember { mutableStateOf(false) }
    var dialogKind by remember { mutableStateOf(0) }
    var alert by remember { mutableStateOf<Pair<String, Int>?>(null) }
    val active = session.mode == 2
    val inGroup = active && online.isNotEmpty()

    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        val c = r.contents
        if (c != null) mgr.joinFromQr(c)
    }
    fun raise(text: String, kind: Int) {
        alert = text to kind
        Utils.postSettingsNotification(ctx, text, kind)
    }
    // Short how-to in the existing yellow banner (same look): only while no network is ready and nothing is connected.
    LaunchedEffect(Unit) {
        if (alert == null && session.mode == 0 && Utils.localIp() == null) {
            alert = (if (Utils.wifiOn(ctx))
                "Phone 1: turn on Hotspot, tap Open QR Code. Phone 2: join that hotspot in Wi-Fi, tap Open Scanner or Search Nearby."
            else
                "Phone 1: turn on Hotspot, tap Open QR Code. Phone 2: turn on Wi-Fi, join that hotspot, tap Open Scanner or Search Nearby.") to 0
        }
    }
    LaunchedEffect(alert) {
        val a = alert
        if (a != null) {
            while (true) {
                delay(1200)
                val fixed = when (a.second) {
                    0 -> Utils.wifiOn(ctx) || Utils.localIp() != null
                    else -> Utils.localIp() != null
                }
                if (fixed) {
                    alert = null
                    Utils.cancelSettingsNotifications(ctx)
                    break
                }
            }
        }
    }
    LaunchedEffect(online.size) {
        if (online.isNotEmpty()) {
            showQr = false
            dialogKind = 0
            alert = null
        }
    }
    LaunchedEffect(tick) { if (tick > 0) showQr = false }
    val leaveQr = {
        showQr = false
        if (!inGroup) mgr.stopSession()
    }
    BackHandler(enabled = showQr) { leaveQr() }

    KeepVisible(mgr, 2, !inGroup && !showQr && dialogKind == 0)

    val openScannerCamera = {
        dialogKind = 0
        if (!inGroup) mgr.stopSession()
        mgr.internalLaunch = true
        scan.launch(
            ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                .setPrompt("Scan the Airlink QR code").setBeepEnabled(false).setOrientationLocked(false)
                .setCaptureActivity(com.airlink.app.ScanActivity::class.java)
        )
    }

    PageBox(theme) {
        when {
            inGroup && !showQr -> ChatPanel(mgr, 2, theme, back, onInvite = { showQr = true })
            showQr -> GroupQrPanel(mgr, theme, leaveQr, inGroup) { showQr = false }
            else -> Column(Modifier.fillMaxSize()) {
                Title(title, back)
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionTile("Open Scanner", Green, Modifier.weight(1f), { ScanIcon(Modifier.size(32.dp)) }) {
                        if (!Utils.wifiOn(ctx) && Utils.localIp() == null) {
                            raise("Wi-Fi is off. Turn it on to scan for Airlink phones around you.", 0)
                        } else {
                            alert = null
                            dialogKind = 2
                        }
                    }
                    ActionTile("Open QR Code", theme.accent, Modifier.weight(1f), { QrIcon(Modifier.size(32.dp)) }) {
                        if (Utils.localIp() == null) {
                            raise("Hotspot is off. Turn it on, then the other phones can join it and scan your QR.", 1)
                        } else {
                            alert = null
                            showQr = true
                            mgr.startHost(2, false, me.name + "'s group")
                        }
                    }
                    ActionTile("Search Nearby Network", Cyan, Modifier.weight(1f), { LinkSignalIcon(Modifier.size(34.dp), listOf(Color.White, Color.White)) }) {
                        if (Utils.localIp() != null) {
                            alert = null
                            dialogKind = 1
                        } else if (!Utils.wifiOn(ctx)) {
                            raise("Wi-Fi is off. Turn it on (or turn on your hotspot) to find nearby phones.", 0)
                        } else {
                            raise("Not on any Wi-Fi or hotspot yet. Join the other phone's hotspot or turn on yours.", 2)
                        }
                    }
                }
                alert?.let { a ->
                    AlertBanner(
                        a.first,
                        onOpen = {
                            mgr.internalLaunch = true
                            if (a.second == 1) Utils.openHotspotSettings(ctx) else Utils.openWifiSettings(ctx)
                        },
                        onClose = {
                            alert = null
                            Utils.cancelSettingsNotifications(ctx)
                        }
                    )
                }
                if (session.mode == 2 && !session.host && !inGroup) {
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp)
                            .background(Brush.horizontalGradient(Cyan), RoundedCornerShape(16.dp)).padding(12.dp)
                    ) {
                        Text(
                            session.status.ifBlank { "Connecting..." }, color = Color.White,
                            fontWeight = FontWeight.Bold, fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }

    if (dialogKind != 0) {
        NearbyDialog(
            mgr, theme, withCamera = dialogKind == 2,
            onDismiss = {
                dialogKind = 0
                if (!inGroup && !showQr) mgr.stopSession()
            },
            onScanCamera = openScannerCamera,
            onPick = { n -> mgr.connectNearby(n) },
            mode = 2
        )
    }
}

/** Group QR: just the code, who is connected, and Open chat / Stop. */
@Composable
fun GroupQrPanel(mgr: Manager, theme: PageTheme, back: () -> Unit, canOpenChat: Boolean, onOpenChat: () -> Unit) {
    val session by mgr.session.collectAsState()
    val online by mgr.online.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Title("My QR", back)
        Panel {
            if (session.host && session.qr.isNotEmpty()) {
                val bmp = remember(session.qr) { Utils.qrBitmap(session.qr).asImageBitmap() }
                Image(
                    bmp, "QR code",
                    Modifier.size(250.dp).align(Alignment.CenterHorizontally).background(Color.White).padding(8.dp)
                )
                Text(
                    "Everybody scans this to join the group",
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 13.sp
                )
            }
            Text(session.status, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            if (online.isNotEmpty()) {
                Text("Connected: " + online.values.joinToString { it.name }, modifier = Modifier.padding(top = 6.dp))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                if (canOpenChat) {
                    AirButton("Open chat", Green, Modifier.weight(1f), 1, onClick = onOpenChat)
                    Spacer(Modifier.width(10.dp))
                }
                AirButton("Stop", Red, Modifier.weight(1f), 2) { mgr.stopSession() }
            }
        }
    }
}

/**
 * One to One page. Top: three buttons (Search Nearby Network / Open Scanner / Open QR Code) in one small block.
 * Below: the saved users (tap = chat history). Connecting never needs a PIN: the other phone only taps Confirm.
 */
@Composable
fun DirectPage(mgr: Manager, theme: PageTheme, title: String, back: () -> Unit) {
    val ctx = LocalContext.current
    val session by mgr.session.collectAsState()
    val online by mgr.online.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    val tick by mgr.openChatTick.collectAsState()
    val liveId: String? = if (session.mode == 1) online.keys.firstOrNull() else null
    var selected by remember { mutableStateOf(liveId) }
    var showQr by remember { mutableStateOf(false) }
    var transport by remember { mutableStateOf<Int?>(null) }
    // 0 = closed, 1 = "Search Nearby Network" list, 2 = "Open Scanner" list
    var dialogKind by remember { mutableStateOf(0) }
    // the "notification": text + kind (0 Wi-Fi is off, 1 hotspot is off, 2 not on any network)
    var alert by remember { mutableStateOf<Pair<String, Int>?>(null) }
    val now = rememberMinuteNow()

    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        val c = r.contents
        if (c != null) mgr.joinFromQr(c)
    }

    fun raise(text: String, kind: Int) {
        alert = text to kind
        Utils.postSettingsNotification(ctx, text, kind)
    }

    // The banner goes away by itself as soon as the person has fixed the problem in Settings.
    // Short how-to in the existing yellow banner (same look): only while no network is ready and nothing is connected.
    LaunchedEffect(Unit) {
        if (alert == null && session.mode == 0 && Utils.localIp() == null) {
            alert = (if (Utils.wifiOn(ctx))
                "Phone 1: turn on Hotspot, tap Open QR Code. Phone 2: join that hotspot in Wi-Fi, tap Open Scanner or Search Nearby."
            else
                "Phone 1: turn on Hotspot, tap Open QR Code. Phone 2: turn on Wi-Fi, join that hotspot, tap Open Scanner or Search Nearby.") to 0
        }
    }
    LaunchedEffect(alert) {
        val a = alert
        if (a != null) {
            while (true) {
                delay(1200)
                val fixed = when (a.second) {
                    0 -> Utils.wifiOn(ctx) || Utils.localIp() != null
                    else -> Utils.localIp() != null
                }
                if (fixed) {
                    alert = null
                    Utils.cancelSettingsNotifications(ctx)
                    break
                }
            }
        }
    }

    LaunchedEffect(liveId) {
        if (liveId != null) {
            selected = liveId
            showQr = false
            transport = null
            dialogKind = 0
            alert = null
        }
    }
    LaunchedEffect(tick) {
        if (tick > 0 && liveId != null) {
            selected = liveId
            showQr = false
            transport = null
        }
    }
    val leaveQr = {
        showQr = false
        transport = null
        if (liveId == null) mgr.stopSession()
    }
    BackHandler(enabled = showQr || selected != null) {
        if (showQr) {
            leaveQr()
        } else {
            selected = null
        }
    }

    KeepVisible(mgr, 1, liveId == null && !showQr && dialogKind == 0)

    val openScannerCamera = {
        dialogKind = 0
        if (liveId == null) mgr.stopSession()
        mgr.internalLaunch = true
        scan.launch(
            ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                .setPrompt("Scan the Airlink QR code").setBeepEnabled(false).setOrientationLocked(false)
                .setCaptureActivity(com.airlink.app.ScanActivity::class.java)
        )
    }

    PageBox(theme) {
        val sel = selected
        when {
            showQr -> ConnectPanel(
                mgr, 1, theme, "My QR", leaveQr,
                liveId != null, { selected = liveId; showQr = false }, transport == 1
            )
            sel != null -> ChatPanel(mgr, 1, theme, { selected = null }, { }, sel, liveId == sel)
            else -> Column(Modifier.fillMaxSize()) {
                Title(title, back)

                // ---- the three buttons: one small block at the top only
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionTile("Open Scanner", Green, Modifier.weight(1f), { ScanIcon(Modifier.size(32.dp)) }) {
                        if (!Utils.wifiOn(ctx) && Utils.localIp() == null) {
                            raise("Wi-Fi is off. Turn it on to scan for Airlink phones around you.", 0)
                        } else {
                            alert = null
                            dialogKind = 2
                        }
                    }
                    ActionTile("Open QR Code", theme.accent, Modifier.weight(1f), { QrIcon(Modifier.size(32.dp)) }) {
                        if (Utils.localIp() == null) {
                            raise("Hotspot is off. Turn it on, then the other phone can join it and scan your QR.", 1)
                        } else {
                            alert = null
                            transport = 0
                            showQr = true
                            mgr.startHost(1, false, "")
                        }
                    }
                    ActionTile("Search Nearby Network", Cyan, Modifier.weight(1f), { LinkSignalIcon(Modifier.size(34.dp), listOf(Color.White, Color.White)) }) {
                        if (Utils.localIp() != null) {
                            alert = null
                            dialogKind = 1
                        } else if (!Utils.wifiOn(ctx)) {
                            raise("Wi-Fi is off. Turn it on (or turn on your hotspot) to find nearby phones.", 0)
                        } else {
                            raise("Not on any Wi-Fi or hotspot yet. Join the other phone's hotspot or turn on yours.", 2)
                        }
                    }
                }

                alert?.let { a ->
                    AlertBanner(
                        a.first,
                        onOpen = {
                            mgr.internalLaunch = true
                            if (a.second == 1) Utils.openHotspotSettings(ctx) else Utils.openWifiSettings(ctx)
                        },
                        onClose = {
                            alert = null
                            Utils.cancelSettingsNotifications(ctx)
                        }
                    )
                }

                if (session.mode == 1 && !session.host && liveId == null) {
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp)
                            .background(Brush.horizontalGradient(Cyan), RoundedCornerShape(16.dp)).padding(12.dp)
                    ) {
                        Text(
                            session.status.ifBlank { "Connecting..." }, color = Color.White,
                            fontWeight = FontWeight.Bold, fontSize = 14.sp
                        )
                    }
                }

                // ---- saved users
                if (users.isEmpty()) {
                    Panel {
                        Text("No saved users yet.", fontWeight = FontWeight.Bold)
                        Text("Use the three buttons above to connect with a phone. Everyone you connect with is saved here.", fontSize = 13.sp)
                    }
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(users, key = { it.id }) { u ->
                        UserCard(
                            u,
                            live = online.containsKey(u.id) && session.mode == 1,
                            statusText = "Last seen: " + Utils.lastSeen(now, u.lastSeen)
                        ) { selected = u.id }
                    }
                }
            }
        }
    }

    if (dialogKind != 0) {
        NearbyDialog(
            mgr, theme, withCamera = dialogKind == 2,
            onDismiss = {
                dialogKind = 0
                if (liveId == null && !showQr) mgr.stopSession()
            },
            onScanCamera = openScannerCamera,
            onPick = { n -> mgr.connectNearby(n) }
        )
    }
}

/** One of the three square-ish buttons at the top of the One to One page: icon on top, small label below. */
@Composable
fun ActionTile(
    label: String, colors: List<Color>, modifier: Modifier = Modifier,
    icon: @Composable () -> Unit, onClick: () -> Unit
) {
    AirBox(colors, modifier.height(108.dp), onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            icon()
            Spacer(Modifier.height(6.dp))
            Text(
                label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                textAlign = TextAlign.Center, lineHeight = 14.sp, maxLines = 3
            )
        }
    }
}

/** The in-app "notification" with a link: tapping it opens the Wi-Fi or hotspot settings. */
@Composable
fun AlertBanner(text: String, onOpen: () -> Unit, onClose: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable(onClick = onOpen),
        shape = RoundedCornerShape(16.dp), color = Color(0xFFFFF4D6), tonalElevation = 2.dp
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(text, color = Color(0xFF5B3A00), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Tap here to open the settings", color = Color(0xFF1D4ED8), fontSize = 12.sp,
                    fontWeight = FontWeight.Bold, textDecoration = TextDecoration.Underline,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Text(
                "\u2715", color = Color(0xFF5B3A00), fontSize = 16.sp,
                modifier = Modifier.clickable(onClick = onClose).padding(8.dp)
            )
        }
    }
}

private val CardColors = listOf(
    listOf(Color(0xFF2563EB), Color(0xFF7C3AED)),
    listOf(Color(0xFFF97316), Color(0xFFEC4899)),
    listOf(Color(0xFF059669), Color(0xFF14B8A6)),
    listOf(Color(0xFF7C3AED), Color(0xFFDB2777)),
    listOf(Color(0xFF0284C7), Color(0xFF6366F1))
)

/** A saved user: bright glossy gradient card, white bold text with a soft shadow so it stays sharp in light and dark mode. */
@Composable
fun UserCard(u: UserEntity, live: Boolean, statusText: String, onClick: () -> Unit) {
    val colors = CardColors[Math.floorMod(u.id.hashCode(), CardColors.size)]
    val shape = RoundedCornerShape(22.dp)
    val crisp = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.7f), Offset(0f, 2f), 6f))
    Box(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .shadow(8.dp, shape, ambientColor = colors[0], spotColor = colors[1])
            .clip(shape)
            .background(Brush.horizontalGradient(colors), shape)
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), shape)
            .clickable(onClick = onClick)
    ) {
        Box(
            Modifier.fillMaxWidth().height(34.dp)
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent)))
        )
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.border(2.5.dp, Color.White, CircleShape).padding(2.dp)) { Avatar(u.photo, u.name, 48.dp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    u.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp,
                    maxLines = 1, style = crisp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (live) {
                        Box(Modifier.size(9.dp).background(Color(0xFF86EFAC), CircleShape))
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        if (live) "Online now" else statusText,
                        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, style = crisp
                    )
                }
            }
        }
    }
}

/**
 * While a connect page is open (and nothing else is going on) this phone stays visible in the other phones'
 * "Search Nearby Network" list, so the other phone never has to open anything: it just gets the Allow box.
 * Leaving the page without a live connection makes the phone invisible again.
 */
@Composable
fun KeepVisible(mgr: Manager, mode: Int, enabled: Boolean) {
    LaunchedEffect(enabled, mode) {
        if (enabled) {
            while (true) {
                mgr.startVisible(mode)
                delay(1500)
            }
        }
    }
    DisposableEffect(mode) {
        onDispose {
            if (mgr.online.value.isEmpty() && mgr.session.value.let { it.mode == mode && it.host }) mgr.stopSession()
        }
    }
}

/**
 * ShareIt-style list of the Airlink phones around: round photo + name, each marked with the Airlink badge.
 * Only Airlink phones ever answer. One tap = request sent; the other phone only has to tap Allow. No PIN, no extra settings.
 * withCamera = also offers the QR camera scanner.
 */
@Composable
fun NearbyDialog(
    mgr: Manager, theme: PageTheme, withCamera: Boolean,
    onDismiss: () -> Unit, onScanCamera: () -> Unit, onPick: (Nearby) -> Unit, mode: Int = 1
) {
    val nearby by mgr.nearby.collectAsState()
    val photos by mgr.nearbyPhotos.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    val session by mgr.session.collectAsState()
    var pending by remember { mutableStateOf<Nearby?>(null) }

    // While open: make this phone visible to the other Airlink phones and keep looking (and fetch their photos).
    LaunchedEffect(Unit) {
        while (true) {
            mgr.startVisible(mode)
            mgr.sweepNearby()
            for (n in mgr.nearby.value.values) mgr.peekNearby(n)
            delay(1200)
        }
    }
    // The request ended without a connection (declined / timed out): go back to the list.
    LaunchedEffect(session.mode) { if (session.mode == 0) pending = null }

    val near = nearby.values.filter { it.mode == mode }.sortedBy { it.name.lowercase() }
    val wait = pending

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth(0.94f),
            shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surface
        ) {
            Column(Modifier.padding(18.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AirBadge(32.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (withCamera) "Airlink scanner" else "Nearby Airlink phones",
                        fontWeight = FontWeight.ExtraBold, fontSize = 20.sp
                    )
                }
                Spacer(Modifier.height(12.dp))
                if (wait != null) {
                    // ---- request sent: the other phone only has to tap Allow
                    val photo = (photos[wait.id] ?: ByteArray(0)).takeIf { it.isNotEmpty() }
                        ?: users.firstOrNull { it.id == wait.id }?.photo
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(Modifier.size(104.dp), strokeWidth = 4.dp)
                            Avatar(photo, wait.name, 82.dp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(wait.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Waiting for " + wait.name + " to allow...", fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                } else if (near.isEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(26.dp), strokeWidth = 3.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Looking for Airlink phones nearby...", fontSize = 14.sp)
                    }
                } else {
                    Text("Tap a phone to connect. It only has to tap Allow.", fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    for (row in near.chunked(3)) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            for (n in row) {
                                val photo = (photos[n.id] ?: ByteArray(0)).takeIf { it.isNotEmpty() }
                                    ?: users.firstOrNull { it.id == n.id }?.photo
                                Column(
                                    Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).clickable {
                                        pending = n
                                        onPick(n)
                                    }.padding(4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box {
                                        Box(
                                            Modifier.border(3.dp, Brush.linearGradient(theme.accent), CircleShape).padding(3.dp)
                                        ) { Avatar(photo, n.name, 66.dp) }
                                        Box(Modifier.align(Alignment.BottomEnd)) { AirBadge(24.dp) }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        n.name, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                        maxLines = 1, textAlign = TextAlign.Center
                                    )
                                }
                            }
                            for (i in row.size until 3) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                if (withCamera && wait == null) {
                    Spacer(Modifier.height(8.dp))
                    AirButton("Scan a QR code with the camera", Cyan, Modifier.fillMaxWidth(), 1, onClick = onScanCamera)
                }
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    AirButton(if (wait != null) "Cancel" else "Close", Grey, small = true, onClick = onDismiss)
                }
            }
        }
    }
}

/**
 * The connect dialog.
 * 1) Nearby phones: found automatically (both phones just open this screen), tap one, the other phone taps Confirm.
 * 2) Scan a QR code.  3) Show my QR code.
 * A small link appears only when it is needed: Wi-Fi off (for scanning) or hotspot off (for showing the QR).
 */
@Composable
fun ConnectDialog(
    mgr: Manager, theme: PageTheme, onDismiss: () -> Unit, onScanner: () -> Unit,
    onShowQr: (Boolean) -> Unit, onPickNearby: (Nearby) -> Unit
) {
    val ctx = LocalContext.current
    val nearby by mgr.nearby.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    var bt by remember { mutableStateOf(false) }
    var netReady by remember { mutableStateOf(Utils.localIp() != null) }
    var wifiOn by remember { mutableStateOf(Utils.wifiOn(ctx)) }

    // While the dialog is open: keep checking Wi-Fi / hotspot (the person may come back from Settings)
    // and make this phone visible to the other Airlink phones as soon as a network exists.
    LaunchedEffect(bt) {
        while (true) {
            netReady = Utils.localIp() != null
            wifiOn = Utils.wifiOn(ctx)
            if (!bt) mgr.startVisible()
            delay(1500)
        }
    }

    val near = nearby.values.filter { it.mode == 1 }.sortedBy { it.name.lowercase() }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Text("Connect with a phone", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Spacer(Modifier.height(10.dp))

                // ---- 1. nearby phones (automatic)
                Text("Nearby phones", fontWeight = FontWeight.Bold, color = theme.accent[0])
                if (!netReady) {
                    Text("Turn on Wi-Fi or hotspot to find phones around you.", fontSize = 13.sp)
                } else if (near.isEmpty()) {
                    Text("Searching... the other phone must also open this screen.", fontSize = 13.sp)
                } else {
                    for (n in near) {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(n.name, fontWeight = FontWeight.Bold, maxLines = 1)
                                if (users.any { it.id == n.id }) Text("Saved", fontSize = 11.sp)
                            }
                            AirButton("Connect", theme.accent, small = true) { onPickNearby(n) }
                        }
                    }
                }

                // ---- 2. scan a QR
                Spacer(Modifier.height(16.dp))
                Text("Scan a QR code", fontWeight = FontWeight.Bold, color = Cyan[1])
                if (!wifiOn && !netReady) {
                    LinkText("Wi-Fi is off. Tap here to turn it on") {
                        mgr.internalLaunch = true
                        Utils.openWifiSettings(ctx)
                    }
                }
                Spacer(Modifier.height(6.dp))
                AirButton("Open Scanner", Cyan, Modifier.fillMaxWidth(), 1, onClick = onScanner)

                // ---- 3. show my QR
                Spacer(Modifier.height(16.dp))
                Text("Show my QR code", fontWeight = FontWeight.Bold, color = theme.accent[0])
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    AirButton("Wi-Fi / Hotspot", if (!bt) theme.accent else Grey, Modifier.weight(1f), 1, small = true) { bt = false }
                    Spacer(Modifier.width(8.dp))
                    AirButton("Bluetooth", if (bt) theme.accent else Grey, Modifier.weight(1f), 3, small = true) { bt = true }
                }
                Spacer(Modifier.height(6.dp))
                if (bt) {
                    Text("Pair the two phones once in Bluetooth settings. Video calls need Wi-Fi.", fontSize = 13.sp)
                } else if (!netReady) {
                    LinkText("Hotspot is off. Tap here to turn it on") {
                        mgr.internalLaunch = true
                        Utils.openHotspotSettings(ctx)
                    }
                }
                Spacer(Modifier.height(6.dp))
                AirButton("Show My QR", theme.accent, Modifier.fillMaxWidth(), 0) { onShowQr(bt) }

                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    AirButton("Cancel", Grey, small = true, onClick = onDismiss)
                }
            }
        }
    }
}

@Composable
private fun LinkText(text: String, onClick: () -> Unit) {
    Text(
        text, color = Cyan[1], fontSize = 13.sp, fontWeight = FontWeight.Bold,
        textDecoration = TextDecoration.Underline,
        modifier = Modifier.padding(vertical = 6.dp).clickable(onClick = onClick)
    )
}

@Composable
fun ConnectPanel(
    mgr: Manager, mode: Int, theme: PageTheme, title: String, back: () -> Unit,
    canOpenChat: Boolean, onOpenChat: () -> Unit, fixedBt: Boolean? = null
) {
    val ctx = LocalContext.current
    val session by mgr.session.collectAsState()
    val nearby by mgr.nearby.collectAsState()
    val online by mgr.online.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    var btSel by remember { mutableStateOf(false) }
    val bt = fixedBt ?: btSel
    var gname by remember { mutableStateOf("") }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        val c = r.contents
        if (c != null) mgr.joinFromQr(c)
    }
    val showing = session.mode == mode
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Title(title, back)
        if (fixedBt == null) {
            Row(Modifier.fillMaxWidth()) {
                AirButton("Wi-Fi", if (!bt) theme.accent else Grey, Modifier.weight(1f), 1) { btSel = false }
                Spacer(Modifier.width(10.dp))
                AirButton("Bluetooth", if (bt) theme.accent else Grey, Modifier.weight(1f), 3) { btSel = true }
            }
            Spacer(Modifier.height(10.dp))
        }
        Panel {
            if (bt) {
                Text("Bluetooth is slower. Chat, voice calls and files work, but video calls are Wi-Fi only. Pair the two phones in Bluetooth settings once before connecting.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                AirButton("Open Bluetooth settings", Cyan, Modifier.fillMaxWidth(), 2) {
                    mgr.internalLaunch = true
                    ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                }
            } else {
                Text("Wi-Fi: turn on the hotspot on one phone and connect the other phone to it (or put both on the same Wi-Fi). No internet needed.", fontSize = 13.sp)
            }
            if (mode == 2) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = gname, onValueChange = { gname = it.take(30) },
                    label = { Text("Group name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            AirButton(if (mode == 2) "Create group + QR" else "Show my QR", theme.accent, Modifier.weight(1f), 0) {
                mgr.startHost(mode, bt, gname)
            }
            Spacer(Modifier.width(10.dp))
            AirButton("Scan QR", Cyan, Modifier.weight(1f), 1) {
                mgr.internalLaunch = true
                scan.launch(
                    ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                        .setPrompt("Scan the Airlink QR code").setBeepEnabled(false).setOrientationLocked(false)
                .setCaptureActivity(com.airlink.app.ScanActivity::class.java)
                )
            }
        }
        if (showing) {
            Spacer(Modifier.height(10.dp))
            Panel {
                if (session.host && session.qr.isNotEmpty()) {
                    val bmp = remember(session.qr) { Utils.qrBitmap(session.qr).asImageBitmap() }
                    Image(
                        bmp, "QR code",
                        Modifier.size(250.dp).align(Alignment.CenterHorizontally).background(Color.White).padding(8.dp)
                    )
                    Text(
                        if (mode == 2) "Everybody scans this to join the group" else "Let the other phone scan this",
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 13.sp
                    )
                }
                Text(session.status, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                if (online.isNotEmpty()) {
                    Text("Connected: " + online.values.joinToString { it.name }, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    if (canOpenChat) {
                        AirButton("Open chat", Green, Modifier.weight(1f), 1, onClick = onOpenChat)
                        Spacer(Modifier.width(10.dp))
                    }
                    AirButton("Stop", Red, Modifier.weight(1f), 2) { mgr.stopSession() }
                }
            }
        }
        val near = nearby.values.filter { it.mode == mode }
        if (!bt && near.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Panel {
                Text("Phones nearby", fontWeight = FontWeight.Bold)
                for (n in near) {
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(n.name, Modifier.weight(1f))
                        AirButton("Connect", theme.accent, style = 1) { mgr.connectNearby(n) }
                    }
                }
            }
        }
    }
}

/** Chat. `convId` = which saved user (one to one). `live` = connected right now (otherwise read-only history). */
@Composable
fun ChatPanel(
    mgr: Manager, mode: Int, theme: PageTheme, back: () -> Unit, onInvite: () -> Unit,
    convId: String? = null, live: Boolean = true
) {
    val ctx = LocalContext.current
    val session by mgr.session.collectAsState()
    val online by mgr.online.collectAsState()
    val call by mgr.call.collectAsState()
    val nearby by mgr.nearby.collectAsState()
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    val conv = if (mode == 2) session.groupId else (convId ?: online.keys.firstOrNull() ?: "")
    val msgs by remember(conv) { mgr.dao.messages(conv) }.collectAsState(initial = emptyList<MessageEntity>())
    val listState = rememberLazyListState()
    val now = rememberNow()
    var text by remember { mutableStateOf("") }
    var muted by remember { mutableStateOf(false) }
    LaunchedEffect(conv) { mgr.setActive(conv) }
    DisposableEffect(Unit) { onDispose { mgr.setActive("") } }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) mgr.sendUri(u)
    }
    // Save buttons: /sdcard/Airlink/. Android 11+ needs "All files access" first.
    var pendingSave by remember { mutableStateOf<MessageEntity?>(null) }
    fun doSave(m: MessageEntity, fallback: Boolean) {
        Thread {
            val where = if (fallback) AirlinkStorage.saveToDownloadsAirlink(ctx, m.path, m.fileName)
            else AirlinkStorage.save(ctx, m.path, m.fileName)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(ctx, if (where != null) "Saved to $where" else "Could not save", Toast.LENGTH_LONG).show()
            }
        }.start()
    }
    val onSave: (MessageEntity) -> Unit = { m -> if (AirlinkStorage.needsAllFilesPrompt()) pendingSave = m else doSave(m, false) }
    val title = if (mode == 2) session.groupName.ifBlank { "Group" }
    else (users.firstOrNull { it.id == conv }?.name ?: online[conv]?.name ?: "Chat")

    val pm = pendingSave
    if (pm != null) {
        SaveAccessDialog(pm, mgr, { pendingSave = null }) {
            pendingSave = null
            doSave(pm, true)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            PlainIcon("←", 26, onClick = back)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text(
                    if (live) (online.size + 1).toString() + " online · " + (if (session.bt) "Bluetooth" else "Wi-Fi")
                    else "Offline · saved history",
                    color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp
                )
            }
            if (live) {
                AirButton("📞", Green, style = 0) { mgr.startCall(false) }
                Spacer(Modifier.width(6.dp))
                AirButton("📹", if (session.bt) Grey else Cyan, style = 3) { mgr.startCall(true) }
            }
        }
        if (live) {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                if (mode == 2 && session.host) {
                    AirButton("＋ Invite", theme.accent, Modifier.weight(1f), 1) { onInvite() }
                    Spacer(Modifier.width(8.dp))
                }
                AirButton("Disconnect", Red, Modifier.weight(1f), 2) { mgr.stopSession() }
            }
        }
        if (live && session.bt) {
            Text(
                "Bluetooth is slower: big files and voice may take longer. Video calls are Wi-Fi only.",
                color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)
            )
        }
        if (live && call.state == 2 && !call.video) {
            Panel(Modifier.padding(bottom = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (call.startedAt > 0) "In call  " + Utils.duration(((now - call.startedAt) / 1000).toInt()) else "Calling...",
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                    )
                    AirButton(if (muted) "Unmute" else "Mute", Grey, style = 2) {
                        muted = !muted
                        mgr.audio.muted = muted
                    }
                    Spacer(Modifier.width(8.dp))
                    AirButton("End", Red, style = 1) { mgr.endCall() }
                }
            }
        }
        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(msgs, key = { it.id }) { m ->
                // always one reliable name: stored name, else saved/online user, else "User"
                val who = if (m.outgoing) "You"
                else m.senderName.trim().ifBlank {
                    users.firstOrNull { it.id == m.senderId }?.name?.trim().orEmpty()
                        .ifBlank { online[m.senderId]?.name?.trim().orEmpty() }
                        .ifBlank { "User" }
                }
                Bubble(m, theme, who, onSave)
            }
            if (msgs.isNotEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                    AirButton("Clear conversation", Grey, small = true) {
                        mgr.clearConversation(conv)
                        Toast.makeText(ctx, "Conversation cleared", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        if (live) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                AirButton("📎", Cyan, style = 3) {
                    mgr.internalLaunch = true
                    pick.launch(arrayOf("*/*"))
                }
                Spacer(Modifier.width(6.dp))
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("Message") }, maxLines = 3
                )
                Spacer(Modifier.width(6.dp))
                if (text.isBlank()) {
                    MicButton(mgr, theme)
                } else {
                    AirButton("➤", theme.accent, style = 0) {
                        mgr.sendText(text.trim())
                        text = ""
                    }
                }
            }
        } else {
            Panel(Modifier.padding(top = 6.dp)) {
                Text("Not connected. To chat again, connect with the QR icon on the previous page.", fontSize = 13.sp)
                val n = nearby[conv]
                if (n != null) {
                    Spacer(Modifier.height(8.dp))
                    AirButton("Connect (nearby)", theme.accent, Modifier.fillMaxWidth(), 1) { mgr.connectNearby(n) }
                }
            }
        }
    }
}

@Composable
private fun SaveAccessDialog(m: MessageEntity, mgr: Manager, close: () -> Unit, saveFallback: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Save to the Airlink folder") },
        text = {
            Text(
                "To save into the \"Airlink\" folder on your phone's main storage (/sdcard/Airlink), allow \"All files access\" for Airlink, then tap Save again."
            )
        },
        confirmButton = {
            AirButton("Allow", Green, style = 1) {
                mgr.internalLaunch = true
                try {
                    ctx.startActivity(AirlinkStorage.accessIntent(ctx))
                } catch (e: Exception) {
                    ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                close()
            }
        },
        dismissButton = { AirButton("Use Download/Airlink", Grey, style = 2, small = true) { saveFallback() } }
    )
}

@Composable
fun MicButton(mgr: Manager, theme: PageTheme) {
    val ctx = LocalContext.current
    val rec = remember { VoiceRec(ctx) }
    var recording by remember { mutableStateOf(false) }
    Box(
        Modifier.size(52.dp).clip(AirShape)
            .background(Brush.verticalGradient(if (recording) Red else theme.accent), AirShape)
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), AirShape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    recording = rec.start()
                    tryAwaitRelease()
                    if (recording) {
                        recording = false
                        val f = rec.stop()
                        if (f != null) {
                            if (f.length() > 800) mgr.sendVoice(f) else f.delete()
                        }
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text(if (recording) "●" else "🎤", color = Color.White, fontSize = 20.sp)
    }
}

/** Picture preview (no file name). Tap = open full screen in the viewer app. */
@Composable
fun ImagePreview(path: String, onClick: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { Utils.thumbnail(path, 1, 720) }?.asImageBitmap()
    }
    val b = bmp
    if (b == null) {
        Box(
            Modifier.size(200.dp, 150.dp),
            contentAlignment = Alignment.Center
        ) { Text("Image", color = Color.White, fontSize = 12.sp) }
    } else {
        Image(
            b, null,
            Modifier.widthIn(max = 250.dp).heightIn(max = 300.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick),
            contentScale = ContentScale.Fit
        )
    }
}

/**
 * Video that plays right inside the chat. First it shows the first frame with a play mark;
 * tapping starts real playback (VideoView with the standard play/pause/seek controls).
 */
@Composable
fun InlineVideo(path: String) {
    var playing by remember(path) { mutableStateOf(false) }
    Box(
        Modifier.size(230.dp, 170.dp).clip(RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (!playing) {
            val bmp by produceState<ImageBitmap?>(null, path) {
                value = withContext(Dispatchers.IO) { Utils.thumbnail(path, 2, 720) }?.asImageBitmap()
            }
            val b = bmp
            if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            Box(
                Modifier.size(50.dp).border(2.dp, Color.White, CircleShape).clip(CircleShape).clickable { playing = true },
                contentAlignment = Alignment.Center
            ) { Text("▶", color = Color.White, fontSize = 22.sp) }
        } else {
            AndroidView(
                factory = { c ->
                    VideoView(c).apply {
                        val mc = MediaController(c)
                        mc.setAnchorView(this)
                        setMediaController(mc)
                        setVideoPath(path)
                        setOnPreparedListener { start() }
                        setOnCompletionListener { playing = false }
                    }
                },
                onRelease = { it.stopPlayback() },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/**
 * Music that plays right inside the chat, same idea as InlineVideo: a player bar with play/pause,
 * a seek bar and the time. Works for mp3, m4a, wav, ogg, flac, aac and the other audio extensions.
 */
@Composable
fun InlineAudio(path: String, fg: Color, accent: List<Color>) {
    var player by remember(path) { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember(path) { mutableStateOf(false) }
    var pos by remember(path) { mutableStateOf(0) }
    var dur by remember(path) { mutableStateOf(0) }
    var failed by remember(path) { mutableStateOf(false) }
    var dragging by remember(path) { mutableStateOf(false) }

    DisposableEffect(path) {
        onDispose {
            try { player?.release() } catch (e: Exception) { }
            player = null
        }
    }
    LaunchedEffect(playing, dragging, player) {
        while (playing && !dragging) {
            val p = player ?: break
            try { pos = p.currentPosition } catch (e: Exception) { break }
            delay(250)
        }
    }
    fun fmt(ms: Int): String {
        val t = ms / 1000
        return "%d:%02d".format(t / 60, t % 60)
    }
    fun toggle() {
        try {
            var p = player
            if (p == null) {
                p = MediaPlayer()
                p.setDataSource(path)
                p.prepare()
                p.setOnCompletionListener { playing = false; pos = 0; try { it.seekTo(0) } catch (e: Exception) { } }
                dur = p.duration
                player = p
            }
            if (p.isPlaying) { p.pause(); playing = false } else { p.start(); playing = true }
        } catch (e: Exception) {
            failed = true
        }
    }
    Row(Modifier.widthIn(min = 220.dp, max = 260.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Brush.linearGradient(accent)).clickable { toggle() },
            contentAlignment = Alignment.Center
        ) { Text(if (playing) "❚❚" else "▶", color = Color.White, fontSize = 16.sp) }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            if (failed) {
                Text("Can't play this audio", color = fg, fontSize = 12.sp)
            } else {
                Slider(
                    value = if (dur > 0) pos.toFloat().coerceIn(0f, dur.toFloat()) else 0f,
                    onValueChange = { dragging = true; pos = it.toInt() },
                    onValueChangeFinished = {
                        try { player?.seekTo(pos) } catch (e: Exception) { }
                        dragging = false
                    },
                    valueRange = 0f..(if (dur > 0) dur.toFloat() else 1f),
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.35f)
                    ),
                    modifier = Modifier.height(24.dp)
                )
                Text(fmt(pos) + " / " + fmt(dur), color = fg.copy(alpha = 0.7f), fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun Bubble(m: MessageEntity, theme: PageTheme, who: String, onSave: (MessageEntity) -> Unit) {
    val ctx = LocalContext.current
    val out = m.outgoing
    // files (photo, video, music, any file) float straight on the page: no bubble box, no border
    val bare = m.kind > 1
    val fg = if (bare) Color.White else if (out) Color.White else MaterialTheme.colorScheme.onSurface
    val shape = RoundedCornerShape(
        topStart = 18.dp, topEnd = 18.dp,
        bottomStart = if (out) 18.dp else 4.dp, bottomEnd = if (out) 4.dp else 18.dp
    )
    val maxW = (LocalConfiguration.current.screenWidthDp * 0.78f).dp
    // sender on the right, receiver on the left, every message the same way
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = if (out) Arrangement.End else Arrangement.Start
    ) {
        val bg = if (bare) Modifier
        else if (out) Modifier.background(Brush.linearGradient(theme.accent))
        else Modifier.background(MaterialTheme.colorScheme.surface)
        Column(
            Modifier.widthIn(max = maxW).then(if (bare) Modifier else Modifier.clip(shape)).then(bg)
                .then(if (bare) Modifier else Modifier.padding(horizontal = 12.dp, vertical = 8.dp)),
            horizontalAlignment = if (out) Alignment.End else Alignment.Start
        ) {
            // the name is shown on every message (incoming: sender name, outgoing: "You")
            Text(
                who,
                color = if (bare || out || MaterialTheme.colorScheme.surface.luminance() < 0.5f)
                    androidx.compose.ui.graphics.lerp(theme.accent[0], Color.White, 0.75f) else theme.accent[0],
                fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1,
                modifier = Modifier.padding(bottom = 2.dp)
            )
            when (m.kind) {
                // text and voice messages: never a save button
                0 -> Text(m.text, color = fg)
                1 -> Row(verticalAlignment = Alignment.CenterVertically) {
                    AirButton("▶", if (out) Grey else theme.accent, style = 0) {
                        if (m.path.isNotEmpty() && m.progress == 100) VoicePlayer.play(m.path)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Voice message", color = fg)
                }
                else -> {
                    val type = Utils.fileType(m.fileName)
                    val ready = m.path.isNotEmpty() && m.progress == 100
                    // save icon: only on received data (never on what I sent), at the right side inside the same box
                    val canSave = ready && !out
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f, fill = false)) {
                            when {
                                // image: preview only (no file name)
                                type == 1 -> {
                                    if (ready) ImagePreview(m.path) { openFile(ctx, m.path) }
                                    else if (m.progress >= 0) Text("Image", color = fg, fontWeight = FontWeight.Bold)
                                }
                                // video: plays in the chat
                                type == 2 -> {
                                    if (ready) InlineVideo(m.path)
                                    else if (m.progress >= 0) Text("Video", color = fg, fontWeight = FontWeight.Bold)
                                }
                                // music / audio: colourful format logo + small name (download icon right after it), player below
                                type == 3 -> {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        FileLogo(m.fileName, 46.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f, fill = false)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(m.fileName.ifBlank { "Music" }, color = fg, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                                                    maxLines = 2, modifier = Modifier.weight(1f, fill = false))
                                                if (canSave) SaveRow { onSave(m) }
                                            }
                                            Text(Utils.sizeText(m.fileSize), color = fg.copy(alpha = 0.8f), fontSize = 11.sp)
                                        }
                                    }
                                    if (ready) InlineAudio(m.path, fg, theme.accent)
                                }
                                // everything else (.zip, .pdf ...): colourful logo of that format + small name, download icon right after it
                                else -> {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        FileLogo(m.fileName, 46.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f, fill = false)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(m.fileName.ifBlank { "File" }, color = fg, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                                                    maxLines = 2, modifier = Modifier.weight(1f, fill = false)
                                                        .then(if (ready) Modifier.clickable { openFile(ctx, m.path) } else Modifier))
                                                if (canSave) SaveRow { onSave(m) }
                                            }
                                            Text(Utils.sizeText(m.fileSize), color = fg.copy(alpha = 0.8f), fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                        // photos and videos have no name, so their icon sits at the right of the picture
                        if (canSave && (type == 1 || type == 2)) SaveRow { onSave(m) }
                    }
                }
            }
            if (m.kind > 0 && m.progress in 0..99) {
                LinearProgressIndicator(progress = { m.progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                Text("${m.progress}%", color = fg.copy(alpha = 0.7f), fontSize = 11.sp)
            }
            if (m.progress < 0) Text("Failed", color = Color(0xFFFF6B6B), fontSize = 12.sp)
            // compact time, bottom right, in the phone's own format (e.g. 10:15 AM)
            Row(Modifier.align(Alignment.End).padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(Utils.timeOnly(ctx, m.timestamp), color = fg.copy(alpha = 0.7f), fontSize = 10.sp)
                if (out) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (m.status == 0) "✓" else "✓✓",
                        color = if (m.status >= 2) Color(0xFF67E8F9) else fg.copy(alpha = 0.8f),
                        fontSize = 12.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SaveRow(onClick: () -> Unit) {
    // small, thin green download icon (no button or colour behind it): one tap saves the file
    Box(
        Modifier.padding(start = 4.dp).size(32.dp).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { DownloadIcon(Modifier.size(18.dp), Green[0], stroke = 0.11f) }
}

// ------------------------------------------------------------------ video call (dark + neon)

@Composable
fun VideoCallScreen(mgr: Manager) {
    val call by mgr.call.collectAsState()
    val frames by mgr.frames.collectAsState()
    val now = rememberNow()
    var front by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    val neonA = listOf(Color(0xFF00F5D4), Color(0xFF00BBF9))
    val neonB = listOf(Color(0xFFFF2E93), Color(0xFFFF6B35))
    val neonC = listOf(Color(0xFFB517FF), Color(0xFF6A5CFF))
    Box(Modifier.fillMaxSize().background(Color(0xFF07070F))) {
        val list = frames.values.toList()
        if (list.isEmpty()) {
            Text("Waiting for video...", color = Color(0xFF00F5D4), modifier = Modifier.align(Alignment.Center))
        } else {
            Column(Modifier.fillMaxSize()) {
                for (rowItems in list.chunked(2)) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        for (b in rowItems) {
                            Image(
                                b.asImageBitmap(), null,
                                Modifier.weight(1f).fillMaxHeight().padding(2.dp), contentScale = ContentScale.Fit
                            )
                        }
                    }
                }
            }
        }
        Text(
            if (call.startedAt > 0) Utils.duration(((now - call.startedAt) / 1000).toInt()) else "Calling...",
            color = Color(0xFF00F5D4), fontWeight = FontWeight.Bold, fontSize = 18.sp,
            modifier = Modifier.align(Alignment.TopStart).padding(16.dp)
        )
        CameraPreview(
            front, { jpeg, rot -> mgr.sendVideo(jpeg, rot) },
            Modifier.align(Alignment.TopEnd).padding(12.dp).size(110.dp, 150.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(2.dp, Brush.linearGradient(neonA), RoundedCornerShape(16.dp))
        )
        Row(Modifier.align(Alignment.BottomCenter).padding(24.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AirButton(if (muted) "🔇" else "🎤", neonC, style = 2) {
                muted = !muted
                mgr.audio.muted = muted
            }
            AirButton("🔄", neonA, style = 2) { front = !front }
            AirButton("End", neonB, style = 2) { mgr.endCall() }
        }
    }
}

// ------------------------------------------------------------------ saved users, history

@Composable
fun UsersScreen(mgr: Manager, back: () -> Unit) {
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())
    var toDelete by remember { mutableStateOf<UserEntity?>(null) }
    PageBox(ToolsTheme) {
        Title("Saved users", back)
        LazyColumn(Modifier.weight(1f)) {
            items(users, key = { it.id }) { u ->
                Panel(Modifier.padding(bottom = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u.photo, u.name, 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            u.name, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f)
                        )
                        AirButton("Delete", Red, small = true) { toDelete = u }
                    }
                }
            }
        }
    }
    val d = toDelete
    if (d != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete " + d.name + "?") },
            text = { Text("This user will be removed from your saved users.") },
            confirmButton = { AirButton("Delete", Red, style = 1) { mgr.deleteUser(d.id); toDelete = null } },
            dismissButton = { AirButton("Cancel", Grey, style = 2) { toDelete = null } }
        )
    }
}

/** One line per chat inside the chosen period. */
private class ChatSummary(
    val name: String, var messages: Int = 0, var files: Int = 0, var voice: Int = 0, var calls: Int = 0,
    var lastTs: Long = 0, var last: String = ""
)

@Composable
fun HistoryScreen(mgr: Manager, back: () -> Unit) {
    val ctx = LocalContext.current
    val now = rememberMinuteNow()
    var range by remember { mutableStateOf(1) } // 0 = today, 1 = last 3 days
    val since = Utils.startOfDay(now) - (if (range == 0) 0L else 2 * 86_400_000L)
    val msgs by remember(since) { mgr.messagesSince(since) }.collectAsState(initial = emptyList<MessageEntity>())
    val calls by mgr.callsFlow.collectAsState(initial = emptyList<CallEntity>())
    val users by mgr.usersFlow.collectAsState(initial = emptyList<UserEntity>())

    val rows = remember(msgs, calls, users, since) {
        val map = LinkedHashMap<String, ChatSummary>()
        fun row(conv: String, fallback: String): ChatSummary =
            map.getOrPut(conv) { ChatSummary(users.firstOrNull { it.id == conv }?.name ?: fallback) }
        for (m in msgs) { // newest first
            val r = row(m.convId, m.senderName.takeIf { !m.outgoing && it.isNotBlank() } ?: "Group chat")
            r.messages++
            if (m.kind == 1) r.voice++
            if (m.kind == 2) r.files++
            if (m.timestamp > r.lastTs) {
                r.lastTs = m.timestamp
                r.last = when (m.kind) {
                    0 -> m.text
                    1 -> "Voice message"
                    else -> m.fileName
                }
            }
        }
        for (c in calls) {
            if (c.timestamp < since) continue
            val r = row(c.convId, c.peerName)
            r.calls++
            if (c.timestamp > r.lastTs) {
                r.lastTs = c.timestamp
                r.last = (if (c.video) "Video call · " else "Voice call · ") + Utils.duration(c.durationSec)
            }
        }
        map.values.sortedByDescending { it.lastTs }
    }

    PageBox(ToolsTheme) {
        Title("History", back)
        Row(Modifier.fillMaxWidth()) {
            AirButton("Today", if (range == 0) ToolsTheme.accent else Grey, Modifier.weight(1f), 1, small = true) { range = 0 }
            Spacer(Modifier.width(8.dp))
            AirButton("Last 3 days", if (range == 1) ToolsTheme.accent else Grey, Modifier.weight(1f), 1, small = true) { range = 1 }
        }
        Spacer(Modifier.height(10.dp))
        Panel {
            val totalMsgs = rows.sumOf { it.messages }
            val totalCalls = rows.sumOf { it.calls }
            Text(
                rows.size.toString() + (if (rows.size == 1) " connection" else " connections") +
                    "  ·  " + totalMsgs + (if (totalMsgs == 1) " message" else " messages") +
                    "  ·  " + totalCalls + (if (totalCalls == 1) " call" else " calls"),
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(8.dp))
        if (rows.isEmpty()) {
            Panel { Text("Nothing here yet.", fontSize = 13.sp) }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(rows) { r ->
                Panel(Modifier.padding(bottom = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(r.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        Text(Utils.dayTime(ctx, now, r.lastTs), fontSize = 11.sp)
                    }
                    val parts = ArrayList<String>()
                    if (r.messages > 0) parts.add(r.messages.toString() + (if (r.messages == 1) " message" else " messages"))
                    if (r.files > 0) parts.add(r.files.toString() + (if (r.files == 1) " file" else " files"))
                    if (r.voice > 0) parts.add(r.voice.toString() + " voice")
                    if (r.calls > 0) parts.add(r.calls.toString() + (if (r.calls == 1) " call" else " calls"))
                    Text(parts.joinToString("  ·  "), fontSize = 12.sp)
                    if (r.last.isNotBlank()) Text("“" + r.last + "”", fontSize = 13.sp, maxLines = 1)
                }
            }
        }
    }
}
