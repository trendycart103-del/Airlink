package com.airlink.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** phase: 0 idle, 1 update found, 2 downloading, 3 installing, 4 finished (msg says how). */
data class UpdateState(
    val phase: Int = 0, val pct: Int = 0, val version: String = "", val url: String = "", val msg: String = ""
)

/**
 * In-app update with a real progress bar: finds the newest APK in the GitHub release, downloads it,
 * and installs it through the system PackageInstaller (so the person sees Downloading / Installing / Done).
 * Set REPO to "owner/repo" of the GitHub project. While REPO is empty the feature stays completely silent.
 */
object Updater {
    const val REPO = ""
    const val ACTION = "com.airlink.app.INSTALL_RESULT"

    val state = MutableStateFlow(UpdateState())

    private fun newer(remote: String, local: String): Boolean {
        fun parts(v: String) = v.trim().trimStart('v', 'V').split('.', '-', '_').map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val a = parts(remote)
        val b = parts(local)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** Quietly looks for a newer release. Nothing is shown unless one exists. */
    fun check(ctx: Context) {
        if (REPO.isBlank() || state.value.phase != 0) return
        Thread {
            try {
                val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val tag = j.optString("tag_name")
                val assets = j.optJSONArray("assets") ?: return@Thread
                var apk = ""
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk", true)) {
                        apk = a.optString("browser_download_url")
                        break
                    }
                }
                val mine = ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "0"
                if (apk.isNotEmpty() && newer(tag, mine)) {
                    state.value = UpdateState(1, 0, tag, apk)
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    fun dismiss() {
        state.value = UpdateState()
    }

    /** Download (with %), then install (with %). */
    fun start(ctx: Context) {
        val s = state.value
        if (s.phase != 1) return
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            state.value = s.copy(
                phase = 4,
                msg = "Allow \"Install unknown apps\" for Airlink in the screen that opens, then come back and tap Update again."
            )
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
            return
        }
        Thread {
            try {
                val f = File(ctx.cacheDir, "update.apk")
                state.value = s.copy(phase = 2, pct = 0)
                val c = URL(s.url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 15000
                val total = c.contentLengthLong
                var got = 0L
                var last = -1
                c.inputStream.use { ins ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            val p = if (total > 0) (got * 100 / total).toInt().coerceIn(0, 100) else 0
                            if (p != last) {
                                last = p
                                state.value = state.value.copy(phase = 2, pct = p)
                            }
                        }
                    }
                }
                install(ctx, f)
            } catch (e: Exception) {
                state.value = s.copy(phase = 4, msg = "Download failed. Check the connection and try again.")
            }
        }.start()
    }

    private fun install(ctx: Context, f: File) {
        try {
            state.value = state.value.copy(phase = 3, pct = 0)
            val pi = ctx.packageManager.packageInstaller
            val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
            pi.openSession(id).use { ses ->
                val size = f.length()
                var done = 0L
                var last = -1
                f.inputStream().use { ins ->
                    ses.openWrite("airlink.apk", 0, size).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val p = if (size > 0) (done * 100 / size).toInt().coerceIn(0, 100) else 0
                            if (p != last) {
                                last = p
                                state.value = state.value.copy(phase = 3, pct = p)
                            }
                        }
                        ses.fsync(out)
                    }
                }
                val pend = PendingIntent.getBroadcast(
                    ctx, id, Intent(ctx, InstallReceiver::class.java).setAction(ACTION).setPackage(ctx.packageName),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
                ses.commit(pend.intentSender)
            }
        } catch (e: Exception) {
            state.value = state.value.copy(phase = 4, msg = "Could not install the update.")
        }
    }

    /** Plain-words reason for a failed install. */
    fun reason(status: Int, text: String?): String = when (status) {
        PackageInstaller.STATUS_FAILURE_CONFLICT ->
            "Not installed: the new file is signed with a different key (or has an older version number) than the app on this phone. Build every update with the same signing key and a higher versionCode."
        PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> "Not installed: this file does not fit this phone."
        PackageInstaller.STATUS_FAILURE_STORAGE -> "Not installed: not enough free storage."
        PackageInstaller.STATUS_FAILURE_BLOCKED -> "Not installed: blocked by the phone. Allow installs from Airlink and try again."
        PackageInstaller.STATUS_FAILURE_ABORTED -> "Installation was cancelled."
        else -> "Not installed" + (if (text.isNullOrBlank()) "." else ": $text")
    }
}

/** Receives the installer's answer: asks for the system confirm screen, then reports success or the reason. */
class InstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, i: Intent) {
        val st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        when (st) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val ask = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (ask != null) {
                    try {
                        ctx.startActivity(ask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                }
            }
            PackageInstaller.STATUS_SUCCESS ->
                Updater.state.value = UpdateState(4, 100, msg = "Updated. Airlink restarts with the new version.")
            else ->
                Updater.state.value = UpdateState(4, 0, msg = Updater.reason(st, i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)))
        }
    }
}
