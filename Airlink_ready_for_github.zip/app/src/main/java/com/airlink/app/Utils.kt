package com.airlink.app

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.text.format.DateFormat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.Date

object Utils {
    /** Local IPv4 address on the Wi-Fi / hotspot interface. */
    fun localIp(): String? {
        return try {
            val found = ArrayList<Pair<String, String>>()
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) {
                        found.add(Pair(ni.name, a.hostAddress ?: ""))
                    }
                }
            }
            // Only Wi-Fi / hotspot interfaces count. Mobile-data addresses (rmnet, ccmni...) can never be reached by the other phone.
            val wifi = found.firstOrNull {
                it.first.startsWith("wlan") || it.first.startsWith("ap") || it.first.startsWith("swlan") ||
                    it.first.startsWith("eth") || it.first.startsWith("p2p")
            }
            val ip = wifi?.second
            if (ip.isNullOrEmpty()) null else ip
        } catch (e: Exception) {
            null
        }
    }

    class WifiInfo(val ip: String, val prefix: Int, val broadcast: String?)

    /** Address, prefix length and real broadcast address of the Wi-Fi / hotspot interface. */
    fun wifiInfo(): WifiInfo? {
        return try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name
                if (!(n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth") || n.startsWith("p2p"))) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) {
                        return WifiInfo(a.hostAddress ?: continue, ia.networkPrefixLength.toInt(), ia.broadcast?.hostAddress)
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    /** Every other address of this phone's Wi-Fi / hotspot subnet (at most one /22 around this phone). */
    fun subnetHosts(info: WifiInfo): List<String> {
        val parts = info.ip.split(".").map { it.toInt() }
        val me = (parts[0] shl 24) or (parts[1] shl 16) or (parts[2] shl 8) or parts[3]
        val prefix = info.prefix.coerceIn(22, 30)
        val mask = (-1 shl (32 - prefix))
        val net = me and mask
        val last = net or mask.inv()
        val out = ArrayList<String>()
        for (x in (net + 1) until last) {
            if (x == me) continue
            out.add("${(x ushr 24) and 255}.${(x ushr 16) and 255}.${(x ushr 8) and 255}.${x and 255}")
        }
        return out
    }


    /** What this phone's network looks like right now. */
    enum class Net { NONE, WIFI_OFF, HOTSPOT, WIFI_CLIENT }

    private fun isApName(n: String) = n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap")

    /** True when this phone itself is sharing its hotspot (its address lives on an access-point interface). */
    fun hotspotOn(): Boolean = try {
        var r = false
        for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp || ni.isLoopback || !isApName(ni.name)) continue
            for (a in Collections.list(ni.inetAddresses)) {
                if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) r = true
            }
        }
        r
    } catch (e: Exception) {
        false
    }

    /** Hotspot phone / joined-a-Wi-Fi phone / Wi-Fi switched on but not joined / nothing at all. */
    fun netState(ctx: Context): Net = when {
        hotspotOn() -> Net.HOTSPOT
        localIp() != null -> Net.WIFI_CLIENT
        wifiOn(ctx) -> Net.WIFI_OFF.let { Net.NONE }
        else -> Net.WIFI_OFF
    }

    /** Address of the Wi-Fi router / hotspot phone. A hosting phone is always this address, so it is asked FIRST. */
    @Suppress("DEPRECATION")
    fun gatewayIp(ctx: Context): String? = try {
        val g = (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).dhcpInfo?.gateway ?: 0
        if (g == 0) null else "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}"
    } catch (e: Exception) {
        null
    }

    /** Posts "<name> wants to connect" with an Allow button, for when Airlink is not on screen. */
    fun postPairNotification(ctx: Context, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("airlink_alerts", "Airlink alerts", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            val open = PendingIntent.getActivity(
                ctx, 110, Intent(ctx, MainActivity::class.java).addFlags(flags),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val allow = PendingIntent.getActivity(
                ctx, 111, Intent(ctx, MainActivity::class.java).putExtra("pair_allow", true).addFlags(flags),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, "airlink_alerts")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("Allow connection?")
                .setContentText("$name wants to connect with you")
                .setContentIntent(open)
                .addAction(0, "Allow", allow)
                .setAutoCancel(true)
                .setTimeoutAfter(60_000L)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            nm.notify(4730, n)
        } catch (e: Exception) {
        }
    }

    fun cancelPairNotification(ctx: Context) {
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(4730)
        } catch (e: Exception) {
        }
    }

    /** True if the Wi-Fi radio is switched on. */
    fun wifiOn(ctx: Context): Boolean = try {
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    private fun launchFirst(ctx: Context, list: List<Intent>) {
        for (i in list) {
            try {
                if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
    }

    /** Opens the Wi-Fi switch (a small panel on Android 10+, the Wi-Fi settings page before that). */
    fun openWifiSettings(ctx: Context) {
        val l = ArrayList<Intent>()
        if (Build.VERSION.SDK_INT >= 29) l.add(Intent(Settings.Panel.ACTION_WIFI))
        l.add(Intent(Settings.ACTION_WIFI_SETTINGS))
        launchFirst(ctx, l)
    }

    /** Opens the Hotspot / tethering settings page. */
    fun openHotspotSettings(ctx: Context) {
        launchFirst(
            ctx,
            listOf(
                Intent("android.settings.TETHER_SETTINGS"),
                Intent(Settings.ACTION_WIRELESS_SETTINGS),
                Intent(Settings.ACTION_SETTINGS)
            )
        )
    }

    /**
     * Real Android notification that, when tapped, brings Airlink forward and opens the Wi-Fi settings (kind 0 / 2)
     * or the hotspot settings (kind 1). Silent no-op if the notification permission was not given;
     * the same message is always shown inside the app too.
     */
    fun postSettingsNotification(ctx: Context, text: String, kind: Int) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("airlink_alerts", "Airlink alerts", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val which = if (kind == 1) 1 else 0
            val open = PendingIntent.getActivity(
                ctx, 100 + which,
                Intent(ctx, MainActivity::class.java).putExtra("open_settings", which)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, "airlink_alerts")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("Airlink")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text + "\nTap here to open the settings."))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            nm.notify(4720 + which, n)
        } catch (e: Exception) {
        }
    }

    fun cancelSettingsNotifications(ctx: Context) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(4720)
            nm.cancel(4721)
        } catch (e: Exception) {
        }
    }

    fun qrBitmap(text: String, size: Int = 640): Bitmap {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bmp.setPixel(x, y, if (m.get(x, y)) Color.BLACK else Color.WHITE)
            }
        }
        return bmp
    }

    /** Date + time in the phone's own default format. */
    fun stamp(ctx: Context, ts: Long): String {
        val d = Date(ts)
        return DateFormat.getDateFormat(ctx).format(d) + " " + DateFormat.getTimeFormat(ctx).format(d)
    }

    fun duration(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

    fun sizeText(b: Long): String = when {
        b < 0 -> ""
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
        b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
        else -> "%.2f GB".format(b / 1073741824.0)
    }

    /** Cleans the name (any language is kept, so names never turn into "____") and always keeps the original extension. */
    fun safeName(n: String): String {
        // keep every language (Bangla, Arabic, emoji ...); only characters a file name cannot hold are replaced
        val clean = n.replace(Regex("[\\u0000-\\u001F/\\\\:*?\"<>|]"), "_").trim()
        val dot = clean.lastIndexOf('.')
        val ext = if (dot > 0 && clean.length - dot <= 12) clean.substring(dot) else ""
        val stem = (if (ext.isEmpty()) clean else clean.substring(0, dot)).take(80 - ext.length).ifBlank { "file" }
        return stem + ext
    }

    /** Square 160px JPEG for the profile photo. */
    fun profileBytes(ctx: Context, uri: Uri): ByteArray? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 320 && o.outHeight / (s * 2) >= 320) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val side = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val sc = Bitmap.createScaledBitmap(sq, 160, 160, true)
            val out = ByteArrayOutputStream()
            sc.compress(Bitmap.CompressFormat.JPEG, 80, out)
            out.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    /** 0 = other file, 1 = image, 2 = video, 3 = music/audio (judged by the file extension). */
    fun fileType(name: String): Int {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif" -> 1
            "mp4", "mkv", "3gp", "3gpp", "3g2", "webm", "mov", "avi", "m4v", "flv", "wmv", "mpg", "mpeg", "ts", "ogv", "vob", "divx", "asf", "rm", "rmvb" -> 2
            "mp3", "m4a", "aac", "wav", "ogg", "oga", "opus", "flac", "amr", "wma", "mid", "midi", "mka", "weba", "aif", "aiff" -> 3
            else -> 0
        }
    }

    /** Small preview: the picture itself, or the first frame of a video. Call from a background thread. */
    fun thumbnail(path: String, type: Int, maxSide: Int = 480): Bitmap? {
        return try {
            val f = File(path)
            if (!f.exists()) return null
            if (type == 2) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(path)
                    val fr = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
                    val sc = maxSide.toFloat() / maxOf(fr.width, fr.height)
                    if (sc < 1f) Bitmap.createScaledBitmap(fr, (fr.width * sc).toInt().coerceAtLeast(1), (fr.height * sc).toInt().coerceAtLeast(1), true) else fr
                } finally {
                    try {
                        r.release()
                    } catch (e: Exception) {
                    }
                }
            } else {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, o)
                var s = 1
                while (o.outWidth / (s * 2) >= maxSide && o.outHeight / (s * 2) >= maxSide) s *= 2
                val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
                val rot = try {
                    when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270
                        else -> 0
                    }
                } catch (e: Exception) {
                    0
                }
                if (rot != 0) Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true) else bmp
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Compact clock time in the phone's own format, e.g. "10:15 AM". */
    fun timeOnly(ctx: Context, ts: Long): String = DateFormat.getTimeFormat(ctx).format(Date(ts))

    /** "Just now", "5 mins ago", "2 hrs ago", "3 days ago". */
    fun lastSeen(now: Long, ts: Long): String {
        val m = ((now - ts) / 60000).coerceAtLeast(0)
        return when {
            m < 1 -> "Just now"
            m == 1L -> "1 min ago"
            m < 60 -> "$m mins ago"
            m < 120 -> "1 hr ago"
            m < 24 * 60 -> "${m / 60} hrs ago"
            m < 48 * 60 -> "1 day ago"
            else -> "${m / (24 * 60)} days ago"
        }
    }

    fun startOfDay(ts: Long): Long {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = ts
        c.set(java.util.Calendar.HOUR_OF_DAY, 0)
        c.set(java.util.Calendar.MINUTE, 0)
        c.set(java.util.Calendar.SECOND, 0)
        c.set(java.util.Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** "Today, 10:15 AM" / "Yesterday, 4:02 PM" / "12/10/2026, 9:30 AM". */
    fun dayTime(ctx: Context, now: Long, ts: Long): String {
        val d0 = startOfDay(now)
        val day = when {
            ts >= d0 -> "Today"
            ts >= d0 - 86_400_000L -> "Yesterday"
            else -> DateFormat.getDateFormat(ctx).format(Date(ts))
        }
        return day + ", " + timeOnly(ctx, ts)
    }
}
